/**
 * PPFD (Photosynthetic Photon Flux Density) calculation utilities
 * Based on inverse square law and fixture specifications
 */

export interface PPFDPoint {
  x: number;
  y: number;
  value: number;
}

export interface FixtureData {
  x: number; // position in meters
  y: number; // position in meters
  z: number; // height in meters
  ppf: number; // μmol/s
  beamAngle: number; // degrees
  enabled: boolean;
}

/**
 * Calculate PPFD at a specific point from a single fixture
 * Using inverse square law with beam angle consideration
 */
function calculatePPFDFromFixture(
  fixture: FixtureData,
  pointX: number,
  pointY: number,
  canopyHeight: number
): number {
  if (!fixture.enabled) return 0;

  // Calculate distance from fixture to point
  const dx = fixture.x - pointX;
  const dy = fixture.y - pointY;
  const dz = fixture.z - canopyHeight;
  
  const horizontalDistance = Math.sqrt(dx * dx + dy * dy);
  const totalDistance = Math.sqrt(dx * dx + dy * dy + dz * dz);
  
  // Calculate angle from fixture to point
  const angle = Math.atan2(horizontalDistance, dz) * (180 / Math.PI);
  
  // Apply beam angle falloff
  const halfBeamAngle = fixture.beamAngle / 2;
  let intensityFactor = 1;
  
  if (angle > halfBeamAngle) {
    // Linear falloff outside beam angle
    const falloffAngle = halfBeamAngle * 1.5; // 50% wider for soft edge
    if (angle < falloffAngle) {
      intensityFactor = 1 - (angle - halfBeamAngle) / (falloffAngle - halfBeamAngle);
    } else {
      intensityFactor = 0;
    }
  }
  
  // Apply inverse square law
  // PPF is total output, we need to distribute it over the coverage area
  const coverageArea = Math.PI * Math.pow(Math.tan(halfBeamAngle * Math.PI / 180) * dz, 2);
  const ppfd = (fixture.ppf / coverageArea) * intensityFactor / (totalDistance * totalDistance) * (dz * dz);
  
  return Math.max(0, ppfd);
}

/**
 * Calculate PPFD grid for a room with multiple fixtures
 */
export function calculatePPFDGrid(
  fixtures: FixtureData[],
  roomWidth: number, // meters
  roomLength: number, // meters
  canopyHeight: number, // meters
  gridResolution: number = 50 // points per dimension
): number[][] {
  const grid: number[][] = [];
  const cellWidth = roomWidth / gridResolution;
  const cellLength = roomLength / gridResolution;
  
  for (let y = 0; y < gridResolution; y++) {
    const row: number[] = [];
    const pointY = y * cellLength + cellLength / 2;
    
    for (let x = 0; x < gridResolution; x++) {
      const pointX = x * cellWidth + cellWidth / 2;
      let totalPPFD = 0;
      
      // Sum contributions from all fixtures
      for (const fixture of fixtures) {
        totalPPFD += calculatePPFDFromFixture(fixture, pointX, pointY, canopyHeight);
      }
      
      row.push(totalPPFD);
    }
    grid.push(row);
  }
  
  return grid;
}

/**
 * Calculate PPFD statistics from a grid
 */
export function calculatePPFDStats(grid: number[][]) {
  let min = Infinity;
  let max = 0;
  let sum = 0;
  let count = 0;
  
  for (const row of grid) {
    for (const value of row) {
      if (value > 0) {
        min = Math.min(min, value);
        max = Math.max(max, value);
        sum += value;
        count++;
      }
    }
  }
  
  const avg = count > 0 ? sum / count : 0;
  const uniformity = avg > 0 ? min / avg : 0;
  
  return {
    min: min === Infinity ? 0 : Math.round(min),
    max: Math.round(max),
    avg: Math.round(avg),
    uniformity: Number(uniformity.toFixed(2))
  };
}

/**
 * Calculate DLI (Daily Light Integral) from PPFD
 */
export function calculateDLI(ppfd: number, photoperiod: number): number {
  // DLI = PPFD × photoperiod × 3600 / 1,000,000
  return Number((ppfd * photoperiod * 3600 / 1000000).toFixed(1));
}

/**
 * Generate heatmap data for visualization
 */
export function generateHeatmapData(
  grid: number[][],
  maxValue?: number
): { x: number; y: number; value: number }[] {
  const data: { x: number; y: number; value: number }[] = [];
  const actualMax = maxValue || Math.max(...grid.flat());
  
  for (let y = 0; y < grid.length; y++) {
    for (let x = 0; x < grid[y].length; x++) {
      data.push({
        x,
        y,
        value: grid[y][x] / actualMax // Normalize to 0-1
      });
    }
  }
  
  return data;
}

/**
 * Calculate spectrum mix from multiple fixtures
 */
export function calculateSpectrumMix(fixtures: FixtureData[] & { spectrumData?: any }[]) {
  const totalSpectrum = {
    blue: 0,
    green: 0,
    red: 0,
    farRed: 0,
    total: 0
  };
  
  for (const fixture of fixtures) {
    if (fixture.enabled && fixture.spectrumData) {
      const fixturePPF = fixture.ppf;
      totalSpectrum.blue += (fixture.spectrumData.blue / 100) * fixturePPF;
      totalSpectrum.green += (fixture.spectrumData.green / 100) * fixturePPF;
      totalSpectrum.red += (fixture.spectrumData.red / 100) * fixturePPF;
      totalSpectrum.farRed += (fixture.spectrumData.farRed / 100) * fixturePPF;
      totalSpectrum.total += fixturePPF;
    }
  }
  
  // Convert to percentages
  if (totalSpectrum.total > 0) {
    return {
      blue: Math.round((totalSpectrum.blue / totalSpectrum.total) * 100),
      green: Math.round((totalSpectrum.green / totalSpectrum.total) * 100),
      red: Math.round((totalSpectrum.red / totalSpectrum.total) * 100),
      farRed: Math.round((totalSpectrum.farRed / totalSpectrum.total) * 100)
    };
  }
  
  return { blue: 0, green: 0, red: 0, farRed: 0 };
}