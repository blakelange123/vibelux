import { PhotosyntheticCalculator } from '@/components/PhotosyntheticCalculator'

export default function PhotosyntheticCalculatorPage() {
  return <PhotosyntheticCalculator />
}