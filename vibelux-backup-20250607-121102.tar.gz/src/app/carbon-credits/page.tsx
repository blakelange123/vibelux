import { BlockchainCarbonCredits } from '@/components/BlockchainCarbonCredits'

export default function CarbonCreditsPage() {
  return <BlockchainCarbonCredits />
}