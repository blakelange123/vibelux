import { YieldPredictionML } from '@/components/YieldPredictionML'

export default function YieldPredictionPage() {
  return <YieldPredictionML />
}