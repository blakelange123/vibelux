'use client';

import { AdvancedDesignerV2 } from '@/components/AdvancedDesignerV2';

export default function AdvancedDesignerV3Page() {
  return <AdvancedDesignerV2 />;
}