'use client'

import { useState } from 'react'
import { Room3DWebGL } from '@/components/Room3DWebGL'
import {
  Sparkles,
  Settings,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Download,
  Upload,
  Layers,
  Zap,
  Save,
  Share2
} from 'lucide-react'

export default function Room3DPage() {
  const [roomDimensions, setRoomDimensions] = useState({
    width: 10,
    length: 12,
    height: 3
  })
  
  const [fixtures, setFixtures] = useState([
    {
      id: 'f1',
      x: -2,
      y: -3,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Fluence',
        model: 'SPYDR 2p',
        wattage: 630,
        ppf: 1700,
        beamAngle: 120
      },
      enabled: true
    },
    {
      id: 'f2',
      x: 2,
      y: -3,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Fluence',
        model: 'SPYDR 2p',
        wattage: 630,
        ppf: 1700,
        beamAngle: 120
      },
      enabled: true
    },
    {
      id: 'f3',
      x: -2,
      y: 0,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Gavita',
        model: 'Pro 1700e',
        wattage: 645,
        ppf: 1700,
        beamAngle: 120
      },
      enabled: true
    },
    {
      id: 'f4',
      x: 2,
      y: 0,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Gavita',
        model: 'Pro 1700e',
        wattage: 645,
        ppf: 1700,
        beamAngle: 120
      },
      enabled: true
    },
    {
      id: 'f5',
      x: -2,
      y: 3,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Mars Hydro',
        model: 'FC-E6500',
        wattage: 650,
        ppf: 1711,
        beamAngle: 120
      },
      enabled: false
    },
    {
      id: 'f6',
      x: 2,
      y: 3,
      z: 2.5,
      rotation: 0,
      model: {
        brand: 'Mars Hydro',
        model: 'FC-E6500',
        wattage: 650,
        ppf: 1711,
        beamAngle: 120
      },
      enabled: false
    }
  ])
  
  const [tiers, setTiers] = useState([
    {
      id: 't1',
      name: 'Lower Tier',
      height: 0.5,
      benchDepth: 1.5,
      canopyHeight: 0.6,
      color: '#10B981',
      visible: true,
      enabled: true
    },
    {
      id: 't2',
      name: 'Middle Tier',
      height: 1.2,
      benchDepth: 1.5,
      canopyHeight: 0.6,
      color: '#3B82F6',
      visible: true,
      enabled: true
    },
    {
      id: 't3',
      name: 'Upper Tier',
      height: 1.9,
      benchDepth: 1.5,
      canopyHeight: 0.5,
      color: '#F59E0B',
      visible: true,
      enabled: false
    }
  ])
  
  const toggleFixture = (id: string) => {
    setFixtures(prev => prev.map(f => 
      f.id === id ? { ...f, enabled: !f.enabled } : f
    ))
  }
  
  const toggleTier = (id: string) => {
    setTiers(prev => prev.map(t => 
      t.id === id ? { ...t, enabled: !t.enabled } : t
    ))
  }
  
  const toggleTierVisibility = (id: string) => {
    setTiers(prev => prev.map(t => 
      t.id === id ? { ...t, visible: !t.visible } : t
    ))
  }
  
  const totalPower = fixtures.filter(f => f.enabled).reduce((sum, f) => sum + f.model.wattage, 0)
  const totalPPF = fixtures.filter(f => f.enabled).reduce((sum, f) => sum + f.model.ppf, 0)
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-vibelux-darker">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-xl border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">3D Room Visualization</h1>
                <p className="text-sm text-gray-400">WebGL-powered lighting design</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg flex items-center gap-2 transition-colors">
                <Upload className="w-4 h-4" />
                Import
              </button>
              <button className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg flex items-center gap-2 transition-colors">
                <Download className="w-4 h-4" />
                Export
              </button>
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center gap-2 transition-colors">
                <Save className="w-4 h-4" />
                Save Design
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex h-[calc(100vh-80px)]">
        {/* Left Sidebar - Configuration */}
        <div className="w-80 bg-gray-900/50 backdrop-blur-xl border-r border-gray-700 overflow-y-auto p-4 space-y-4">
          {/* Room Settings */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Room Dimensions
            </h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-400">Width (m)</label>
                <input
                  type="number"
                  value={roomDimensions.width}
                  onChange={(e) => setRoomDimensions(prev => ({ ...prev, width: Number(e.target.value) }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400">Length (m)</label>
                <input
                  type="number"
                  value={roomDimensions.length}
                  onChange={(e) => setRoomDimensions(prev => ({ ...prev, length: Number(e.target.value) }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400">Height (m)</label>
                <input
                  type="number"
                  value={roomDimensions.height}
                  onChange={(e) => setRoomDimensions(prev => ({ ...prev, height: Number(e.target.value) }))}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm"
                />
              </div>
            </div>
          </div>
          
          {/* Fixtures */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Light Fixtures ({fixtures.filter(f => f.enabled).length}/{fixtures.length})
            </h3>
            <div className="space-y-2">
              {fixtures.map(fixture => (
                <div
                  key={fixture.id}
                  className={`p-3 rounded border transition-all ${
                    fixture.enabled 
                      ? 'bg-yellow-900/20 border-yellow-600/50' 
                      : 'bg-gray-700/30 border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-white">{fixture.model.brand}</p>
                      <p className="text-xs text-gray-400">{fixture.model.model}</p>
                      <p className="text-xs text-gray-500">{fixture.model.wattage}W • {fixture.model.ppf} PPF</p>
                    </div>
                    <button
                      onClick={() => toggleFixture(fixture.id)}
                      className={`p-2 rounded transition-colors ${
                        fixture.enabled 
                          ? 'bg-yellow-600 hover:bg-yellow-700 text-white' 
                          : 'bg-gray-600 hover:bg-gray-500 text-gray-300'
                      }`}
                    >
                      {fixture.enabled ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Growing Tiers */}
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Growing Tiers
            </h3>
            <div className="space-y-2">
              {tiers.map(tier => (
                <div
                  key={tier.id}
                  className={`p-3 rounded border transition-all ${
                    tier.enabled 
                      ? 'bg-gray-700/50 border-gray-600' 
                      : 'bg-gray-700/20 border-gray-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: tier.color }}
                      />
                      <p className="text-sm font-medium text-white">{tier.name}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => toggleTierVisibility(tier.id)}
                        className="p-1 text-gray-400 hover:text-white"
                      >
                        {tier.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => toggleTier(tier.id)}
                        className={`px-2 py-1 rounded text-xs ${
                          tier.enabled 
                            ? 'bg-green-600 hover:bg-green-700 text-white' 
                            : 'bg-gray-600 hover:bg-gray-500 text-gray-300'
                        }`}
                      >
                        {tier.enabled ? 'On' : 'Off'}
                      </button>
                    </div>
                  </div>
                  <div className="text-xs text-gray-400">
                    <p>Height: {tier.height}m • Depth: {tier.benchDepth}m</p>
                    <p>Canopy: {tier.canopyHeight}m</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* 3D View */}
        <div className="flex-1 relative">
          <Room3DWebGL
            roomDimensions={roomDimensions}
            fixtures={fixtures}
            tiers={tiers}
            showGrid={true}
            showLightBeams={true}
            showLabels={false}
            showWireframe={false}
          />
        </div>
        
        {/* Right Sidebar - Metrics */}
        <div className="w-80 bg-gray-900/50 backdrop-blur-xl border-l border-gray-700 p-4 space-y-4">
          <div className="bg-gray-800/50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-white mb-3">System Metrics</h3>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-gray-400">Total Power</p>
                <p className="text-2xl font-bold text-white">{totalPower.toLocaleString()} W</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Total PPF</p>
                <p className="text-2xl font-bold text-white">{totalPPF.toLocaleString()} μmol/s</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">System Efficacy</p>
                <p className="text-2xl font-bold text-white">
                  {totalPower > 0 ? (totalPPF / totalPower).toFixed(2) : '0'} μmol/J
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Growing Area</p>
                <p className="text-2xl font-bold text-white">
                  {(roomDimensions.width * roomDimensions.length).toFixed(1)} m²
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-purple-900/20 rounded-lg p-4 border border-purple-700/30">
            <h3 className="text-sm font-semibold text-white mb-2">Quick Tips</h3>
            <ul className="space-y-2 text-xs text-gray-300">
              <li>• Use mouse to rotate, pan, and zoom</li>
              <li>• Toggle fixtures on/off to see impact</li>
              <li>• Enable PPFD heatmap for coverage</li>
              <li>• Export image for documentation</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}