import { SmartGreenhouseIntegration } from '@/components/SmartGreenhouseIntegration'

export default function GreenhouseIntegrationPage() {
  return <SmartGreenhouseIntegration />
}