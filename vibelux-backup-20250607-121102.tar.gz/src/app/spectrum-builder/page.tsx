import { SpectrumBuilder } from '@/components/SpectrumBuilder'

export default function SpectrumBuilderPage() {
  return <SpectrumBuilder />
}