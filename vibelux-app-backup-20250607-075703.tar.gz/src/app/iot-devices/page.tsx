import { IoTDeviceManagement } from '@/components/IoTDeviceManagement'

export default function IoTDevicesPage() {
  return <IoTDeviceManagement />
}