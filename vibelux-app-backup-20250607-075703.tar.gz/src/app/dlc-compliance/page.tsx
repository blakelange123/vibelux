import { DLCComplianceChecker } from '@/components/DLCComplianceChecker'

export default function DLCCompliancePage() {
  return <DLCComplianceChecker />
}