import { MaintenanceTracker } from '@/components/MaintenanceTracker'

export default function MaintenanceTrackerPage() {
  return <MaintenanceTracker />
}