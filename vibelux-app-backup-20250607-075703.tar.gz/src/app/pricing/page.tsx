'use client'

import Link from 'next/link'
import { useState } from 'react'
import {
  Check,
  X,
  ArrowRight,
  Sparkles,
  Shield,
  Users,
  Building,
  Zap,
  BarChart3,
  Database,
  Brain,
  Cloud,
  Lock,
  Phone,
  Mail,
  MessageSquare,
  Layers,
  FileText,
  Download,
  Globe,
  Settings,
  Activity,
  TrendingUp,
  HelpCircle
} from 'lucide-react'

export default function PricingPage() {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annually'>('monthly')

  const tiers = [
    {
      name: 'Free',
      id: 'free',
      price: { monthly: 0, annually: 0 },
      description: 'Perfect for home growers and hobbyists',
      color: 'gray',
      features: [
        { name: 'Room size', value: 'Up to 100 sq ft', included: true },
        { name: 'Fixtures database', value: '200+ DLC fixtures', included: true },
        { name: 'PPFD analysis', value: 'Basic 2D mapping', included: true },
        { name: 'Export formats', value: 'PDF reports only', included: true },
        { name: 'Multi-tier support', value: 'Single tier only', included: false },
        { name: 'Advanced analytics', value: 'Not included', included: false },
        { name: 'ROI calculations', value: 'Not included', included: false },
        { name: 'API access', value: 'Not included', included: false },
        { name: 'Support', value: 'Community forum', included: true }
      ],
      cta: 'Start Free',
      ctaLink: '/dashboard'
    },
    {
      name: 'Professional',
      id: 'professional',
      price: { monthly: 49, annually: 470 },
      description: 'For growing operations and small farms',
      color: 'purple',
      popular: true,
      features: [
        { name: 'Room size', value: 'Unlimited', included: true },
        { name: 'Fixtures database', value: '1,200+ DLC fixtures', included: true },
        { name: 'PPFD analysis', value: '3D heat mapping', included: true },
        { name: 'Export formats', value: 'PDF, CAD, Excel', included: true },
        { name: 'Multi-tier support', value: 'Up to 10 tiers', included: true },
        { name: 'Advanced analytics', value: 'Full suite included', included: true },
        { name: 'ROI calculations', value: 'NPV, IRR, payback', included: true },
        { name: 'API access', value: 'Read-only access', included: true },
        { name: 'Support', value: 'Email support (24h)', included: true }
      ],
      cta: 'Start Free Trial',
      ctaLink: '/dashboard'
    },
    {
      name: 'Enterprise',
      id: 'enterprise',
      price: { monthly: 199, annually: 1910 },
      description: 'For commercial facilities at scale',
      color: 'yellow',
      features: [
        { name: 'Room size', value: 'Unlimited + multi-site', included: true },
        { name: 'Fixtures database', value: '1,200+ DLC + custom', included: true },
        { name: 'PPFD analysis', value: '3D + spectral analysis', included: true },
        { name: 'Export formats', value: 'All formats + API', included: true },
        { name: 'Multi-tier support', value: 'Unlimited tiers', included: true },
        { name: 'Advanced analytics', value: 'Full + ML predictions', included: true },
        { name: 'ROI calculations', value: 'Full + utility rebates', included: true },
        { name: 'API access', value: 'Full read/write access', included: true },
        { name: 'Support', value: 'Priority + dedicated CSM', included: true }
      ],
      cta: 'Contact Sales',
      ctaLink: '/contact'
    }
  ]

  const allFeatures = [
    {
      category: 'Design & Modeling',
      features: [
        { name: 'Room designer', free: 'Basic shapes', pro: 'All shapes + CAD import', enterprise: 'Multi-site + BIM' },
        { name: 'Fixture placement', free: 'Manual only', pro: 'Auto-optimize', enterprise: 'AI-powered' },
        { name: 'Multi-tier support', free: '—', pro: 'Up to 10 tiers', enterprise: 'Unlimited' },
        { name: '3D visualization', free: '—', pro: '✓', enterprise: '✓ + VR export' }
      ]
    },
    {
      category: 'Lighting Analysis',
      features: [
        { name: 'PPFD mapping', free: 'Basic 2D', pro: '3D heat maps', enterprise: '3D + temporal' },
        { name: 'DLI calculations', free: '✓', pro: '✓', enterprise: '✓' },
        { name: 'Uniformity analysis', free: 'Basic', pro: 'Advanced', enterprise: 'AI-optimized' },
        { name: 'Spectral analysis', free: '—', pro: 'Basic', enterprise: '5nm resolution' }
      ]
    },
    {
      category: 'Financial Tools',
      features: [
        { name: 'Energy cost calc', free: '✓', pro: '✓', enterprise: '✓' },
        { name: 'ROI analysis', free: '—', pro: 'Full NPV/IRR', enterprise: 'Full + scenarios' },
        { name: 'Utility rebates', free: '—', pro: '—', enterprise: '✓' },
        { name: 'TCO modeling', free: '—', pro: 'Basic', enterprise: 'Advanced' }
      ]
    },
    {
      category: 'Data & Integration',
      features: [
        { name: 'Export formats', free: 'PDF', pro: 'PDF, CAD, Excel', enterprise: 'All + custom' },
        { name: 'API access', free: '—', pro: 'Read-only', enterprise: 'Full access' },
        { name: 'Webhooks', free: '—', pro: '—', enterprise: '✓' },
        { name: 'SSO/SAML', free: '—', pro: '—', enterprise: '✓' }
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-vibelux-darker">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-xl border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Vibelux</span>
            </Link>
            <Link href="/dashboard" className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors">
              Get Started
            </Link>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
            Start free and scale as you grow. All plans include a 14-day free trial of Professional features.
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className={`text-sm font-medium ${billingPeriod === 'monthly' ? 'text-white' : 'text-gray-400'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingPeriod(billingPeriod === 'monthly' ? 'annually' : 'monthly')}
              className="relative w-14 h-7 bg-gray-700 rounded-full transition-colors"
            >
              <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                billingPeriod === 'annually' ? 'translate-x-7' : 'translate-x-1'
              }`} />
            </button>
            <span className={`text-sm font-medium ${billingPeriod === 'annually' ? 'text-white' : 'text-gray-400'}`}>
              Annually
              <span className="text-green-400 ml-1">(Save 20%)</span>
            </span>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="pb-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {tiers.map((tier) => (
              <div
                key={tier.id}
                className={`relative rounded-2xl p-8 ${
                  tier.popular
                    ? 'bg-gradient-to-br from-purple-900/50 to-purple-800/30 border-2 border-purple-500'
                    : 'bg-gray-800/50 border border-gray-700'
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-4 py-1 rounded-full text-sm font-semibold text-white">
                      Most Popular
                    </div>
                  </div>
                )}
                
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                  <p className="text-gray-400 mb-6">{tier.description}</p>
                  
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-bold text-white">
                      ${billingPeriod === 'monthly' ? tier.price.monthly : Math.floor(tier.price.annually / 12)}
                    </span>
                    <span className="text-gray-400">/month</span>
                  </div>
                  
                  {billingPeriod === 'annually' && tier.price.annually > 0 && (
                    <p className="text-sm text-gray-500 mt-1">
                      ${tier.price.annually} billed annually
                    </p>
                  )}
                </div>

                <ul className="space-y-4 mb-8">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      {feature.included ? (
                        <Check className="w-5 h-5 text-green-400 mt-0.5" />
                      ) : (
                        <X className="w-5 h-5 text-gray-600 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className={`text-sm ${feature.included ? 'text-gray-300' : 'text-gray-500'}`}>
                          {feature.name}
                        </p>
                        <p className={`text-xs ${feature.included ? 'text-gray-400' : 'text-gray-600'}`}>
                          {feature.value}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>

                <Link
                  href={tier.ctaLink}
                  className={`block w-full text-center px-6 py-3 rounded-lg font-medium transition-all ${
                    tier.popular
                      ? 'bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:shadow-lg hover:shadow-purple-500/25'
                      : tier.id === 'enterprise'
                      ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
                      : 'bg-gray-700 hover:bg-gray-600 text-white'
                  }`}
                >
                  {tier.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Feature Comparison */}
      <section className="py-20 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Detailed Feature Comparison</h2>
            <p className="text-gray-400">Everything you need to know about each plan</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-4 px-4 text-white font-medium">Features</th>
                  <th className="text-center py-4 px-4 text-white font-medium">Free</th>
                  <th className="text-center py-4 px-4 text-white font-medium">
                    <div className="flex items-center justify-center gap-2">
                      Professional
                      <span className="px-2 py-0.5 bg-purple-600 text-xs rounded-full">Popular</span>
                    </div>
                  </th>
                  <th className="text-center py-4 px-4 text-white font-medium">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                {allFeatures.map((category) => (
                  <>
                    <tr key={category.category} className="border-b border-gray-800">
                      <td colSpan={4} className="py-3 px-4">
                        <h4 className="text-sm font-semibold text-purple-400">{category.category}</h4>
                      </td>
                    </tr>
                    {category.features.map((feature) => (
                      <tr key={feature.name} className="border-b border-gray-800">
                        <td className="py-3 px-4 text-sm text-gray-300">{feature.name}</td>
                        <td className="py-3 px-4 text-center text-sm text-gray-400">{feature.free}</td>
                        <td className="py-3 px-4 text-center text-sm text-gray-300 bg-purple-900/10">{feature.pro}</td>
                        <td className="py-3 px-4 text-center text-sm text-gray-300">{feature.enterprise}</td>
                      </tr>
                    ))}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-2">Can I change plans anytime?</h3>
              <p className="text-gray-400">
                Yes! You can upgrade or downgrade your plan at any time. When upgrading, you'll be charged a prorated amount. When downgrading, we'll credit your account.
              </p>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-2">Do you offer educational discounts?</h3>
              <p className="text-gray-400">
                Yes, we offer 50% off Professional plans for educational institutions and students. Contact us with proof of enrollment or employment.
              </p>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-2">What happens to my data if I cancel?</h3>
              <p className="text-gray-400">
                Your data remains accessible for 30 days after cancellation. You can export all your projects and data at any time. After 30 days, data is permanently deleted.
              </p>
            </div>

            <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700">
              <h3 className="text-lg font-semibold text-white mb-2">Is there a limit on team members?</h3>
              <p className="text-gray-400">
                Free plans are limited to 1 user. Professional plans include up to 5 team members. Enterprise plans include unlimited team members with role-based permissions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-b from-vibelux-darker to-vibelux-darkest">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Optimize Your Grow?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of growers using Vibelux to maximize yields and minimize costs
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/dashboard"
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-purple-500/25 transition-all flex items-center justify-center gap-2"
            >
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/contact"
              className="px-8 py-4 bg-gray-800 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Talk to Sales
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 mt-6">
            No credit card required • 14-day free trial • Cancel anytime
          </p>
        </div>
      </section>
    </div>
  )
}