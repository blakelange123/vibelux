import { TCOCalculator } from '@/components/TCOCalculator'

export default function TCOCalculatorPage() {
  return <TCOCalculator />
}