"use client"

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { 
  ArrowRight, 
  Sparkles, 
  Zap, 
  Users, 
  Shield, 
  Check,
  CreditCard,
  BarChart3,
  Brain,
  Database,
  Cloud,
  FileText,
  Globe,
  ChevronRight,
  Sun,
  Leaf,
  TrendingUp,
  Lock,
  Activity,
  Settings,
  Building,
  Layers
} from 'lucide-react'

export default function Home() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-gray-900/95 backdrop-blur-xl shadow-2xl' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-12">
              <Link href="/" className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-white">Vibelux</span>
              </Link>
              
              <div className="hidden lg:flex items-center gap-8">
                <Link href="/features" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Features
                </Link>
                <Link href="/fixtures" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Fixtures
                </Link>
                <Link href="/pricing" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Pricing
                </Link>
                <Link href="/resources" className="text-gray-300 hover:text-white transition-colors font-medium">
                  Resources
                </Link>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Link href="/sign-in" className="hidden md:block text-gray-300 hover:text-white transition-colors font-medium px-4">
                Sign In
              </Link>
              <Link 
                href="/dashboard" 
                className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300"
              >
                Get Started Free
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-24 bg-gradient-to-br from-purple-900/20 via-gray-950 to-gray-950">
        {/* Gradient orb */}
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-purple-600/30 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-purple-700/20 to-transparent rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center space-y-8">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-900/30 to-green-900/30 backdrop-blur-sm rounded-full border border-purple-700/50">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-sm font-semibold text-green-400">NEW</span>
              </div>
              <span className="text-sm font-medium text-purple-200">AI-Powered Multi-Tier Design System</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight tracking-tight">
              <span className="block text-white mb-2">Design Perfect</span>
              <span className="block bg-gradient-to-r from-purple-400 via-purple-500 to-green-400 bg-clip-text text-transparent">
                Grow Light Systems
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              From hobbyist grows to commercial vertical farms - design optimal lighting with AI-powered 
              PPFD mapping, multi-tier racking, and real-time ROI analysis. <span className="text-purple-400 font-semibold">Start free, upgrade as you grow.</span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 justify-center items-center">
              <Link 
                href="/dashboard" 
                className="group relative px-10 py-5 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-2xl font-semibold text-xl hover:shadow-2xl hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105 flex items-center gap-3"
              >
                <span>Start Free Forever</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-600 to-purple-700 blur-xl opacity-50 group-hover:opacity-70 transition-opacity -z-10" />
              </Link>
              <Link 
                href="/pricing" 
                className="px-10 py-5 bg-white/10 backdrop-blur-xl text-white rounded-2xl font-semibold text-xl border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all duration-300"
              >
                View Pricing
              </Link>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-gray-400">
              <span className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Free forever plan
              </span>
              <span className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-green-400" />
                No credit card required
              </span>
              <span className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-green-400" />
                14-day Pro trial
              </span>
              <span className="flex items-center gap-2">
                <Users className="w-4 h-4 text-green-400" />
                10,000+ growers trust us
              </span>
            </div>
          </div>
        </div>
        
        
      </section>

      {/* Pricing Preview Section */}
      <section className="bg-gray-900 py-20 border-y border-gray-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Choose Your Growth Path</h2>
            <p className="text-xl text-gray-400">From hobbyist grows to commercial operations</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Free Tier */}
            <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 relative">
              <div className="text-center">
                <h3 className="text-xl font-bold text-white mb-2">Free</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-white">$0</span>
                  <span className="text-gray-400">/month</span>
                </div>
                <p className="text-gray-400 mb-6">Perfect for home growers</p>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Basic room design (up to 100 sq ft)</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">200+ DLC fixtures</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">PPFD analysis</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">PDF exports</span>
                </li>
              </ul>
              <Link href="/dashboard" className="w-full block text-center px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors">
                Start Free
              </Link>
            </div>

            {/* Professional Tier */}
            <div className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 rounded-2xl p-6 border-2 border-purple-500 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-4 py-1 rounded-full text-xs font-semibold text-white">
                  Most Popular
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-bold text-white mb-2">Professional</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-white">$49</span>
                  <span className="text-gray-400">/month</span>
                </div>
                <p className="text-gray-400 mb-6">For growing operations</p>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Unlimited room size</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">1,200+ DLC fixtures</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Multi-tier design</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Advanced analytics</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">ROI analysis</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Email support</span>
                </li>
              </ul>
              <Link href="/dashboard" className="w-full block text-center px-4 py-3 bg-gradient-to-r from-purple-600 to-purple-700 hover:shadow-lg hover:shadow-purple-500/25 text-white rounded-lg font-medium transition-all">
                Start Free Trial
              </Link>
            </div>

            {/* Enterprise Tier */}
            <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700 relative">
              <div className="text-center">
                <h3 className="text-xl font-bold text-white mb-2">Enterprise</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-white">$199</span>
                  <span className="text-gray-400">/month</span>
                </div>
                <p className="text-gray-400 mb-6">For commercial facilities</p>
              </div>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Everything in Professional</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">API access</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Custom integrations</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Priority support</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">Dedicated account manager</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-gray-300">On-site training</span>
                </li>
              </ul>
              <Link href="/contact" className="w-full block text-center px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors">
                Contact Sales
              </Link>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-400 mb-4">All plans include 14-day free trial • No credit card required</p>
            <Link href="/pricing" className="text-purple-400 hover:text-purple-300 font-medium">
              View detailed pricing comparison →
            </Link>
          </div>
        </div>
      </section>

      {/* Metrics Bar */}
      <section className="bg-gray-950 py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <h3 className="text-4xl font-bold text-purple-400 mb-2">10,000+</h3>
              <p className="text-gray-400">Active Users</p>
              <p className="text-sm text-gray-500 mt-1">Growing daily</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold text-purple-400 mb-2">500M+</h3>
              <p className="text-gray-400">Sq Ft Optimized</p>
              <p className="text-sm text-gray-500 mt-1">Across all facilities</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold text-purple-400 mb-2">32%</h3>
              <p className="text-gray-400">Avg Energy Savings</p>
              <p className="text-sm text-gray-500 mt-1">Verified by customers</p>
            </div>
            <div>
              <h3 className="text-4xl font-bold text-purple-400 mb-2">24/7</h3>
              <p className="text-gray-400">AI Support</p>
              <p className="text-sm text-gray-500 mt-1">Always available</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gray-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Everything You Need to Design World-Class Lighting Systems
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              From small grow rooms to industrial greenhouses, Vibelux provides the tools
              professionals trust
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature Card 1 */}
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 hover:border-purple-700 transition-all duration-300">
              <div className="w-14 h-14 bg-purple-900/50 rounded-xl flex items-center justify-center mb-6">
                <BarChart3 className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Advanced Analytics</h3>
              <p className="text-gray-400 mb-6">
                Real-time PPFD mapping, DLI optimization, and uniformity analysis with 3D heat mapping.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  3D heat mapping
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Multi-layer analysis
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Export to CAD
                </li>
              </ul>
              <div className="mt-4 px-3 py-2 bg-purple-900/30 rounded-lg border border-purple-700/50">
                <p className="text-xs text-purple-300">✨ Available in Professional & Enterprise</p>
              </div>
            </div>
              
            {/* Feature Card 2 */}
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 hover:border-purple-700 transition-all duration-300">
              <div className="w-14 h-14 bg-purple-900/50 rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">AI-Powered Assistant</h3>
              <p className="text-gray-400 mb-6">
                GPT-4 powered lighting advisor with plant health diagnosis and optimization recommendations.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Plant health diagnosis
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Spectrum optimization
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  24/7 expert support
                </li>
              </ul>
              <div className="mt-4 px-3 py-2 bg-green-900/30 rounded-lg border border-green-700/50">
                <p className="text-xs text-green-300">🚀 Available in all plans</p>
              </div>
            </div>

            {/* Feature Card 3 */}
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 hover:border-purple-700 transition-all duration-300">
              <div className="w-14 h-14 bg-purple-900/50 rounded-xl flex items-center justify-center mb-6">
                <Database className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">DLC Database Access</h3>
              <p className="text-gray-400 mb-6">
                Complete access to 1,200+ qualified fixtures with real-time updates and filtering.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Updated daily
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  IES file downloads
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Spectrum analysis
                </li>
              </ul>
              <div className="mt-4 px-3 py-2 bg-blue-900/30 rounded-lg border border-blue-700/50">
                <p className="text-xs text-blue-300">📊 200+ fixtures in Free, 1,200+ in Pro+</p>
              </div>
            </div>

            {/* Feature Card 4 */}
            <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800 hover:border-purple-700 transition-all duration-300">
              <div className="w-14 h-14 bg-purple-900/50 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Financial Analysis</h3>
              <p className="text-gray-400 mb-6">
                Investment-grade ROI calculations with utility rebates and NPV/IRR analysis.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  NPV & IRR analysis
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  Rebate calculator
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-purple-400" />
                  15-year projections
                </li>
              </ul>
              <div className="mt-4 px-3 py-2 bg-yellow-900/30 rounded-lg border border-yellow-700/50">
                <p className="text-xs text-yellow-300">💰 Enterprise exclusive feature</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Tier Comparison Section */}
      <section className="py-24 bg-gradient-to-b from-gray-950 to-vibelux-darker">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Teams Choose Professional
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Unlock the full potential of your growing operation with advanced features
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700">
              <div className="grid md:grid-cols-3 gap-8">
                {/* Feature Comparison */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Layers className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">Multi-Tier Design</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Design vertical farms with up to 10 tiers
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Free</span>
                      <span className="text-gray-500">Single tier only</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-purple-400 font-medium">Professional</span>
                      <span className="text-purple-300 font-medium">Up to 10 tiers</span>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Database className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">Fixture Database</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Access to DLC-qualified fixtures
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Free</span>
                      <span className="text-gray-500">200+ fixtures</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-purple-400 font-medium">Professional</span>
                      <span className="text-purple-300 font-medium">1,200+ fixtures</span>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">Analytics & Export</h3>
                  <p className="text-gray-400 text-sm mb-4">
                    Advanced reporting capabilities
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Free</span>
                      <span className="text-gray-500">Basic PDF</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-purple-400 font-medium">Professional</span>
                      <span className="text-purple-300 font-medium">CAD, Excel, API</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-gray-700 text-center">
                <p className="text-gray-400 mb-4">
                  Professional users save an average of <span className="text-purple-400 font-bold">8 hours per project</span> and achieve <span className="text-green-400 font-bold">32% better uniformity</span>
                </p>
                <Link 
                  href="/dashboard" 
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-lg font-medium hover:shadow-lg hover:shadow-purple-500/25 transition-all"
                >
                  Start 14-Day Free Trial
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="relative py-32 bg-gradient-to-b from-vibelux-darker to-vibelux-dark">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Start Optimizing in Minutes
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Our intuitive platform guides you through professional lighting design step by step
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-12">
            {/* Step 1 */}
            <div className="relative">
              <div className="absolute -left-4 top-0 text-8xl font-bold text-vibelux-purple/10">01</div>
              <div className="relative z-10 pt-8">
                <div className="w-16 h-16 bg-gradient-to-br from-vibelux-purple to-vibelux-purple-dark rounded-2xl flex items-center justify-center mb-6 shadow-2xl">
                  <Settings className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Define Your Space</h3>
                <p className="text-gray-400 mb-6">Input room dimensions, crop type, and growth stage. Our AI automatically suggests optimal parameters.</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    3D room builder
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Multi-tier support
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Import CAD files
                  </li>
                </ul>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="absolute -left-4 top-0 text-8xl font-bold text-vibelux-green/10">02</div>
              <div className="relative z-10 pt-8">
                <div className="w-16 h-16 bg-gradient-to-br from-vibelux-green to-vibelux-green-dark rounded-2xl flex items-center justify-center mb-6 shadow-2xl">
                  <Database className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Select Fixtures</h3>
                <p className="text-gray-400 mb-6">Choose from 2,436 DLC-qualified fixtures or add custom models. Compare efficiency and spectrum.</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Advanced filtering
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Side-by-side comparison
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Spectral analysis
                  </li>
                </ul>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="absolute -left-4 top-0 text-8xl font-bold text-vibelux-purple/10">03</div>
              <div className="relative z-10 pt-8">
                <div className="w-16 h-16 bg-gradient-to-br from-vibelux-purple to-vibelux-purple-dark rounded-2xl flex items-center justify-center mb-6 shadow-2xl">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Optimize & Analyze</h3>
                <p className="text-gray-400 mb-6">AI optimizes placement for uniform coverage. View PPFD maps, energy costs, and ROI projections.</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Real-time 3D visualization
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Energy cost analysis
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-vibelux-green" />
                    Export reports
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-24 bg-gradient-to-b from-vibelux-dark to-vibelux-darker">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Built for Every Growing Operation
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              From personal gardens to commercial facilities, we have the right plan for you
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Home Growers */}
            <div className="bg-gray-800/30 rounded-2xl p-8 border border-gray-700 hover:border-green-600 transition-all">
              <div className="w-12 h-12 bg-green-900/50 rounded-xl flex items-center justify-center mb-4">
                <Leaf className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Home Growers</h3>
              <p className="text-gray-400 mb-4">
                Perfect for hobbyists and personal cultivation in small spaces
              </p>
              <ul className="space-y-2 mb-6">
                <li className="text-sm text-gray-300">• Grow tents up to 10x10 ft</li>
                <li className="text-sm text-gray-300">• 1-10 fixtures</li>
                <li className="text-sm text-gray-300">• Basic PPFD optimization</li>
                <li className="text-sm text-gray-300">• Energy cost tracking</li>
              </ul>
              <div className="px-4 py-2 bg-green-900/20 rounded-lg border border-green-700/30">
                <p className="text-sm text-green-400 font-medium">Free Plan</p>
              </div>
            </div>

            {/* Small Farms */}
            <div className="bg-gradient-to-br from-purple-900/20 to-purple-800/10 rounded-2xl p-8 border-2 border-purple-600 relative">
              <div className="absolute -top-3 -right-3">
                <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-3 py-1 rounded-full text-xs font-semibold text-white">
                  Recommended
                </div>
              </div>
              <div className="w-12 h-12 bg-purple-900/50 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Growing Operations</h3>
              <p className="text-gray-400 mb-4">
                Ideal for small to medium commercial grows and greenhouses
              </p>
              <ul className="space-y-2 mb-6">
                <li className="text-sm text-gray-300">• Rooms up to 50,000 sq ft</li>
                <li className="text-sm text-gray-300">• Multi-tier vertical systems</li>
                <li className="text-sm text-gray-300">• Advanced analytics & ROI</li>
                <li className="text-sm text-gray-300">• Utility rebate optimization</li>
              </ul>
              <div className="px-4 py-2 bg-purple-900/20 rounded-lg border border-purple-700/30">
                <p className="text-sm text-purple-400 font-medium">Professional Plan - $49/mo</p>
              </div>
            </div>

            {/* Large Facilities */}
            <div className="bg-gray-800/30 rounded-2xl p-8 border border-gray-700 hover:border-yellow-600 transition-all">
              <div className="w-12 h-12 bg-yellow-900/50 rounded-xl flex items-center justify-center mb-4">
                <Building className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Commercial Facilities</h3>
              <p className="text-gray-400 mb-4">
                Enterprise solutions for large-scale cultivation operations
              </p>
              <ul className="space-y-2 mb-6">
                <li className="text-sm text-gray-300">• Unlimited facility size</li>
                <li className="text-sm text-gray-300">• Multi-site management</li>
                <li className="text-sm text-gray-300">• API & custom integrations</li>
                <li className="text-sm text-gray-300">• Dedicated support team</li>
              </ul>
              <div className="px-4 py-2 bg-yellow-900/20 rounded-lg border border-yellow-700/30">
                <p className="text-sm text-yellow-400 font-medium">Enterprise Plan - $199/mo</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="relative py-32 bg-vibelux-dark">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Loved by Professional Growers
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Join thousands of facilities optimizing their operations with Vibelux
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
              <div className="flex items-center gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-vibelux-purple" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-300 mb-6 italic">
                "Vibelux helped us reduce energy costs by 32% while increasing yields. The PPFD mapping is incredibly accurate."
              </p>
              <div>
                <div className="font-semibold text-white">Sarah Chen</div>
                <div className="text-sm text-gray-400">Head of Cultivation, Green Valley Farms</div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
              <div className="flex items-center gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-vibelux-green" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-300 mb-6 italic">
                "The AI recommendations are spot-on. We've optimized our entire facility in just two weeks."
              </p>
              <div>
                <div className="font-semibold text-white">Marcus Thompson</div>
                <div className="text-sm text-gray-400">Operations Director, Urban Grow Co.</div>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
              <div className="flex items-center gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-5 h-5 text-vibelux-purple" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-300 mb-6 italic">
                "Best lighting design platform we've used. The DLC database integration saves hours of research."
              </p>
              <div>
                <div className="font-semibold text-white">Jennifer Park</div>
                <div className="text-sm text-gray-400">Facility Manager, Bloom Industries</div>
              </div>
            </div>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-vibelux-purple/20 to-vibelux-purple/10 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Shield className="w-10 h-10 text-vibelux-purple" />
              </div>
              <h3 className="font-bold text-white mb-1">SOC 2 Type II</h3>
              <p className="text-sm text-gray-400">Enterprise security</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-vibelux-green/20 to-vibelux-green/10 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Lock className="w-10 h-10 text-vibelux-green" />
              </div>
              <h3 className="font-bold text-white mb-1">GDPR Compliant</h3>
              <p className="text-sm text-gray-400">Data protection</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-vibelux-purple/20 to-vibelux-purple/10 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Zap className="w-10 h-10 text-vibelux-purple" />
              </div>
              <h3 className="font-bold text-white mb-1">99.9% Uptime</h3>
              <p className="text-sm text-gray-400">Always available</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-vibelux-green/20 to-vibelux-green/10 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Globe className="w-10 h-10 text-vibelux-green" />
              </div>
              <h3 className="font-bold text-white mb-1">Global CDN</h3>
              <p className="text-sm text-gray-400">Fast everywhere</p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="relative py-32 bg-gradient-to-b from-vibelux-dark to-vibelux-darkest overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-[800px] h-[800px] bg-gradient-to-br from-vibelux-purple/20 to-transparent rounded-full blur-3xl animate-float" />
          <div className="absolute -bottom-40 -left-40 w-[800px] h-[800px] bg-gradient-to-tr from-vibelux-green/20 to-transparent rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }} />
        </div>
        
        <div className="relative max-w-5xl mx-auto px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white">
              Ready to Optimize Your
              <span className="block bg-gradient-to-r from-vibelux-purple to-vibelux-green bg-clip-text text-transparent mt-2">
                Growing Operation?
              </span>
            </h2>
            
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto">
              Join 10,000+ professional growers using Vibelux to maximize yields and minimize costs
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 justify-center items-center pt-8">
              <Link 
                href="/dashboard" 
                className="group relative px-12 py-6 bg-gradient-to-r from-vibelux-purple to-vibelux-purple-dark text-white rounded-2xl font-semibold text-xl hover:shadow-2xl hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105 flex items-center gap-3"
              >
                <span>Start Your Free Trial</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-vibelux-purple to-vibelux-purple-dark blur-xl opacity-50 group-hover:opacity-70 transition-opacity -z-10" />
              </Link>
              <Link 
                href="/contact" 
                className="px-12 py-6 bg-white/10 backdrop-blur-xl text-white rounded-2xl font-semibold text-xl border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all duration-300"
              >
                Schedule a Demo
              </Link>
            </div>
            
            <div className="flex items-center justify-center gap-8 text-gray-400 pt-8">
              <span className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                10,000+ users
              </span>
              <span className="flex items-center gap-2">
                <Leaf className="w-5 h-5" />
                500M+ sq ft optimized
              </span>
              <span className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                32% avg energy savings
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-vibelux-dark border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 mb-12">
            {/* Logo and Description */}
            <div className="col-span-2">
              <Link href="/" className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-vibelux-purple to-vibelux-green rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-white">Vibelux</span>
              </Link>
              <p className="text-gray-400 mb-6">
                Professional horticultural lighting design platform trusted by 10,000+ growers worldwide.
              </p>
              <div className="flex items-center gap-4">
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                  </svg>
                </a>
                <a href="#" className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                </a>
              </div>
            </div>
            
            {/* Product */}
            <div>
              <h4 className="font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-3">
                <li><Link href="/features" className="text-gray-400 hover:text-white transition-colors">Features</Link></li>
                <li><Link href="/pricing" className="text-gray-400 hover:text-white transition-colors">Pricing</Link></li>
                <li><Link href="/integrations" className="text-gray-400 hover:text-white transition-colors">Integrations</Link></li>
                <li><Link href="/api" className="text-gray-400 hover:text-white transition-colors">API</Link></li>
              </ul>
            </div>
            
            {/* Resources */}
            <div>
              <h4 className="font-semibold text-white mb-4">Resources</h4>
              <ul className="space-y-3">
                <li><Link href="/docs" className="text-gray-400 hover:text-white transition-colors">Documentation</Link></li>
                <li><Link href="/tutorials" className="text-gray-400 hover:text-white transition-colors">Tutorials</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link></li>
                <li><Link href="/community" className="text-gray-400 hover:text-white transition-colors">Community</Link></li>
              </ul>
            </div>
            
            {/* Company */}
            <div>
              <h4 className="font-semibold text-white mb-4">Company</h4>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors">About</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="/careers" className="text-gray-400 hover:text-white transition-colors">Careers</Link></li>
                <li><Link href="/press" className="text-gray-400 hover:text-white transition-colors">Press</Link></li>
              </ul>
            </div>
            
            {/* Support */}
            <div>
              <h4 className="font-semibold text-white mb-4">Support</h4>
              <ul className="space-y-3">
                <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="/status" className="text-gray-400 hover:text-white transition-colors">Status</Link></li>
                <li><Link href="/security" className="text-gray-400 hover:text-white transition-colors">Security</Link></li>
                <li><Link href="/legal" className="text-gray-400 hover:text-white transition-colors">Legal</Link></li>
              </ul>
            </div>
          </div>
          
          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="text-gray-400">
                © 2024 Vibelux, Inc. All rights reserved.
              </div>
              <div className="flex items-center gap-6 text-sm">
                <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</Link>
                <Link href="/terms" className="text-gray-400 hover:text-white transition-colors">Terms of Service</Link>
                <Link href="/cookies" className="text-gray-400 hover:text-white transition-colors">Cookie Policy</Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}