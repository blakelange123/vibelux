import type { Tier } from '@/components/MultiLayerCanopyPanel';

export interface FixtureAssignment {
  fixtureId: string;
  assignedTiers: string[];
  mountingHeight: number; // Height of fixture above ground
  intensity: number; // PPF output
  beamAngle: number;
  position: { x: number; y: number };
}

export interface TierLightingAnalysis {
  tierId: string;
  tierName: string;
  benchHeight: number;
  canopyHeight: number;
  targetPPFD: number;
  actualPPFD: number;
  uniformity: number;
  coveragePercent: number;
  ppfReceived: number;
  shadowingFactor: number; // How much light is blocked by upper tiers
  energyEfficiency: number; // PPFD per watt
  recommendedFixtures: number;
  lightingGaps: Array<{ x: number; y: number; deficitPPFD: number }>;
}

export interface MultiTierLightingResult {
  tiers: TierLightingAnalysis[];
  totalEnergyConsumption: number;
  overallEfficiency: number;
  systemUniformity: number;
  recommendations: string[];
  fixturePlacements: Array<{
    position: { x: number; y: number; z: number };
    targetTiers: string[];
    intensity: number;
    beamAngle: number;
  }>;
}

/**
 * Calculate light distribution and shadowing effects for multi-tier systems
 */
export function calculateMultiTierLighting(
  tiers: Tier[],
  fixtures: FixtureAssignment[],
  roomDimensions: { width: number; height: number; depth: number },
  gridResolution: number = 50
): MultiTierLightingResult {
  // Sort tiers from top to bottom for shadowing calculations
  const sortedTiers = [...tiers].sort((a, b) => b.height - a.height);
  
  const tierAnalyses: TierLightingAnalysis[] = [];
  const recommendations: string[] = [];

  // Calculate lighting for each tier
  for (const tier of sortedTiers) {
    const tierAnalysis = calculateTierLighting(
      tier,
      fixtures,
      sortedTiers,
      roomDimensions,
      gridResolution
    );
    tierAnalyses.push(tierAnalysis);

    // Generate recommendations for this tier
    if (tierAnalysis.actualPPFD < tier.targetPPFD * 0.8) {
      recommendations.push(
        `${tier.name}: Increase lighting by ${Math.ceil(tierAnalysis.recommendedFixtures - getCurrentFixtureCount(tier.id, fixtures))} fixtures`
      );
    }

    if (tierAnalysis.uniformity < 0.7) {
      recommendations.push(
        `${tier.name}: Poor uniformity (${(tierAnalysis.uniformity * 100).toFixed(0)}%). Consider repositioning fixtures.`
      );
    }

    if (tierAnalysis.shadowingFactor > 0.3) {
      recommendations.push(
        `${tier.name}: Significant shadowing from upper tiers (${(tierAnalysis.shadowingFactor * 100).toFixed(0)}% light loss)`
      );
    }
  }

  // Calculate system-wide metrics
  const totalEnergyConsumption = fixtures.reduce((sum, fixture) => {
    // Assume 2.5 μmol/J efficiency and convert PPF to watts
    return sum + (fixture.intensity / 2.5);
  }, 0);

  const totalPPFDelivered = tierAnalyses.reduce((sum, tier) => sum + tier.ppfReceived, 0);
  const overallEfficiency = totalPPFDelivered / Math.max(totalEnergyConsumption, 1);

  const systemUniformity = tierAnalyses.reduce((sum, tier) => sum + tier.uniformity, 0) / tierAnalyses.length;

  // Generate optimal fixture placements
  const fixturePlacements = generateOptimalFixturePlacements(
    sortedTiers,
    roomDimensions
  );

  return {
    tiers: tierAnalyses,
    totalEnergyConsumption,
    overallEfficiency,
    systemUniformity,
    recommendations,
    fixturePlacements
  };
}

/**
 * Calculate lighting analysis for a single tier considering shadowing
 */
function calculateTierLighting(
  tier: Tier,
  fixtures: FixtureAssignment[],
  allTiers: Tier[],
  roomDimensions: { width: number; height: number; depth: number },
  gridResolution: number
): TierLightingAnalysis {
  const grid: number[][] = [];\n  const tiersAbove = allTiers.filter(t => t.height > tier.height);\n  \n  // Create PPFD grid for this tier\n  for (let y = 0; y < gridResolution; y++) {\n    const row: number[] = [];\n    for (let x = 0; x < gridResolution; x++) {\n      const worldX = (x / gridResolution) * roomDimensions.width;\n      const worldY = (y / gridResolution) * roomDimensions.height;\n      \n      let totalPPFD = 0;\n      let shadowingFactor = 0;\n      \n      // Calculate contribution from each fixture\n      for (const fixture of fixtures) {\n        if (fixture.assignedTiers.includes(tier.id)) {\n          const distance = Math.sqrt(\n            Math.pow(worldX - fixture.position.x, 2) +\n            Math.pow(worldY - fixture.position.y, 2) +\n            Math.pow((tier.height + tier.canopyHeight/24) - fixture.mountingHeight, 2)\n          );\n          \n          // Calculate base PPFD using inverse square law with beam angle consideration\n          const beamRadius = Math.tan((fixture.beamAngle * Math.PI / 180) / 2) * fixture.mountingHeight;\n          const beamFactor = Math.exp(-Math.pow(distance / beamRadius, 2));\n          const basePPFD = (fixture.intensity * beamFactor) / Math.max(Math.pow(distance, 2), 1);\n          \n          // Calculate shadowing from upper tiers\n          const shadows = calculateShadowing(\n            { x: worldX, y: worldY, z: tier.height + tier.canopyHeight/24 },\n            fixture,\n            tiersAbove\n          );\n          \n          shadowingFactor = Math.max(shadowingFactor, shadows.shadowFactor);\n          totalPPFD += basePPFD * (1 - shadows.shadowFactor);\n        }\n      }\n      \n      row.push(totalPPFD);\n    }\n    grid.push(row);\n  }\n  \n  // Calculate metrics from grid\n  const flatGrid = grid.flat();\n  const actualPPFD = flatGrid.reduce((sum, val) => sum + val, 0) / flatGrid.length;\n  const minPPFD = Math.min(...flatGrid);\n  const maxPPFD = Math.max(...flatGrid);\n  const uniformity = maxPPFD > 0 ? minPPFD / maxPPFD : 0;\n  \n  const targetThreshold = tier.targetPPFD * 0.8;\n  const coveragePercent = flatGrid.filter(val => val >= targetThreshold).length / flatGrid.length;\n  \n  // Calculate total PPF received by this tier\n  const tierArea = tier.benchDepth * roomDimensions.width;\n  const ppfReceived = actualPPFD * tierArea * 0.092903; // Convert ft² to m²\n  \n  // Estimate required fixtures\n  const deficitPPFD = Math.max(0, tier.targetPPFD - actualPPFD);\n  const recommendedFixtures = Math.ceil((deficitPPFD * tierArea * 0.092903) / 1600); // Assuming 1600 PPF per fixture\n  \n  // Find lighting gaps\n  const lightingGaps: Array<{ x: number; y: number; deficitPPFD: number }> = [];\n  for (let y = 0; y < gridResolution; y += 5) {\n    for (let x = 0; x < gridResolution; x += 5) {\n      if (grid[y][x] < targetThreshold) {\n        lightingGaps.push({\n          x: (x / gridResolution) * roomDimensions.width,\n          y: (y / gridResolution) * roomDimensions.height,\n          deficitPPFD: targetThreshold - grid[y][x]\n        });\n      }\n    }\n  }\n  \n  const averageShadowing = flatGrid.reduce((sum, val, idx) => {\n    const maxPossible = calculateMaxPossiblePPFD(\n      idx % gridResolution,\n      Math.floor(idx / gridResolution),\n      fixtures.filter(f => f.assignedTiers.includes(tier.id)),\n      tier,\n      roomDimensions,\n      gridResolution\n    );\n    return sum + (maxPossible > 0 ? 1 - (val / maxPossible) : 0);\n  }, 0) / flatGrid.length;\n  \n  return {\n    tierId: tier.id,\n    tierName: tier.name,\n    benchHeight: tier.height,\n    canopyHeight: tier.canopyHeight,\n    targetPPFD: tier.targetPPFD,\n    actualPPFD,\n    uniformity,\n    coveragePercent,\n    ppfReceived,\n    shadowingFactor: averageShadowing,\n    energyEfficiency: actualPPFD / Math.max(getCurrentFixtureWattage(tier.id, fixtures), 1),\n    recommendedFixtures,\n    lightingGaps\n  };\n}\n\n/**\n * Calculate shadowing effects from upper tiers\n */\nfunction calculateShadowing(\n  point: { x: number; y: number; z: number },\n  fixture: FixtureAssignment,\n  upperTiers: Tier[]\n): { shadowFactor: number; blockedBy: string[] } {\n  let maxShadowFactor = 0;\n  const blockedBy: string[] = [];\n  \n  for (const upperTier of upperTiers) {\n    // Check if light ray from fixture to point passes through this upper tier\n    const rayDirection = {\n      x: point.x - fixture.position.x,\n      y: point.y - fixture.position.y,\n      z: point.z - fixture.mountingHeight\n    };\n    \n    const rayLength = Math.sqrt(\n      rayDirection.x * rayDirection.x +\n      rayDirection.y * rayDirection.y +\n      rayDirection.z * rayDirection.z\n    );\n    \n    if (rayLength === 0) continue;\n    \n    // Normalize ray direction\n    rayDirection.x /= rayLength;\n    rayDirection.y /= rayLength;\n    rayDirection.z /= rayLength;\n    \n    // Check intersection with upper tier plane\n    const tierZ = upperTier.height + upperTier.canopyHeight/12;\n    if (tierZ > point.z && tierZ < fixture.mountingHeight) {\n      const t = (tierZ - point.z) / rayDirection.z;\n      const intersectionX = point.x + rayDirection.x * t;\n      const intersectionY = point.y + rayDirection.y * t;\n      \n      // Check if intersection is within the tier bounds\n      const tierBounds = getTierBounds(upperTier);\n      if (intersectionX >= tierBounds.minX && intersectionX <= tierBounds.maxX &&\n          intersectionY >= tierBounds.minY && intersectionY <= tierBounds.maxY) {\n        \n        // Calculate shadow factor based on canopy density and transmittance\n        const shadowFactor = (1 - upperTier.transmittance) * (upperTier.canopyDensity / 100);\n        if (shadowFactor > maxShadowFactor) {\n          maxShadowFactor = shadowFactor;\n          blockedBy.push(upperTier.name);\n        }\n      }\n    }\n  }\n  \n  return { shadowFactor: maxShadowFactor, blockedBy };\n}\n\n/**\n * Get the 2D bounds of a tier in the room\n */\nfunction getTierBounds(tier: Tier): { minX: number; maxX: number; minY: number; maxY: number } {\n  // For now, assume tier spans the full width of the room\n  // In a real implementation, you might have more specific tier positioning\n  return {\n    minX: 0,\n    maxX: 10, // This should come from room dimensions\n    minY: 0,\n    maxY: tier.benchDepth\n  };\n}\n\n/**\n * Calculate maximum possible PPFD at a point without shadowing\n */\nfunction calculateMaxPossiblePPFD(\n  gridX: number,\n  gridY: number,\n  fixtures: FixtureAssignment[],\n  tier: Tier,\n  roomDimensions: { width: number; height: number; depth: number },\n  gridResolution: number\n): number {\n  const worldX = (gridX / gridResolution) * roomDimensions.width;\n  const worldY = (gridY / gridResolution) * roomDimensions.height;\n  \n  let totalPPFD = 0;\n  \n  for (const fixture of fixtures) {\n    const distance = Math.sqrt(\n      Math.pow(worldX - fixture.position.x, 2) +\n      Math.pow(worldY - fixture.position.y, 2) +\n      Math.pow((tier.height + tier.canopyHeight/24) - fixture.mountingHeight, 2)\n    );\n    \n    const beamRadius = Math.tan((fixture.beamAngle * Math.PI / 180) / 2) * fixture.mountingHeight;\n    const beamFactor = Math.exp(-Math.pow(distance / beamRadius, 2));\n    totalPPFD += (fixture.intensity * beamFactor) / Math.max(Math.pow(distance, 2), 1);\n  }\n  \n  return totalPPFD;\n}\n\n/**\n * Get current number of fixtures assigned to a tier\n */\nfunction getCurrentFixtureCount(tierId: string, fixtures: FixtureAssignment[]): number {\n  return fixtures.filter(f => f.assignedTiers.includes(tierId)).length;\n}\n\n/**\n * Get total wattage of fixtures assigned to a tier\n */\nfunction getCurrentFixtureWattage(tierId: string, fixtures: FixtureAssignment[]): number {\n  return fixtures\n    .filter(f => f.assignedTiers.includes(tierId))\n    .reduce((sum, f) => sum + (f.intensity / 2.5), 0); // Convert PPF to watts\n}\n\n/**\n * Generate optimal fixture placements for multi-tier system\n */\nfunction generateOptimalFixturePlacements(\n  tiers: Tier[],\n  roomDimensions: { width: number; height: number; depth: number }\n): Array<{\n  position: { x: number; y: number; z: number };\n  targetTiers: string[];\n  intensity: number;\n  beamAngle: number;\n}> {\n  const placements: Array<{\n    position: { x: number; y: number; z: number };\n    targetTiers: string[];\n    intensity: number;\n    beamAngle: number;\n  }> = [];\n  \n  // Sort tiers by height\n  const sortedTiers = [...tiers].sort((a, b) => a.height - b.height);\n  \n  for (let i = 0; i < sortedTiers.length; i++) {\n    const tier = sortedTiers[i];\n    const nextTier = sortedTiers[i + 1];\n    \n    // Calculate optimal mounting height for this tier\n    const maxCanopyHeight = tier.height + tier.canopyHeight/12;\n    const minNextTierHeight = nextTier ? nextTier.height : roomDimensions.depth;\n    const optimalHeight = maxCanopyHeight + Math.min(3, (minNextTierHeight - maxCanopyHeight) * 0.7);\n    \n    // Calculate fixture spacing based on tier area and target PPFD\n    const tierArea = tier.benchDepth * roomDimensions.width;\n    const requiredPPF = tier.targetPPFD * tierArea * 0.092903;\n    const fixturesNeeded = Math.ceil(requiredPPF / 1600); // Assuming 1600 PPF per fixture\n    \n    // Distribute fixtures evenly across the tier\n    const fixturesPerRow = Math.ceil(Math.sqrt(fixturesNeeded));\n    const spacing = roomDimensions.width / (fixturesPerRow + 1);\n    \n    for (let row = 0; row < Math.ceil(fixturesNeeded / fixturesPerRow); row++) {\n      for (let col = 0; col < fixturesPerRow && (row * fixturesPerRow + col) < fixturesNeeded; col++) {\n        placements.push({\n          position: {\n            x: spacing * (col + 1),\n            y: tier.benchDepth / 2,\n            z: optimalHeight\n          },\n          targetTiers: [tier.id],\n          intensity: 1600,\n          beamAngle: 120\n        });\n      }\n    }\n  }\n  \n  return placements;\n}\n\n/**\n * Calculate inter-tier spacing requirements\n */\nexport function calculateTierSpacing(\n  lowerTier: Tier,\n  upperTier: Tier,\n  fixtureHeight: number = 6 // inches\n): {\n  minimumSpacing: number;\n  recommendedSpacing: number;\n  clearanceIssues: string[];\n} {\n  const clearanceIssues: string[] = [];\n  \n  // Minimum clearance for maintenance access\n  const maintenanceClearance = 18; // inches\n  \n  // Clearance needed for plant growth\n  const plantClearance = lowerTier.canopyHeight;\n  \n  // Clearance for fixtures\n  const fixtureClearance = fixtureHeight + 6; // 6\" buffer\n  \n  const minimumSpacing = Math.max(\n    maintenanceClearance,\n    plantClearance + fixtureClearance\n  );\n  \n  const actualSpacing = (upperTier.height - lowerTier.height) * 12; // Convert to inches\n  \n  if (actualSpacing < minimumSpacing) {\n    clearanceIssues.push(\n      `Insufficient spacing: ${actualSpacing}\" < ${minimumSpacing}\" minimum`\n    );\n  }\n  \n  if (actualSpacing < plantClearance + 6) {\n    clearanceIssues.push(\n      `Risk of plant damage: Only ${actualSpacing - plantClearance}\" clearance above canopy`\n    );\n  }\n  \n  const recommendedSpacing = minimumSpacing + 12; // Add 12\" buffer\n  \n  return {\n    minimumSpacing,\n    recommendedSpacing,\n    clearanceIssues\n  };\n}\n\n/**\n * Calculate photosynthetic photon flux density (PPFD) considering spectral quality\n */\nexport function calculateSpectralPPFD(\n  basePPFD: number,\n  spectrum: { red: number; blue: number; green: number; farRed: number },\n  cropType: string,\n  growthStage: string\n): {\n  effectivePPFD: number;\n  spectralQuality: number;\n  recommendations: string[];\n} {\n  const recommendations: string[] = [];\n  \n  // Crop-specific spectral response curves\n  const spectralWeights = getSpectralWeights(cropType, growthStage);\n  \n  // Calculate effective PPFD based on spectral composition\n  const effectivePPFD = basePPFD * (\n    (spectrum.red / 100) * spectralWeights.red +\n    (spectrum.blue / 100) * spectralWeights.blue +\n    (spectrum.green / 100) * spectralWeights.green +\n    (spectrum.farRed / 100) * spectralWeights.farRed\n  );\n  \n  // Calculate overall spectral quality score\n  const idealSpectrum = getIdealSpectrum(cropType, growthStage);\n  const spectralQuality = calculateSpectralMatch(spectrum, idealSpectrum);\n  \n  // Generate recommendations\n  if (spectrum.blue < idealSpectrum.blue * 0.8) {\n    recommendations.push('Increase blue light for better leaf development');\n  }\n  \n  if (spectrum.red < idealSpectrum.red * 0.8) {\n    recommendations.push('Increase red light for enhanced photosynthesis');\n  }\n  \n  if (spectrum.farRed > idealSpectrum.farRed * 1.2) {\n    recommendations.push('Consider reducing far-red to prevent stem elongation');\n  }\n  \n  return {\n    effectivePPFD,\n    spectralQuality,\n    recommendations\n  };\n}\n\nfunction getSpectralWeights(cropType: string, growthStage: string) {\n  // Simplified spectral response weights\n  const baseWeights = { red: 1.0, blue: 0.8, green: 0.5, farRed: 0.3 };\n  \n  if (growthStage === 'seedling') {\n    return { ...baseWeights, blue: 1.0, red: 0.8 };\n  } else if (growthStage === 'flowering') {\n    return { ...baseWeights, red: 1.2, farRed: 0.4 };\n  }\n  \n  return baseWeights;\n}\n\nfunction getIdealSpectrum(cropType: string, growthStage: string) {\n  // Simplified ideal spectrum percentages\n  const defaults = { red: 65, blue: 20, green: 10, farRed: 5 };\n  \n  if (cropType.toLowerCase().includes('lettuce') || cropType.toLowerCase().includes('leafy')) {\n    return { red: 60, blue: 25, green: 12, farRed: 3 };\n  } else if (cropType.toLowerCase().includes('tomato')) {\n    return { red: 70, blue: 15, green: 10, farRed: 5 };\n  }\n  \n  return defaults;\n}\n\nfunction calculateSpectralMatch(\n  actual: { red: number; blue: number; green: number; farRed: number },\n  ideal: { red: number; blue: number; green: number; farRed: number }\n): number {\n  const differences = [\n    Math.abs(actual.red - ideal.red) / ideal.red,\n    Math.abs(actual.blue - ideal.blue) / ideal.blue,\n    Math.abs(actual.green - ideal.green) / ideal.green,\n    Math.abs(actual.farRed - ideal.farRed) / ideal.farRed\n  ];\n  \n  const averageDifference = differences.reduce((sum, diff) => sum + diff, 0) / differences.length;\n  return Math.max(0, 1 - averageDifference);\n}