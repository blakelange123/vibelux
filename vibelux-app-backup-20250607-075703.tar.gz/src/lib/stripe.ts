import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-11-20.acacia',
  typescript: true,
});

export const getStripeJs = () => {
  if (typeof window === 'undefined') {
    return null;
  }
  
  return import('@stripe/stripe-js').then(({ loadStripe }) =>
    loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)
  );
};

// Pricing plans
export const PRICING_PLANS = {
  free: {
    id: 'free',
    name: 'Free',
    description: 'Perfect for hobbyists and small projects',
    price: 0,
    interval: null,
    features: [
      'Up to 3 active projects',
      'Basic PPFD calculator',
      'Access to 100 DLC fixtures',
      'Community support',
      'PDF export',
    ],
    limitations: {
      projects: 3,
      fixtures: 100,
      users: 1,
      exportFormats: ['pdf'],
    }
  },
  pro: {
    id: 'pro',
    name: 'Professional',
    description: 'For professional growers and consultants',
    price: 29,
    interval: 'month',
    stripePriceId: process.env.STRIPE_PRO_PRICE_ID,
    features: [
      'Unlimited projects',
      'Full DLC fixture database',
      'Advanced spectrum analysis',
      'Multi-layer canopy design',
      'Priority email support',
      'CAD & IES export',
      'API access',
      'Custom branding',
    ],
    limitations: {
      projects: -1, // unlimited
      fixtures: -1,
      users: 5,
      exportFormats: ['pdf', 'cad', 'ies', 'csv'],
    }
  },
  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For large-scale operations and teams',
    price: 99,
    interval: 'month',
    stripePriceId: process.env.STRIPE_ENTERPRISE_PRICE_ID,
    features: [
      'Everything in Professional',
      'Unlimited team members',
      'White-label options',
      'Custom integrations',
      'Dedicated account manager',
      'Phone support',
      'SLA guarantee',
      'Custom training',
      'Bulk fixture pricing',
    ],
    limitations: {
      projects: -1,
      fixtures: -1,
      users: -1,
      exportFormats: ['pdf', 'cad', 'ies', 'csv', 'api'],
    }
  }
};

export type PricingPlan = typeof PRICING_PLANS[keyof typeof PRICING_PLANS];