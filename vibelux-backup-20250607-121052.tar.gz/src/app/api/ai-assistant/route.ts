import { NextRequest, NextResponse } from 'next/server'

const OPENAI_API_KEY = process.env.OPENAI_API_KEY
const OPENAI_ORG_ID = process.env.OPENAI_ORG_ID

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json()
    
    if (!OPENAI_API_KEY) {
      return NextResponse.json(
        { error: 'OpenAI API key not configured' },
        { status: 500 }
      )
    }
    
    // Prepare the system message with context about Vibelux
    const systemMessage = {
      role: 'system',
      content: `You are the Vibelux AI Assistant, an expert in horticultural lighting design. You help users with:
- Lighting design and fixture placement
- PPFD (Photosynthetic Photon Flux Density) calculations
- DLI (Daily Light Integral) optimization
- Fixture selection from DLC (DesignLights Consortium) database
- Energy efficiency and ROI calculations
- Multi-tier growing system design
- Spectrum optimization for different crops and growth stages

Key information:
- Optimal PPFD ranges: Seedlings (100-300), Vegetative (400-600), Flowering/Fruiting (600-900) μmol/m²/s
- DLI calculation: PPFD × photoperiod hours × 0.0036
- System efficacy target: >2.5 μmol/J for modern LED fixtures
- Typical mounting heights: 18-36 inches above canopy

Be helpful, accurate, and provide specific recommendations based on the user's needs.`
    }
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'OpenAI-Organization': OPENAI_ORG_ID || ''
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        messages: [systemMessage, ...messages],
        temperature: 0.7,
        max_tokens: 500,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0
      })
    })
    
    if (!response.ok) {
      const error = await response.json()
      console.error('OpenAI API error:', error)
      return NextResponse.json(
        { error: 'Failed to get AI response' },
        { status: response.status }
      )
    }
    
    const data = await response.json()
    const content = data.choices[0]?.message?.content || 'Sorry, I could not generate a response.'
    
    return NextResponse.json({ content })
  } catch (error) {
    console.error('AI Assistant error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}