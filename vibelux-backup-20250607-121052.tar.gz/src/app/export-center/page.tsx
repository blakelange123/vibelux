import { AdvancedExportCenter } from '@/components/AdvancedExportCenter'

export default function ExportCenterPage() {
  return <AdvancedExportCenter />
}