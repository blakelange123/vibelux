"use client"

import { useState } from 'react'
import Link from 'next/link'
import { 
  Calculator, 
  Lightbulb, 
  Sun, 
  Zap, 
  Clock, 
  TrendingUp,
  DollarSign,
  Leaf,
  Map,
  ArrowRight,
  Sparkles
} from 'lucide-react'

export default function CalculatorsPage() {
  const [ppfd, setPpfd] = useState(500)
  const [photoperiod, setPhotoperiod] = useState(16)
  const [targetDLI, setTargetDLI] = useState(20)
  const [dliPhotoperiod, setDliPhotoperiod] = useState(16)
  const [currentDLI, setCurrentDLI] = useState(15)
  const [selectedCrop, setSelectedCrop] = useState('lettuce')
  const [wattage, setWattage] = useState(600)
  const [fixtureCount, setFixtureCount] = useState(10)
  const [hoursPerDay, setHoursPerDay] = useState(16)
  const [electricityRate, setElectricityRate] = useState(0.12)

  // Calculations
  const calculatedDLI = (ppfd * photoperiod * 0.0036).toFixed(1)
  const requiredPPFD = Math.round(targetDLI / (dliPhotoperiod * 0.0036))
  const totalPower = wattage * fixtureCount
  const dailyEnergy = (totalPower * hoursPerDay) / 1000
  const dailyCost = dailyEnergy * electricityRate
  const monthlyCost = dailyCost * 30
  const yearlyCost = dailyCost * 365

  // Crop data
  const cropData: Record<string, { min: number, optimal: number, max: number, photoperiodVeg: number, photoperiodFlower: number }> = {
    lettuce: { min: 12, optimal: 17, max: 25, photoperiodVeg: 16, photoperiodFlower: 12 },
    spinach: { min: 10, optimal: 15, max: 20, photoperiodVeg: 14, photoperiodFlower: 12 },
    kale: { min: 12, optimal: 17, max: 25, photoperiodVeg: 16, photoperiodFlower: 12 },
    basil: { min: 12, optimal: 16, max: 22, photoperiodVeg: 16, photoperiodFlower: 12 },
    tomato: { min: 20, optimal: 30, max: 40, photoperiodVeg: 18, photoperiodFlower: 12 },
    pepper: { min: 20, optimal: 30, max: 40, photoperiodVeg: 18, photoperiodFlower: 12 },
    cucumber: { min: 20, optimal: 30, max: 35, photoperiodVeg: 18, photoperiodFlower: 12 },
    strawberry: { min: 15, optimal: 20, max: 25, photoperiodVeg: 16, photoperiodFlower: 12 },
    cannabis_veg: { min: 18, optimal: 24, max: 35, photoperiodVeg: 18, photoperiodFlower: 12 },
    cannabis_flower: { min: 30, optimal: 45, max: 60, photoperiodVeg: 18, photoperiodFlower: 12 },
    microgreens: { min: 8, optimal: 12, max: 15, photoperiodVeg: 16, photoperiodFlower: 16 },
    wheatgrass: { min: 8, optimal: 12, max: 15, photoperiodVeg: 16, photoperiodFlower: 16 },
    petunia: { min: 10, optimal: 15, max: 20, photoperiodVeg: 14, photoperiodFlower: 12 },
    chrysanthemum: { min: 15, optimal: 20, max: 25, photoperiodVeg: 16, photoperiodFlower: 12 },
    orchid: { min: 5, optimal: 10, max: 15, photoperiodVeg: 12, photoperiodFlower: 12 }
  }

  const currentCropData = cropData[selectedCrop]
  const dliDeficit = currentCropData.optimal - Number(currentDLI)
  const dliPosition = ((Number(currentDLI) - currentCropData.min) / (currentCropData.max - currentCropData.min)) * 100

  const getCropStatus = () => {
    if (Number(currentDLI) < currentCropData.min) return { status: 'Critical', color: 'red', icon: '⚠️' }
    if (Number(currentDLI) < currentCropData.optimal) return { status: 'Deficient', color: 'yellow', icon: '↓' }
    if (Number(currentDLI) > currentCropData.max) return { status: 'Excessive', color: 'orange', icon: '↑' }
    return { status: 'Optimal', color: 'green', icon: '✓' }
  }

  const cropStatus = getCropStatus()

  const getPPFDGradientPosition = () => {
    return (ppfd / 2000) * 100
  }

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Dark gradient background */}
      <div className="fixed inset-0 bg-gradient-to-br from-purple-900/20 via-gray-950 to-green-900/20" />
      
      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <div className="bg-gray-900/80 backdrop-blur-xl border-b border-gray-800">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl shadow-lg shadow-purple-500/25">
                <Calculator className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                  Lighting Calculators
                </h1>
                <p className="text-gray-400 mt-1">Professional tools for PPFD, DLI, and energy calculations</p>
              </div>
            </div>
          </div>
        </div>

        {/* Hero Section - Heat Map */}
        <div className="container mx-auto px-4 py-8">
          <Link href="/calculators/ppfd-map">
            <div className="relative group cursor-pointer">
              {/* Animated gradient border */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition-opacity animate-pulse" />
              
              <div className="relative bg-gray-900/90 backdrop-blur-xl rounded-3xl p-8 border border-gray-700 hover:border-gray-600 transition-all">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-3 bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl">
                        <Map className="w-8 h-8 text-white" />
                      </div>
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-yellow-400" />
                        <span className="text-yellow-400 font-medium">Advanced Tool</span>
                      </div>
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-3">PPFD Heat Map Visualizer</h2>
                    <p className="text-gray-300 text-lg mb-4">
                      Create interactive 3D heat maps of your lighting layout. Visualize coverage, uniformity, and optimize fixture placement.
                    </p>
                    <div className="flex items-center gap-6 text-sm text-gray-400">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                        <span>Multi-fixture support</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                        <span>Real-time uniformity</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                        <span>Export ready</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Heat map preview */}
                  <div className="hidden lg:block">
                    <div className="relative">
                      <div className="absolute inset-0 bg-gradient-to-br from-yellow-500 to-red-500 rounded-xl blur-2xl opacity-50" />
                      <div className="relative bg-gray-900/50 backdrop-blur rounded-xl p-4 border border-gray-700">
                        <div className="grid grid-cols-8 gap-1">
                          {Array.from({ length: 64 }, (_, i) => (
                            <div
                              key={i}
                              className="w-3 h-3 rounded-sm animate-pulse"
                              style={{
                                backgroundColor: `hsl(${280 - i * 3}, 70%, ${50 + (i % 8) * 5}%)`,
                                animationDelay: `${i * 50}ms`
                              }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex items-center gap-2 text-white group-hover:gap-3 transition-all">
                  <span className="font-medium">Open Heat Map Tool</span>
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Calculator Grid */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* PPFD to DLI Calculator */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-3xl blur-xl" />
              <div className="relative bg-gray-900/80 backdrop-blur-xl rounded-3xl border border-gray-700 overflow-hidden">
                <div className="bg-gradient-to-br from-purple-600/80 to-pink-600/80 p-6 backdrop-blur">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-white/20 backdrop-blur rounded-xl">
                      <Lightbulb className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold text-white">PPFD to DLI Calculator</h2>
                      <p className="text-purple-100 text-sm">Convert photon flux to daily light integral</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">PPFD (μmol/m²/s)</label>
                    <div className="relative">
                      <input
                        type="range"
                        min="0"
                        max="2000"
                        value={ppfd}
                        onChange={(e) => setPpfd(Number(e.target.value))}
                        className="w-full h-3 bg-gradient-to-r from-blue-600 via-purple-600 to-red-600 rounded-lg appearance-none cursor-pointer"
                        style={{
                          background: `linear-gradient(to right, #3B82F6 0%, #8B5CF6 50%, #EF4444 100%)`
                        }}
                      />
                      <div 
                        className="absolute -top-8 transform -translate-x-1/2 bg-purple-600 text-white text-xs rounded py-1 px-2"
                        style={{ left: `${getPPFDGradientPosition()}%` }}
                      >
                        {ppfd}
                      </div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>Low Light</span>
                      <span>Seedlings</span>
                      <span>Vegetative</span>
                      <span>Flowering</span>
                      <span>High Light</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Photoperiod (hours)</label>
                    <div className="grid grid-cols-6 gap-2">
                      {[8, 12, 14, 16, 18, 24].map((hours) => (
                        <button
                          key={hours}
                          onClick={() => setPhotoperiod(hours)}
                          className={`py-2 rounded-lg font-medium transition-all ${
                            photoperiod === hours
                              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25'
                              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
                          }`}
                        >
                          {hours}h
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl blur-xl opacity-50" />
                    <div className="relative bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl p-8 text-center text-white shadow-2xl">
                      <p className="text-purple-100 mb-2">Daily Light Integral</p>
                      <p className="text-6xl font-bold mb-2">{calculatedDLI}</p>
                      <p className="text-purple-100">mol/m²/day</p>
                      <div className="mt-4 pt-4 border-t border-white/20">
                        <p className="text-sm text-purple-200">
                          {ppfd} μmol/m²/s × {photoperiod} hours × 0.0036
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* DLI to PPFD Calculator */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-3xl blur-xl" />
              <div className="relative bg-gray-900/80 backdrop-blur-xl rounded-3xl border border-gray-700 overflow-hidden">
                <div className="bg-gradient-to-br from-green-600/80 to-emerald-600/80 p-6 backdrop-blur">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-white/20 backdrop-blur rounded-xl">
                      <Sun className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold text-white">DLI to PPFD Calculator</h2>
                      <p className="text-green-100 text-sm">Calculate required PPFD for target DLI</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Target DLI (mol/m²/day)</label>
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      {[
                        { label: 'Low', value: 12 },
                        { label: 'Medium', value: 20 },
                        { label: 'High', value: 30 },
                        { label: 'Very High', value: 40 }
                      ].map((preset) => (
                        <button
                          key={preset.value}
                          onClick={() => setTargetDLI(preset.value)}
                          className={`py-2 rounded-lg text-xs font-medium transition-all ${
                            targetDLI === preset.value
                              ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white shadow-lg shadow-green-500/25'
                              : 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
                          }`}
                        >
                          {preset.label}
                          <div className="text-xs opacity-80">{preset.value}</div>
                        </button>
                      ))}
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="60"
                      value={targetDLI}
                      onChange={(e) => setTargetDLI(Number(e.target.value))}
                      className="w-full h-3 bg-gradient-to-r from-yellow-600 via-green-600 to-red-600 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Photoperiod (hours)</label>
                    <input
                      type="range"
                      min="0"
                      max="24"
                      value={dliPhotoperiod}
                      onChange={(e) => setDliPhotoperiod(Number(e.target.value))}
                      className="w-full h-3 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="text-center mt-2 text-2xl font-bold text-white">
                      {dliPhotoperiod} hours
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-green-600 to-emerald-600 rounded-2xl blur-xl opacity-50" />
                    <div className="relative bg-gradient-to-br from-green-600 to-emerald-600 rounded-2xl p-8 text-center text-white shadow-2xl">
                      <p className="text-green-100 mb-2">Required PPFD</p>
                      <p className="text-6xl font-bold mb-2">{requiredPPFD}</p>
                      <p className="text-green-100">μmol/m²/s</p>
                      <div className="mt-4 pt-4 border-t border-white/20">
                        <p className="text-sm text-green-200">
                          {targetDLI} mol ÷ ({dliPhotoperiod}h × 0.0036)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Crop DLI Analysis */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/20 to-teal-600/20 rounded-3xl blur-xl" />
              <div className="relative bg-gray-900/80 backdrop-blur-xl rounded-3xl border border-gray-700 overflow-hidden">
                <div className="bg-gradient-to-br from-emerald-600/80 to-teal-600/80 p-6 backdrop-blur">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-white/20 backdrop-blur rounded-xl">
                      <Leaf className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold text-white">Crop DLI Analysis</h2>
                      <p className="text-emerald-100 text-sm">Compare current DLI to crop requirements</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Select Crop</label>
                    <select
                      value={selectedCrop}
                      onChange={(e) => setSelectedCrop(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-xl text-white focus:border-emerald-500 focus:outline-none transition-colors"
                    >
                      <option value="lettuce" className="bg-gray-900">Lettuce (Leafy Greens)</option>
                      <option value="spinach" className="bg-gray-900">Spinach (Leafy Greens)</option>
                      <option value="kale" className="bg-black">Kale (Leafy Greens)</option>
                      <option value="basil" className="bg-black">Basil (Herbs)</option>
                      <option value="tomato" className="bg-black">Tomato (Fruiting)</option>
                      <option value="pepper" className="bg-black">Pepper (Fruiting)</option>
                      <option value="cucumber" className="bg-black">Cucumber (Fruiting)</option>
                      <option value="strawberry" className="bg-black">Strawberry (Fruiting)</option>
                      <option value="cannabis_veg" className="bg-black">Cannabis Veg (Cannabis)</option>
                      <option value="cannabis_flower" className="bg-black">Cannabis Flower (Cannabis)</option>
                      <option value="microgreens" className="bg-black">Microgreens (Microgreens)</option>
                      <option value="wheatgrass" className="bg-black">Wheatgrass (Microgreens)</option>
                      <option value="petunia" className="bg-black">Petunia (Ornamentals)</option>
                      <option value="chrysanthemum" className="bg-black">Chrysanthemum (Ornamentals)</option>
                      <option value="orchid" className="bg-black">Orchid (Ornamentals)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Current DLI (mol/m²/day)</label>
                    <input
                      type="number"
                      value={currentDLI}
                      onChange={(e) => setCurrentDLI(Number(e.target.value))}
                      className="w-full px-4 py-3 bg-white/5 border-2 border-white/10 rounded-xl text-white focus:border-emerald-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div className="relative">
                    <div className="mb-2 flex justify-between text-xs text-gray-400">
                      <span>Minimum ({currentCropData.min})</span>
                      <span className="font-medium text-white">Optimal ({currentCropData.optimal})</span>
                      <span>Maximum ({currentCropData.max})</span>
                    </div>
                    <div className="relative h-8 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="absolute h-full bg-gradient-to-r from-red-500 to-yellow-500"
                        style={{ left: '0%', width: `${(currentCropData.min / currentCropData.max) * 100}%` }}
                      />
                      <div 
                        className="absolute h-full bg-gradient-to-r from-green-500 to-green-600"
                        style={{ 
                          left: `${(currentCropData.min / currentCropData.max) * 100}%`, 
                          width: `${((currentCropData.optimal - currentCropData.min) / currentCropData.max) * 100}%` 
                        }}
                      />
                      <div 
                        className="absolute h-full bg-gradient-to-r from-yellow-500 to-orange-500"
                        style={{ 
                          left: `${(currentCropData.optimal / currentCropData.max) * 100}%`, 
                          width: `${((currentCropData.max - currentCropData.optimal) / currentCropData.max) * 100}%` 
                        }}
                      />
                      <div 
                        className="absolute top-1/2 transform -translate-y-1/2 -translate-x-1/2"
                        style={{ left: `${dliPosition}%` }}
                      >
                        <div className="relative">
                          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-xs rounded-full px-2 py-1 font-medium">
                            {currentDLI}
                          </div>
                          <div className="w-4 h-4 bg-blue-600 rounded-full border-2 border-white shadow-lg" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={`rounded-xl p-6 border-2 ${
                    cropStatus.color === 'green' ? 'bg-green-500/10 border-green-500/30' :
                    cropStatus.color === 'yellow' ? 'bg-yellow-500/10 border-yellow-500/30' :
                    cropStatus.color === 'orange' ? 'bg-orange-500/10 border-orange-500/30' :
                    'bg-red-500/10 border-red-500/30'
                  }`}>
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`p-2 rounded-lg ${
                        cropStatus.color === 'green' ? 'bg-green-500/20' :
                        cropStatus.color === 'yellow' ? 'bg-yellow-500/20' :
                        cropStatus.color === 'orange' ? 'bg-orange-500/20' :
                        'bg-red-500/20'
                      }`}>
                        {cropStatus.icon}
                      </div>
                      <h4 className={`font-semibold text-lg ${
                        cropStatus.color === 'green' ? 'text-green-400' :
                        cropStatus.color === 'yellow' ? 'text-yellow-400' :
                        cropStatus.color === 'orange' ? 'text-orange-400' :
                        'text-red-400'
                      }`}>
                        {cropStatus.status} Light Levels
                      </h4>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Target DLI:</span>
                        <p className="font-semibold text-lg text-white">{currentCropData.optimal} mol/m²/day</p>
                      </div>
                      <div>
                        <span className="text-gray-400">Deficit:</span>
                        <p className="font-semibold text-lg text-white">
                          {dliDeficit.toFixed(1)} mol ({((dliDeficit / currentCropData.optimal) * 100).toFixed(0)}%)
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-blue-600/10 to-indigo-600/10 rounded-xl p-4 border border-blue-500/20">
                    <p className="font-medium text-blue-400 mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Photoperiod Recommendation
                    </p>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="bg-gray-800/50 rounded-lg p-3">
                        <span className="text-gray-400">Vegetative:</span>
                        <p className="font-semibold text-white">{currentCropData.photoperiodVeg} hours</p>
                      </div>
                      <div className="bg-gray-800/50 rounded-lg p-3">
                        <span className="text-gray-400">Flowering:</span>
                        <p className="font-semibold text-white">{currentCropData.photoperiodFlower} hours</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Energy Cost Calculator */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/20 to-orange-600/20 rounded-3xl blur-xl" />
              <div className="relative bg-black/80 backdrop-blur-xl rounded-3xl border border-white/10 overflow-hidden">
                <div className="bg-gradient-to-br from-yellow-600/80 to-orange-600/80 p-6 backdrop-blur">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-white/20 backdrop-blur rounded-xl">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold text-white">Energy Cost Calculator</h2>
                      <p className="text-yellow-100 text-sm">Estimate lighting electricity costs</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Fixture Wattage</label>
                      <div className="relative">
                        <input
                          type="number"
                          value={wattage}
                          onChange={(e) => setWattage(Number(e.target.value))}
                          className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-xl text-white focus:border-yellow-500 focus:outline-none transition-colors"
                        />
                        <span className="absolute right-3 top-3 text-gray-500">W</span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Number of Fixtures</label>
                      <input
                        type="number"
                        value={fixtureCount}
                        onChange={(e) => setFixtureCount(Number(e.target.value))}
                        className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-xl text-white focus:border-yellow-500 focus:outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Daily Hours</label>
                      <input
                        type="number"
                        value={hoursPerDay}
                        onChange={(e) => setHoursPerDay(Number(e.target.value))}
                        className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-xl text-white focus:border-yellow-500 focus:outline-none transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">$/kWh</label>
                      <div className="relative">
                        <span className="absolute left-3 top-3 text-gray-500">$</span>
                        <input
                          type="number"
                          step="0.01"
                          value={electricityRate}
                          onChange={(e) => setElectricityRate(Number(e.target.value))}
                          className="w-full pl-8 pr-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-xl text-white focus:border-yellow-500 focus:outline-none transition-colors"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 mt-6">
                    <div className="bg-gradient-to-br from-yellow-600/20 to-yellow-700/20 rounded-xl p-4 text-center border border-yellow-500/20">
                      <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                      <p className="text-xs text-yellow-400 mb-1">Daily Cost</p>
                      <p className="text-2xl font-bold text-white">${dailyCost.toFixed(2)}</p>
                    </div>
                    <div className="bg-gradient-to-br from-orange-600/20 to-orange-700/20 rounded-xl p-4 text-center border border-orange-500/20">
                      <TrendingUp className="w-6 h-6 text-orange-400 mx-auto mb-2" />
                      <p className="text-xs text-orange-400 mb-1">Monthly Cost</p>
                      <p className="text-2xl font-bold text-white">${monthlyCost.toFixed(2)}</p>
                    </div>
                    <div className="bg-gradient-to-br from-red-600/20 to-red-700/20 rounded-xl p-4 text-center border border-red-500/20">
                      <DollarSign className="w-6 h-6 text-red-400 mx-auto mb-2" />
                      <p className="text-xs text-red-400 mb-1">Yearly Cost</p>
                      <p className="text-2xl font-bold text-white">${yearlyCost.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="bg-gray-800/50 rounded-xl p-4 space-y-2 border border-gray-700">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Total System Power:</span>
                      <span className="font-semibold text-white">{totalPower.toLocaleString()}W</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Daily Energy:</span>
                      <span className="font-semibold text-white">{dailyEnergy.toFixed(2)} kWh</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Monthly Energy:</span>
                      <span className="font-semibold text-white">{(dailyEnergy * 30).toFixed(2)} kWh</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Reference Guide */}
        <div className="container mx-auto px-4 py-12">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-900/50 to-green-900/50 rounded-3xl blur-xl" />
            <div className="relative bg-gray-900/80 backdrop-blur-xl rounded-3xl border border-gray-700 p-8">
              <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-green-400 mb-6 text-center">
                Quick Reference Guide
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-gray-800/50 backdrop-blur rounded-xl p-4 border border-gray-700">
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-white">
                    <Lightbulb className="w-5 h-5 text-yellow-400" />
                    Common PPFD Levels
                  </h4>
                  <ul className="text-sm space-y-2 text-gray-300">
                    <li className="flex justify-between">
                      <span>Seedlings:</span>
                      <span className="font-medium text-white">100-300</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Vegetative:</span>
                      <span className="font-medium text-white">300-600</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Flowering:</span>
                      <span className="font-medium text-white">600-1000</span>
                    </li>
                    <li className="flex justify-between">
                      <span>High Light:</span>
                      <span className="font-medium text-white">1000+</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white/5 backdrop-blur rounded-xl p-4 border border-white/10">
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-white">
                    <Sun className="w-5 h-5 text-yellow-400" />
                    DLI Categories
                  </h4>
                  <ul className="text-sm space-y-2 text-gray-300">
                    <li className="flex justify-between">
                      <span>Low:</span>
                      <span className="font-medium text-white">5-10</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Medium:</span>
                      <span className="font-medium text-white">10-20</span>
                    </li>
                    <li className="flex justify-between">
                      <span>High:</span>
                      <span className="font-medium text-white">20-30</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Very High:</span>
                      <span className="font-medium text-white">30+</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white/5 backdrop-blur rounded-xl p-4 border border-white/10">
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-white">
                    <Calculator className="w-5 h-5 text-yellow-400" />
                    Key Formulas
                  </h4>
                  <ul className="text-sm space-y-2 text-gray-300">
                    <li>DLI = PPFD × Hours × 0.0036</li>
                    <li>PPFD = DLI ÷ (Hours × 0.0036)</li>
                    <li>1 mol = 1,000,000 μmol</li>
                    <li>Hours = DLI ÷ (PPFD × 0.0036)</li>
                  </ul>
                </div>

                <div className="bg-white/5 backdrop-blur rounded-xl p-4 border border-white/10">
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-white">
                    <Leaf className="w-5 h-5 text-green-400" />
                    Common Crop DLI
                  </h4>
                  <ul className="text-sm space-y-2 text-gray-300">
                    <li className="flex justify-between">
                      <span>Leafy Greens:</span>
                      <span className="font-medium text-white">12-17</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Herbs:</span>
                      <span className="font-medium text-white">10-16</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Fruiting:</span>
                      <span className="font-medium text-white">20-30</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Cannabis:</span>
                      <span className="font-medium text-white">25-50</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}