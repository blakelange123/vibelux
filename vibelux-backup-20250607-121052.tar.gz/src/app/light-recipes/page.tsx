import { LightRecipeManager } from '@/components/LightRecipeManager'

export default function LightRecipesPage() {
  return <LightRecipeManager />
}