import { auth } from "@clerk/nextjs/server"
import { redirect } from "next/navigation"
import Link from "next/link"
import { FeatureShowcase } from "@/components/FeatureShowcase"

export default async function DashboardPage() {
  const session = await auth()
  
  if (!session?.userId) {
    redirect("/sign-in")
  }

  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-white">Dashboard</h1>
      
      {/* Key metrics (Feature 22, 23) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all">
          <div className="text-sm text-gray-400 mb-2">Active Projects</div>
          <div className="text-3xl font-bold text-white mb-1">0</div>
          <div className="text-sm text-purple-400">Start your first project</div>
        </div>
        
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all">
          <div className="text-sm text-gray-400 mb-2">Saved Fixtures</div>
          <div className="text-3xl font-bold text-white mb-1">0</div>
          <div className="text-sm text-purple-400">Browse fixture database</div>
        </div>
        
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all">
          <div className="text-sm text-gray-400 mb-2">Reports Generated</div>
          <div className="text-3xl font-bold text-white mb-1">0</div>
          <div className="text-sm text-purple-400">Create your first report</div>
        </div>
        
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all">
          <div className="text-sm text-gray-400 mb-2">Subscription</div>
          <div className="text-3xl font-bold text-white mb-1">Free</div>
          <div className="text-sm text-purple-400">Upgrade for more features</div>
        </div>
      </div>

      {/* Quick actions (Feature 24) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all group">
          <h3 className="font-semibold mb-2 text-white">New Project</h3>
          <p className="text-sm text-gray-400 mb-4">
            Start a new lighting design project
          </p>
          <button className="text-purple-400 text-sm font-medium hover:text-purple-300 transition-colors group-hover:translate-x-1 inline-flex items-center gap-1">
            Create Project →
          </button>
        </div>
        
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all group">
          <h3 className="font-semibold mb-2 text-white">Browse Fixtures</h3>
          <p className="text-sm text-gray-400 mb-4">
            Explore DLC qualified fixtures
          </p>
          <Link href="/fixtures">
            <button className="text-purple-400 text-sm font-medium hover:text-purple-300 transition-colors group-hover:translate-x-1 inline-flex items-center gap-1">
              View Fixtures →
            </button>
          </Link>
        </div>
        
        <div className="glass-card p-6 rounded-xl hover:shadow-purple-lg transition-all group">
          <h3 className="font-semibold mb-2 text-white">PPFD Calculator</h3>
          <p className="text-sm text-gray-400 mb-4">
            Calculate light distribution
          </p>
          <Link href="/calculators">
            <button className="text-purple-400 text-sm font-medium hover:text-purple-300 transition-colors group-hover:translate-x-1 inline-flex items-center gap-1">
              Open Calculator →
            </button>
          </Link>
        </div>
      </div>

      {/* Feature Showcase */}
      <div className="mt-8">
        <FeatureShowcase />
      </div>
    </div>
  )
}