"use client"

import { useState, useRef } from 'react'
import { 
  FileText, 
  Plus, 
  Filter, 
  BarChart3, 
  PieChart, 
  LineChart,
  Table,
  Calendar,
  Download,
  Save,
  Share2,
  Clock,
  DollarSign,
  Zap,
  Leaf,
  Eye,
  Settings,
  ChevronRight,
  X,
  Move,
  Copy,
  Trash2,
  Cloud,
  FileDown,
  CheckCircle,
  Image as ImageIcon,
  Type,
  Grid,
  Palette
} from 'lucide-react'
import { SalesforceIntegration } from './SalesforceIntegration'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart as RechartsLineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts'

interface ReportWidget {
  id: string
  type: 'chart' | 'table' | 'metric' | 'text' | 'image'
  chartType?: 'line' | 'bar' | 'pie' | 'area'
  title: string
  dataSource: string
  config: {
    color?: string
    showLegend?: boolean
    showGrid?: boolean
    data?: any[]
    text?: string
    imageUrl?: string
    metric?: {
      value: number
      unit: string
      change: number
      trend: 'up' | 'down' | 'stable'
    }
  }
  position: { x: number; y: number; w: number; h: number }
}

interface ReportTemplate {
  id: string
  name: string
  description: string
  widgets: ReportWidget[]
  category: string
  lastModified: Date
}

interface DataSource {
  id: string
  name: string
  type: string
  icon: React.FC<any>
  fields: string[]
}

// Sample data for charts
const sampleData = {
  energy: [
    { name: 'Jan', consumption: 4000, cost: 2400, efficiency: 85 },
    { name: 'Feb', consumption: 3000, cost: 1398, efficiency: 87 },
    { name: 'Mar', consumption: 2000, cost: 9800, efficiency: 89 },
    { name: 'Apr', consumption: 2780, cost: 3908, efficiency: 91 },
    { name: 'May', consumption: 1890, cost: 4800, efficiency: 93 },
    { name: 'Jun', consumption: 2390, cost: 3800, efficiency: 94 }
  ],
  production: [
    { name: 'Week 1', yield: 120, quality: 95 },
    { name: 'Week 2', yield: 132, quality: 96 },
    { name: 'Week 3', yield: 141, quality: 94 },
    { name: 'Week 4', yield: 134, quality: 97 }
  ],
  pie: [
    { name: 'Lighting', value: 35, color: '#8884d8' },
    { name: 'HVAC', value: 25, color: '#82ca9d' },
    { name: 'Water', value: 20, color: '#ffc658' },
    { name: 'Other', value: 20, color: '#ff7c7c' }
  ]
}

export function EnhancedCustomReportingBuilder() {
  const reportRef = useRef<HTMLDivElement>(null)
  const [activeReport, setActiveReport] = useState<ReportTemplate | null>(null)
  const [widgets, setWidgets] = useState<ReportWidget[]>([])
  const [selectedWidget, setSelectedWidget] = useState<string | null>(null)
  const [reportName, setReportName] = useState('New Report')
  const [showDataPanel, setShowDataPanel] = useState(true)
  const [draggedWidget, setDraggedWidget] = useState<string | null>(null)
  const [showSalesforce, setShowSalesforce] = useState(false)
  const [generatingPDF, setGeneratingPDF] = useState(false)
  const [reportTheme, setReportTheme] = useState({
    primaryColor: '#6366f1',
    backgroundColor: '#ffffff',
    textColor: '#111827',
    fontFamily: 'Inter'
  })

  const reportTemplates: ReportTemplate[] = [
    {
      id: '1',
      name: 'Energy Efficiency Report',
      description: 'Track energy usage and costs across facilities',
      widgets: [],
      category: 'Energy',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 24)
    },
    {
      id: '2',
      name: 'Crop Yield Analysis',
      description: 'Monitor yield trends and optimize production',
      widgets: [],
      category: 'Production',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 48)
    },
    {
      id: '3',
      name: 'Monthly Operations Summary',
      description: 'Comprehensive overview of monthly performance',
      widgets: [],
      category: 'Operations',
      lastModified: new Date(Date.now() - 1000 * 60 * 60 * 72)
    }
  ]

  const dataSources: DataSource[] = [
    {
      id: 'energy',
      name: 'Energy Metrics',
      type: 'timeseries',
      icon: Zap,
      fields: ['power', 'energy', 'cost', 'efficiency', 'peak_demand']
    },
    {
      id: 'production',
      name: 'Production Data',
      type: 'aggregate',
      icon: Leaf,
      fields: ['yield', 'quality', 'harvest_date', 'crop_type', 'area']
    },
    {
      id: 'financial',
      name: 'Financial Data',
      type: 'aggregate',
      icon: DollarSign,
      fields: ['revenue', 'costs', 'profit', 'roi', 'payback']
    },
    {
      id: 'environmental',
      name: 'Environmental',
      type: 'timeseries',
      icon: Leaf,
      fields: ['temperature', 'humidity', 'co2', 'vpd', 'dli']
    }
  ]

  const widgetTypes = [
    { id: 'line-chart', type: 'chart', chartType: 'line', name: 'Line Chart', icon: LineChart },
    { id: 'bar-chart', type: 'chart', chartType: 'bar', name: 'Bar Chart', icon: BarChart3 },
    { id: 'pie-chart', type: 'chart', chartType: 'pie', name: 'Pie Chart', icon: PieChart },
    { id: 'area-chart', type: 'chart', chartType: 'area', name: 'Area Chart', icon: BarChart3 },
    { id: 'data-table', type: 'table', name: 'Data Table', icon: Table },
    { id: 'metric-card', type: 'metric', name: 'Metric Card', icon: FileText },
    { id: 'text-block', type: 'text', name: 'Text Block', icon: Type },
    { id: 'image-block', type: 'image', name: 'Image', icon: ImageIcon }
  ]

  const addWidget = (typeId: string) => {
    const widgetType = widgetTypes.find(w => w.id === typeId)
    if (!widgetType) return

    const newWidget: ReportWidget = {
      id: Date.now().toString(),
      type: widgetType.type as any,
      chartType: widgetType.chartType as any,
      title: `New ${widgetType.name}`,
      dataSource: '',
      config: {
        color: reportTheme.primaryColor,
        showLegend: true,
        showGrid: true,
        data: widgetType.type === 'chart' ? sampleData.energy : undefined,
        metric: widgetType.type === 'metric' ? {
          value: 1250,
          unit: 'kWh',
          change: 12.5,
          trend: 'up'
        } : undefined
      },
      position: { x: 0, y: 0, w: 4, h: 3 }
    }

    setWidgets([...widgets, newWidget])
    setSelectedWidget(newWidget.id)
  }

  const updateWidget = (widgetId: string, updates: Partial<ReportWidget>) => {
    setWidgets(widgets.map(w => 
      w.id === widgetId ? { ...w, ...updates } : w
    ))
  }

  const deleteWidget = (widgetId: string) => {
    setWidgets(widgets.filter(w => w.id !== widgetId))
    if (selectedWidget === widgetId) {
      setSelectedWidget(null)
    }
  }

  const duplicateWidget = (widgetId: string) => {
    const widget = widgets.find(w => w.id === widgetId)
    if (!widget) return

    const newWidget: ReportWidget = {
      ...widget,
      id: Date.now().toString(),
      position: {
        ...widget.position,
        x: widget.position.x + 1,
        y: widget.position.y + 1
      }
    }

    setWidgets([...widgets, newWidget])
  }

  const generatePDFReport = async () => {
    setGeneratingPDF(true)
    try {
      const pdf = new jsPDF('p', 'mm', 'a4')
      const pageWidth = pdf.internal.pageSize.getWidth()
      const pageHeight = pdf.internal.pageSize.getHeight()
      
      // Title Page
      pdf.setFillColor(103, 58, 183)
      pdf.rect(0, 0, pageWidth, 60, 'F')
      
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(28)
      pdf.text(reportName, pageWidth / 2, 30, { align: 'center' })
      
      pdf.setFontSize(14)
      pdf.text(`Generated on ${new Date().toLocaleDateString()}`, pageWidth / 2, 45, { align: 'center' })
      
      // Executive Summary
      pdf.setTextColor(0, 0, 0)
      pdf.setFontSize(18)
      pdf.text('Executive Summary', 20, 80)
      
      pdf.setFontSize(11)
      pdf.setTextColor(60)
      const summaryText = `This report provides a comprehensive analysis of ${reportName}. 
      It includes ${widgets.length} key metrics and visualizations covering energy efficiency, 
      production metrics, and operational performance.`
      
      const summaryLines = pdf.splitTextToSize(summaryText, pageWidth - 40)
      pdf.text(summaryLines, 20, 95)
      
      // Add new page for widgets
      pdf.addPage()
      let yPosition = 20
      
      // Render each widget
      for (const widget of widgets) {
        if (yPosition > pageHeight - 80) {
          pdf.addPage()
          yPosition = 20
        }
        
        // Widget Title
        pdf.setFontSize(14)
        pdf.setTextColor(103, 58, 183)
        pdf.text(widget.title, 20, yPosition)
        yPosition += 10
        
        // Widget Content
        switch (widget.type) {
          case 'metric':
            if (widget.config.metric) {
              pdf.setFontSize(24)
              pdf.setTextColor(0)
              pdf.text(`${widget.config.metric.value} ${widget.config.metric.unit}`, 20, yPosition + 10)
              
              pdf.setFontSize(12)
              const changeColor = widget.config.metric.trend === 'up' ? [0, 128, 0] : [255, 0, 0]
              pdf.setTextColor(...changeColor as [number, number, number])
              pdf.text(`${widget.config.metric.trend === 'up' ? '↑' : '↓'} ${widget.config.metric.change}%`, 20, yPosition + 20)
              yPosition += 30
            }
            break
            
          case 'text':
            pdf.setFontSize(11)
            pdf.setTextColor(60)
            const textLines = pdf.splitTextToSize(widget.config.text || 'Sample text content', pageWidth - 40)
            pdf.text(textLines, 20, yPosition + 5)
            yPosition += textLines.length * 5 + 10
            break
            
          case 'chart':
            // For charts, we'll add a placeholder or capture from canvas
            pdf.setDrawColor(200)
            pdf.setFillColor(250, 250, 250)
            pdf.rect(20, yPosition, pageWidth - 40, 60, 'FD')
            
            pdf.setFontSize(10)
            pdf.setTextColor(150)
            pdf.text(`[${widget.chartType?.toUpperCase()} CHART]`, pageWidth / 2, yPosition + 30, { align: 'center' })
            yPosition += 70
            break
            
          case 'table':
            // Draw a simple table
            const tableData = [
              ['Date', 'Value', 'Change'],
              ['2024-01-01', '1,234', '+5.2%'],
              ['2024-01-02', '1,456', '+7.8%'],
              ['2024-01-03', '1,389', '-2.1%']
            ]
            
            let tableY = yPosition
            tableData.forEach((row, i) => {
              row.forEach((cell, j) => {
                pdf.setDrawColor(200)
                pdf.rect(20 + j * 50, tableY, 50, 8, 'S')
                pdf.setFontSize(9)
                pdf.setTextColor(i === 0 ? 0 : 60)
                pdf.text(cell, 25 + j * 50, tableY + 5)
              })
              tableY += 8
            })
            yPosition = tableY + 10
            break
        }
        
        yPosition += 10
      }
      
      // Footer
      const totalPages = pdf.getNumberOfPages()
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i)
        pdf.setFontSize(10)
        pdf.setTextColor(150)
        pdf.text(`Page ${i} of ${totalPages}`, pageWidth / 2, pageHeight - 10, { align: 'center' })
      }
      
      // Save the PDF
      pdf.save(`${reportName.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}.pdf`)
    } catch (error) {
      console.error('Error generating PDF:', error)
      alert('Error generating PDF. Please try again.')
    } finally {
      setGeneratingPDF(false)
    }
  }

  const exportReport = async (format: 'pdf' | 'excel' | 'csv') => {
    if (format === 'pdf') {
      await generatePDFReport()
    } else {
      console.log(`Exporting report as ${format}`)
      // Implement Excel/CSV export here
    }
  }

  const saveReport = () => {
    console.log('Saving report:', {
      name: reportName,
      widgets: widgets,
      theme: reportTheme
    })
    // In a real app, this would save to backend
  }

  const renderWidget = (widget: ReportWidget) => {
    switch (widget.type) {
      case 'chart':
        return (
          <div className="h-full p-2">
            <ResponsiveContainer width="100%" height="100%">
              {widget.chartType === 'line' && (
                <RechartsLineChart data={widget.config.data || sampleData.energy}>
                  {widget.config.showGrid && <CartesianGrid strokeDasharray="3 3" />}
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  {widget.config.showLegend && <Legend />}
                  <Line type="monotone" dataKey="consumption" stroke={widget.config.color} />
                  <Line type="monotone" dataKey="efficiency" stroke="#82ca9d" />
                </RechartsLineChart>
              )}
              {widget.chartType === 'bar' && (
                <BarChart data={widget.config.data || sampleData.energy}>
                  {widget.config.showGrid && <CartesianGrid strokeDasharray="3 3" />}
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  {widget.config.showLegend && <Legend />}
                  <Bar dataKey="consumption" fill={widget.config.color} />
                  <Bar dataKey="cost" fill="#82ca9d" />
                </BarChart>
              )}
              {widget.chartType === 'pie' && (
                <RechartsPieChart>
                  <Pie
                    data={sampleData.pie}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {sampleData.pie.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  {widget.config.showLegend && <Legend />}
                </RechartsPieChart>
              )}
              {widget.chartType === 'area' && (
                <AreaChart data={widget.config.data || sampleData.energy}>
                  {widget.config.showGrid && <CartesianGrid strokeDasharray="3 3" />}
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  {widget.config.showLegend && <Legend />}
                  <Area type="monotone" dataKey="consumption" stroke={widget.config.color} fill={widget.config.color} fillOpacity={0.6} />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        )
      
      case 'table':
        return (
          <div className="h-full overflow-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Date</th>
                  <th className="text-left p-2">Value</th>
                  <th className="text-left p-2">Change</th>
                </tr>
              </thead>
              <tbody>
                {[1, 2, 3, 4, 5].map(i => (
                  <tr key={i} className="border-b">
                    <td className="p-2">2024-01-{String(i).padStart(2, '0')}</td>
                    <td className="p-2">{(Math.random() * 1000).toFixed(0)}</td>
                    <td className="p-2 text-green-600">+{(Math.random() * 10).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      
      case 'metric':
        return (
          <div className="h-full flex flex-col items-center justify-center p-4">
            <p className="text-4xl font-bold" style={{ color: widget.config.color }}>
              {widget.config.metric?.value || '0'} {widget.config.metric?.unit || ''}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{widget.title}</p>
            {widget.config.metric && (
              <div className={`flex items-center gap-1 mt-2 ${
                widget.config.metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
              }`}>
                <span>{widget.config.metric.trend === 'up' ? '↑' : '↓'}</span>
                <span className="text-sm font-medium">{widget.config.metric.change}%</span>
              </div>
            )}
          </div>
        )
      
      case 'text':
        return (
          <div className="h-full p-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {widget.config.text || 'Add your text content here...'}
            </p>
          </div>
        )
      
      case 'image':
        return (
          <div className="h-full flex items-center justify-center p-4">
            {widget.config.imageUrl ? (
              <img src={widget.config.imageUrl} alt={widget.title} className="max-w-full max-h-full object-contain" />
            ) : (
              <div className="text-center">
                <ImageIcon className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600">Add image URL in settings</p>
              </div>
            )}
          </div>
        )
    }
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
      {/* Header */}
      <div className="p-6 border-b flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileText className="w-6 h-6 text-indigo-600" />
          <input
            type="text"
            value={reportName}
            onChange={(e) => setReportName(e.target.value)}
            className="text-2xl font-bold bg-transparent border-b border-transparent hover:border-gray-300 focus:border-indigo-600 focus:outline-none"
          />
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowDataPanel(!showDataPanel)}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
            title="Toggle theme settings"
          >
            <Palette className="w-5 h-5" />
          </button>
          <button
            onClick={saveReport}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            <Save className="w-4 h-4" />
            Save
          </button>
          <div className="relative group">
            <button 
              className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              disabled={generatingPDF}
            >
              <Download className="w-4 h-4" />
              {generatingPDF ? 'Generating...' : 'Export'}
            </button>
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 border rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
              <button
                onClick={() => exportReport('pdf')}
                className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2"
              >
                <FileDown className="w-4 h-4" />
                Export as PDF
              </button>
              <button
                onClick={() => exportReport('excel')}
                className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Export as Excel
              </button>
              <button
                onClick={() => exportReport('csv')}
                className="w-full text-left px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                Export as CSV
              </button>
            </div>
          </div>
          <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded">
            <Share2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowSalesforce(!showSalesforce)}
            className={`p-2 rounded transition-colors ${
              showSalesforce 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
            title="Salesforce Integration"
          >
            <Cloud className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex h-[calc(100vh-200px)]">
        {/* Left Panel - Widget Library */}
        <div className="w-64 border-r border-gray-200 dark:border-gray-700 p-4 overflow-y-auto">
          <h3 className="font-semibold mb-4 text-gray-900 dark:text-gray-200">Widgets</h3>
          <div className="grid grid-cols-2 gap-2">
            {widgetTypes.map(widget => (
              <button
                key={widget.id}
                onClick={() => addWidget(widget.id)}
                className="flex flex-col items-center gap-2 p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <widget.icon className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                <span className="text-xs text-gray-700 dark:text-gray-300">{widget.name}</span>
              </button>
            ))}
          </div>

          <h3 className="font-semibold mt-6 mb-4 text-gray-900 dark:text-gray-200">Data Sources</h3>
          <div className="space-y-2">
            {dataSources.map(source => (
              <div
                key={source.id}
                className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700"
                draggable
                onDragStart={() => setDraggedWidget(source.id)}
              >
                <div className="flex items-center gap-2 mb-2">
                  <source.icon className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                  <span className="font-medium text-sm">{source.name}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {source.fields.slice(0, 3).map(field => (
                    <span
                      key={field}
                      className="px-2 py-0.5 bg-gray-100 dark:bg-gray-600 rounded text-xs"
                    >
                      {field}
                    </span>
                  ))}
                  {source.fields.length > 3 && (
                    <span className="text-xs text-gray-500">
                      +{source.fields.length - 3} more
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Theme Settings */}
          {showDataPanel && (
            <div className="mt-6">
              <h3 className="font-semibold mb-4 text-gray-900 dark:text-gray-200">Theme</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-600">Primary Color</label>
                  <input
                    type="color"
                    value={reportTheme.primaryColor}
                    onChange={(e) => setReportTheme({...reportTheme, primaryColor: e.target.value})}
                    className="w-full h-8 rounded cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-sm text-gray-600">Font</label>
                  <select
                    value={reportTheme.fontFamily}
                    onChange={(e) => setReportTheme({...reportTheme, fontFamily: e.target.value})}
                    className="w-full px-2 py-1 border rounded"
                  >
                    <option value="Inter">Inter</option>
                    <option value="Arial">Arial</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Courier">Courier</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          <h3 className="font-semibold mt-6 mb-4 text-gray-900 dark:text-gray-200">Templates</h3>
          <div className="space-y-2">
            {reportTemplates.map(template => (
              <button
                key={template.id}
                onClick={() => {
                  setActiveReport(template)
                  setReportName(template.name)
                }}
                className="w-full text-left p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <p className="font-medium text-sm">{template.name}</p>
                <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                  {template.description}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Center - Report Canvas */}
        <div className="flex-1 p-6 bg-gray-50 dark:bg-gray-900 overflow-auto" ref={reportRef}>
          {widgets.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <Grid className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold mb-2">Start Building Your Report</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Add widgets from the left panel to begin
                </p>
                <button
                  onClick={() => addWidget('metric-card')}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  Add First Widget
                </button>
              </div>
            </div>
          ) : (
            <div 
              className="grid grid-cols-12 gap-4 auto-rows-[100px]"
              style={{ fontFamily: reportTheme.fontFamily }}
            >
              {widgets.map(widget => (
                <div
                  key={widget.id}
                  className={`bg-white dark:bg-gray-800 rounded-lg shadow-md cursor-pointer overflow-hidden ${
                    selectedWidget === widget.id ? 'ring-2 ring-indigo-600' : ''
                  }`}
                  style={{
                    gridColumn: `span ${widget.position.w}`,
                    gridRow: `span ${widget.position.h}`
                  }}
                  onClick={() => setSelectedWidget(widget.id)}
                >
                  <div className="h-full relative group">
                    {/* Widget Controls */}
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                      <div className="flex gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            duplicateWidget(widget.id)
                          }}
                          className="p-1 bg-white dark:bg-gray-700 rounded shadow hover:bg-gray-50"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteWidget(widget.id)
                          }}
                          className="p-1 bg-white dark:bg-gray-700 rounded shadow hover:bg-red-50 text-red-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                    {renderWidget(widget)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Panel - Widget Settings */}
        {selectedWidget && (
          <div className="w-80 border-l p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Widget Settings</h3>
              <button
                onClick={() => setSelectedWidget(null)}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {(() => {
              const widget = widgets.find(w => w.id === selectedWidget)
              if (!widget) return null

              return (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Title</label>
                    <input
                      type="text"
                      value={widget.title}
                      onChange={(e) => updateWidget(widget.id, { title: e.target.value })}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Data Source</label>
                    <select
                      value={widget.dataSource}
                      onChange={(e) => updateWidget(widget.id, { dataSource: e.target.value })}
                      className="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600"
                    >
                      <option value="">Select data source...</option>
                      {dataSources.map(source => (
                        <option key={source.id} value={source.id}>
                          {source.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Size</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-xs text-gray-600">Width</label>
                        <input
                          type="number"
                          min="1"
                          max="12"
                          value={widget.position.w}
                          onChange={(e) => updateWidget(widget.id, {
                            position: { ...widget.position, w: Number(e.target.value) }
                          })}
                          className="w-full px-2 py-1 border rounded dark:bg-gray-700 dark:border-gray-600"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-600">Height</label>
                        <input
                          type="number"
                          min="1"
                          max="10"
                          value={widget.position.h}
                          onChange={(e) => updateWidget(widget.id, {
                            position: { ...widget.position, h: Number(e.target.value) }
                          })}
                          className="w-full px-2 py-1 border rounded dark:bg-gray-700 dark:border-gray-600"
                        />
                      </div>
                    </div>
                  </div>

                  {widget.type === 'chart' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium mb-2">Chart Type</label>
                        <div className="grid grid-cols-2 gap-2">
                          {['line', 'bar', 'pie', 'area'].map(type => (
                            <button
                              key={type}
                              onClick={() => updateWidget(widget.id, { chartType: type as any })}
                              className={`p-2 border rounded capitalize ${
                                widget.chartType === type ? 'bg-indigo-50 border-indigo-600' : ''
                              }`}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={widget.config.showLegend}
                            onChange={(e) => updateWidget(widget.id, {
                              config: { ...widget.config, showLegend: e.target.checked }
                            })}
                          />
                          <span className="text-sm">Show Legend</span>
                        </label>
                      </div>
                      <div>
                        <label className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={widget.config.showGrid}
                            onChange={(e) => updateWidget(widget.id, {
                              config: { ...widget.config, showGrid: e.target.checked }
                            })}
                          />
                          <span className="text-sm">Show Grid</span>
                        </label>
                      </div>
                    </>
                  )}

                  {widget.type === 'metric' && (
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium">Value</label>
                        <input
                          type="number"
                          value={widget.config.metric?.value || 0}
                          onChange={(e) => updateWidget(widget.id, {
                            config: {
                              ...widget.config,
                              metric: {
                                ...widget.config.metric!,
                                value: Number(e.target.value)
                              }
                            }
                          })}
                          className="w-full px-2 py-1 border rounded"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Unit</label>
                        <input
                          type="text"
                          value={widget.config.metric?.unit || ''}
                          onChange={(e) => updateWidget(widget.id, {
                            config: {
                              ...widget.config,
                              metric: {
                                ...widget.config.metric!,
                                unit: e.target.value
                              }
                            }
                          })}
                          className="w-full px-2 py-1 border rounded"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Change %</label>
                        <input
                          type="number"
                          step="0.1"
                          value={widget.config.metric?.change || 0}
                          onChange={(e) => updateWidget(widget.id, {
                            config: {
                              ...widget.config,
                              metric: {
                                ...widget.config.metric!,
                                change: Number(e.target.value)
                              }
                            }
                          })}
                          className="w-full px-2 py-1 border rounded"
                        />
                      </div>
                    </div>
                  )}

                  {widget.type === 'text' && (
                    <div>
                      <label className="text-sm font-medium">Content</label>
                      <textarea
                        value={widget.config.text || ''}
                        onChange={(e) => updateWidget(widget.id, {
                          config: { ...widget.config, text: e.target.value }
                        })}
                        className="w-full px-2 py-1 border rounded h-32"
                      />
                    </div>
                  )}

                  {widget.type === 'image' && (
                    <div>
                      <label className="text-sm font-medium">Image URL</label>
                      <input
                        type="url"
                        value={widget.config.imageUrl || ''}
                        onChange={(e) => updateWidget(widget.id, {
                          config: { ...widget.config, imageUrl: e.target.value }
                        })}
                        className="w-full px-2 py-1 border rounded"
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                  )}

                  <div>
                    <label className="text-sm font-medium">Color</label>
                    <input
                      type="color"
                      value={widget.config.color || reportTheme.primaryColor}
                      onChange={(e) => updateWidget(widget.id, {
                        config: { ...widget.config, color: e.target.value }
                      })}
                      className="w-full h-8 rounded cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Filters</label>
                    <button className="w-full flex items-center justify-center gap-2 px-3 py-2 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                      <Filter className="w-4 h-4" />
                      Add Filter
                    </button>
                  </div>
                </div>
              )
            })()}
          </div>
        )}
      </div>

      {/* Salesforce Integration Panel */}
      {showSalesforce && (
        <div className="fixed right-4 top-20 w-96 z-50 shadow-2xl">
          <SalesforceIntegration
            data={{
              reportName,
              projectStatus: 'In Progress',
              energySavings: Math.round(Math.random() * 30 + 20),
              roiPercentage: Math.round(Math.random() * 40 + 60),
              fixtureCount: widgets.filter(w => w.dataSource === 'energy').length * 50 || 100,
              totalPPFD: 650,
              coverageArea: 10000,
              annualYieldEstimate: 45000,
              implementationTimeline: '3-4 months',
              annualSavings: 125000,
              paybackPeriod: 18,
              yieldImprovement: 25,
              spectrumOptimization: 'Full Spectrum LED',
              qualityImprovement: 'A+ Grade'
            }}
            reportId={activeReport?.id || Date.now().toString()}
            onClose={() => setShowSalesforce(false)}
          />
        </div>
      )}
    </div>
  )
}