'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { FalseColorPPFDMap } from '@/components/FalseColorPPFDMap';
import { Room3DModal } from '@/components/Room3DModal';
import { FixtureLibrary, type FixtureModel } from '@/components/FixtureLibrary';
import { ElectricalLoadBalancer } from '@/components/ElectricalLoadBalancer';
import { EnergyCostCalculator } from '@/components/energy-cost-calculator';
import { exportToPDF, exportToExcel, exportToCSV } from '@/lib/export-utils';
import { getWhiteLabelConfig } from '@/lib/whitelabel-config';
import { calculatePPFDGrid, calculatePPFDStats, calculateDLI, calculateSpectrumMix } from '@/lib/ppfd-calculations';
import { 
  Settings,
  Eye,
  EyeOff,
  Save,
  Download,
  Undo,
  Redo,
  Grid,
  Move,
  RotateCw,
  Plus,
  Layers,
  BarChart3,
  Zap,
  Sun,
  ChevronRight,
  ChevronDown,
  Package,
  Map,
  Activity,
  Calendar,
  Thermometer,
  Droplets,
  Brain,
  TrendingUp,
  FileText,
  HelpCircle,
  X,
  Edit2,
  Box as Cube
} from 'lucide-react';

interface Section {
  id: string;
  title: string;
  icon: React.ElementType;
  description: string;
  expanded: boolean;
}

interface Fixture {
  id: string;
  x: number;
  y: number;
  rotation: number;
  model: {
    id: string;
    brand: string;
    model: string;
    wattage: number;
    ppf: number;
    efficacy: number;
    spectrumData: {
      red: number;
      blue: number;
      green: number;
      farRed: number;
    };
    coverage: number;
  };
  enabled: boolean;
}

export function AdvancedDesignerV2() {
  const [activeTab, setActiveTab] = useState<'design' | 'analyze' | 'optimize' | 'export'>('design');
  const [selectedTool, setSelectedTool] = useState<string>('select');
  const [showHelp, setShowHelp] = useState(false);
  const [show3D, setShow3D] = useState(false);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [selectedFixture, setSelectedFixture] = useState<string | null>(null);
  const [multiTierLayers, setMultiTierLayers] = useState<any[]>([]);
  const [roomDimensions, setRoomDimensions] = useState({ width: 10, length: 10, height: 3 });
  const [sidebarSections, setSidebarSections] = useState<Section[]>([
    {
      id: 'room',
      title: 'Room Configuration',
      icon: Package,
      description: 'Set room dimensions and shape',
      expanded: true
    },
    {
      id: 'fixtures',
      title: 'Fixture Library',
      icon: Zap,
      description: 'Browse and select fixtures',
      expanded: true
    },
    {
      id: 'layers',
      title: 'Canopy Layers',
      icon: Layers,
      description: 'Multi-tier growing setup',
      expanded: false
    },
    {
      id: 'environment',
      title: 'Environmental Factors',
      icon: Thermometer,
      description: 'Temperature, humidity, CO2',
      expanded: false
    }
  ]);

  const toggleSection = (sectionId: string) => {
    setSidebarSections(prev => 
      prev.map(section => 
        section.id === sectionId 
          ? { ...section, expanded: !section.expanded }
          : section
      )
    );
  };

  const tools = [
    { id: 'select', icon: Move, tooltip: 'Select & Move (V)' },
    { id: 'place', icon: Plus, tooltip: 'Place Fixture (P)' },
    { id: 'rotate', icon: RotateCw, tooltip: 'Rotate (R)' },
    { id: 'grid', icon: Grid, tooltip: 'Toggle Grid (G)' },
  ];

  const tabs = [
    { id: 'design', label: 'Design', icon: Grid },
    { id: 'analyze', label: 'Analyze', icon: BarChart3 },
    { id: 'optimize', label: 'Optimize', icon: Brain },
    { id: 'export', label: 'Export', icon: Download },
  ];

  return (
    <div className="min-h-screen bg-gradient-background">
      {/* Header Toolbar */}
      <div className="bg-gray-900/90 backdrop-blur-xl border-b border-gray-700 sticky top-0 z-40">
        <div className="px-4 py-2">
          <div className="flex items-center justify-between">
            {/* Left: Project Info & Tools */}
            <div className="flex items-center gap-4">
              <h1 className="text-lg font-semibold text-white">Advanced Lighting Designer</h1>
              
              {/* Tool Selection */}
              <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
                {tools.map(tool => (
                  <button
                    key={tool.id}
                    onClick={() => setSelectedTool(tool.id)}
                    className={`p-2 rounded transition-colors ${
                      selectedTool === tool.id 
                        ? 'bg-purple-600 text-white' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-700'
                    }`}
                    title={tool.tooltip}
                  >
                    <tool.icon className="w-4 h-4" />
                  </button>
                ))}
              </div>

              {/* View Options */}
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShow3D(true)}
                  className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors flex items-center gap-2"
                  title="3D View"
                >
                  <Cube className="w-4 h-4" />
                  <span className="text-sm">3D View</span>
                </button>
                <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Center: Tabs */}
            <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2 rounded flex items-center gap-2 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2">
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                <Undo className="w-4 h-4" />
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                <Redo className="w-4 h-4" />
              </button>
              <div className="w-px h-6 bg-gray-700" />
              <button className="px-3 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded flex items-center gap-2 transition-colors">
                <Save className="w-4 h-4" />
                <span className="text-sm">Save</span>
              </button>
              <button
                onClick={() => setShowHelp(true)}
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex h-[calc(100vh-60px)]">
        {/* Left Sidebar */}
        <div className="w-80 bg-gray-900/50 backdrop-blur-xl border-r border-gray-700 overflow-y-auto">
          <div className="p-4 space-y-4">
            {sidebarSections.map(section => (
              <div key={section.id} className="bg-gray-800/50 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-800/70 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <section.icon className="w-5 h-5 text-purple-400" />
                    <div className="text-left">
                      <h3 className="text-sm font-semibold text-white">{section.title}</h3>
                      <p className="text-xs text-gray-400">{section.description}</p>
                    </div>
                  </div>
                  {section.expanded ? (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  )}
                </button>
                
                {section.expanded && (
                  <div className="p-4 pt-0">
                    {section.id === 'room' && <RoomConfiguration />}
                    {section.id === 'fixtures' && <FixtureLibraryPanel />}
                    {section.id === 'layers' && <CanopyLayersPanel onLayersChange={setMultiTierLayers} />}
                    {section.id === 'environment' && <EnvironmentalPanel />}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Center: Canvas Area */}
        <div className="flex-1 relative bg-gray-950">
          {activeTab === 'design' && (
            <DesignCanvas 
              selectedTool={selectedTool}
              fixtures={fixtures}
              setFixtures={setFixtures}
              roomDimensions={roomDimensions}
              setRoomDimensions={setRoomDimensions}
            />
          )}
          
          {activeTab === 'analyze' && (
            <AnalysisView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
              tiers={multiTierLayers}
            />
          )}
          {activeTab === 'optimize' && (
            <OptimizationView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
            />
          )}
          {activeTab === 'export' && (
            <ExportView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
              tiers={multiTierLayers}
            />
          )}
        </div>

        {/* Right Panel: Metrics & Analysis */}
        <div className="w-96 bg-gray-900/50 backdrop-blur-xl border-l border-gray-700 overflow-y-auto">
          <MetricsPanel activeTab={activeTab} />
        </div>
      </div>

      {/* Help Modal */}
      {showHelp && (
        <HelpModal onClose={() => setShowHelp(false)} />
      )}
      
      {/* 3D WebGL View Modal */}
      <Room3DModal
        isOpen={show3D}
        onClose={() => setShow3D(false)}
        roomDimensions={roomDimensions}
        fixtures={fixtures.map(f => ({
          id: f.id,
          x: f.x - 50, // Convert from percentage to meters
          y: f.y - 50,
          z: 2.5, // Default mounting height
          rotation: f.rotation,
          model: {
            brand: f.model.brand,
            model: f.model.model,
            wattage: f.model.wattage,
            ppf: f.model.ppf,
            beamAngle: 120
          },
          enabled: f.enabled
        }))}
        tiers={multiTierLayers}
      />
    </div>
  );
}

// Component Panels
function RoomConfiguration() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-medium text-gray-400 mb-1 block">Room Shape</label>
        <select className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm">
          <option>Rectangle</option>
          <option>Square</option>
          <option>L-Shape</option>
          <option>Custom Polygon</option>
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-medium text-gray-400 mb-1 block">Width (m)</label>
          <input type="number" defaultValue="10" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-gray-400 mb-1 block">Length (m)</label>
          <input type="number" defaultValue="10" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
        </div>
      </div>
      <div>
        <label className="text-xs font-medium text-gray-400 mb-1 block">Mounting Height (m)</label>
        <input type="number" defaultValue="3" step="0.1" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
      </div>
    </div>
  );
}

function FixtureLibraryPanel() {
  const [selectedFixture, setSelectedFixture] = useState<FixtureModel | null>(null);
  const [showCompact, setShowCompact] = useState(true);
  
  const handleFixtureSelect = (fixture: FixtureModel) => {
    setSelectedFixture(fixture);
    // TODO: Add logic to place fixture on canvas
  };
  
  if (showCompact) {
    // Compact view with search only
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-300">Quick fixture search</p>
          <button
            onClick={() => setShowCompact(false)}
            className="text-xs text-purple-400 hover:text-purple-300"
          >
            Expand catalog
          </button>
        </div>
        <input
          type="text"
          placeholder="Search fixtures..."
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm placeholder-gray-400"
        />
        {selectedFixture && (
          <div className="p-3 bg-purple-900/20 rounded border border-purple-700/50">
            <p className="text-sm font-medium text-white">{selectedFixture.brand} {selectedFixture.model}</p>
            <p className="text-xs text-gray-400">{selectedFixture.wattage}W • {selectedFixture.efficacy} PPE</p>
          </div>
        )}
      </div>
    );
  }
  
  // Full catalog view
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-300">Full fixture catalog</p>
        <button
          onClick={() => setShowCompact(true)}
          className="text-xs text-purple-400 hover:text-purple-300"
        >
          Collapse
        </button>
      </div>
      <div className="max-h-96 overflow-y-auto">
        <FixtureLibrary
          onSelectFixture={handleFixtureSelect}
          selectedFixtureId={selectedFixture?.id}
        />
      </div>
    </div>
  );
}

function CanopyLayersPanel({ onLayersChange }: { onLayersChange?: (layers: any[]) => void }) {
  const [layers, setLayers] = useState([
    {
      id: 'ground',
      name: 'Ground Level',
      height: 30, // inches
      benchDepth: 4, // feet
      canopyHeight: 12, // inches
      targetPPFD: 600,
      cropType: 'Lettuce',
      enabled: true,
      visible: true,
      color: '#10B981',
      plantDensity: 16,
      growthStage: 'vegetative' as const
    }
  ]);
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingLayer, setEditingLayer] = useState<string | null>(null);
  
  // Notify parent when layers change
  useEffect(() => {
    onLayersChange?.(layers.map(layer => ({
      ...layer,
      height: layer.height / 39.37, // Convert inches to meters for 3D view
      canopyHeight: layer.canopyHeight / 39.37,
      benchDepth: layer.benchDepth * 0.3048 // Convert feet to meters
    })));
  }, [layers, onLayersChange]);
  
  const addLayer = () => {
    const newLayer = {
      id: `layer-${Date.now()}`,
      name: `Tier ${layers.length + 1}`,
      height: 60 + (layers.length * 30), // Auto-increment height
      benchDepth: 4,
      canopyHeight: 12,
      targetPPFD: 500 - (layers.length * 50),
      cropType: 'Herbs',
      enabled: true,
      visible: true,
      color: ['#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6'][layers.length % 4],
      plantDensity: 12,
      growthStage: 'vegetative' as const
    };
    setLayers([...layers, newLayer]);
    setShowAddForm(false);
  };
  
  const removeLayer = (layerId: string) => {
    setLayers(layers.filter(l => l.id !== layerId));
  };
  
  const updateLayer = (layerId: string, updates: any) => {
    setLayers(layers.map(l => l.id === layerId ? { ...l, ...updates } : l));
  };
  
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-gray-300">Growing Tiers</h4>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-xs flex items-center gap-1"
        >
          <Plus className="w-3 h-3" />
          Add
        </button>
      </div>
      
      {showAddForm && (
        <div className="p-3 bg-gray-700/70 rounded border border-purple-500/30">
          <div className="grid grid-cols-2 gap-2 mb-2">
            <input
              type="text"
              placeholder="Tier name"
              className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
            />
            <input
              type="number"
              placeholder="Height (in)"
              className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={addLayer}
              className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs"
            >
              Add Tier
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1 bg-gray-600 hover:bg-gray-500 text-white rounded text-xs"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      <div className="space-y-2">
        {layers
          .sort((a, b) => b.height - a.height)
          .map((layer) => (
          <div key={layer.id} className="p-3 bg-gray-700/50 rounded border border-gray-600">
            {editingLayer === layer.id ? (
              <div className="space-y-2">
                <input
                  type="text"
                  value={layer.name}
                  onChange={(e) => updateLayer(layer.id, { name: e.target.value })}
                  className="w-full px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={layer.height}
                    onChange={(e) => updateLayer(layer.id, { height: Number(e.target.value) })}
                    className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                    placeholder="Height (in)"
                  />
                  <input
                    type="number"
                    value={layer.targetPPFD}
                    onChange={(e) => updateLayer(layer.id, { targetPPFD: Number(e.target.value) })}
                    className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                    placeholder="PPFD"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditingLayer(null)}
                    className="px-2 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => removeLayer(layer.id)}
                    className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: layer.color }}
                    />
                    <p className="text-sm font-medium text-white">{layer.name}</p>
                    <button
                      onClick={() => updateLayer(layer.id, { visible: !layer.visible })}
                      className="p-1 text-gray-400 hover:text-white"
                    >
                      {layer.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                    </button>
                  </div>
                  <button
                    onClick={() => setEditingLayer(layer.id)}
                    className="p-1 text-gray-400 hover:text-white"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>
                <div className="text-xs text-gray-400 space-y-1">
                  <p>Height: {layer.height}" • {layer.cropType}</p>
                  <p>Target: {layer.targetPPFD} PPFD • {layer.plantDensity} plants/ft²</p>
                  <p>Bench: {layer.benchDepth}' × full width</p>
                </div>
                
                {/* Mini visualization */}
                <div className="mt-2 h-2 bg-gray-800 rounded overflow-hidden relative">
                  <div 
                    className="absolute left-0 top-0 h-full rounded"
                    style={{
                      backgroundColor: layer.color,
                      width: `${Math.min(100, (layer.targetPPFD / 1000) * 100)}%`,
                      opacity: 0.7
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xs text-white font-medium">
                      {layer.targetPPFD} PPFD
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      
      {layers.length > 1 && (
        <div className="p-2 bg-blue-900/30 border border-blue-600/50 rounded">
          <p className="text-xs text-blue-300">
            ✓ {layers.length} tier system • Total height: {Math.max(...layers.map(l => l.height + l.canopyHeight))}"</p>
          <p className="text-xs text-blue-400">
            Grow area: {layers.reduce((sum, l) => sum + (l.benchDepth * 10), 0)} ft²
          </p>
        </div>
      )}
    </div>
  );
}

function EnvironmentalPanel() {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-medium text-gray-400 mb-1 block">Temperature (°C)</label>
        <input type="number" defaultValue="24" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
      </div>
      <div>
        <label className="text-xs font-medium text-gray-400 mb-1 block">Humidity (%)</label>
        <input type="number" defaultValue="65" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
      </div>
      <div>
        <label className="text-xs font-medium text-gray-400 mb-1 block">CO2 (ppm)</label>
        <input type="number" defaultValue="1000" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" />
      </div>
    </div>
  );
}

function MetricsPanel({ activeTab }: { activeTab: string }) {
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold text-white">Performance Metrics</h2>
      
      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gray-800/50 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Avg PPFD</p>
          <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">μmol/m²/s</span></p>
        </div>
        <div className="bg-gray-800/50 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Uniformity</p>
          <p className="text-xl font-bold text-white">0% <span className="text-sm text-gray-400">avg/max</span></p>
        </div>
        <div className="bg-gray-800/50 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">DLI</p>
          <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">mol/m²/d</span></p>
        </div>
        <div className="bg-gray-800/50 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Power</p>
          <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">kW</span></p>
        </div>
      </div>

      {/* Detailed Analysis */}
      <div className="bg-gray-800/50 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-white mb-3">Spectrum Analysis</h3>
        <div className="h-48 bg-gray-900/50 rounded flex items-center justify-center">
          <p className="text-gray-500 text-sm">No fixtures placed</p>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-purple-900/20 rounded-lg p-4 border border-purple-700/30">
        <div className="flex items-start gap-3">
          <Brain className="w-5 h-5 text-purple-400 mt-0.5" />
          <div>
            <h3 className="text-sm font-semibold text-white mb-1">AI Recommendations</h3>
            <p className="text-xs text-gray-400">Add fixtures to get optimization suggestions</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnalysisView({ fixtures, roomDimensions, tiers }: { 
  fixtures: Fixture[]; 
  roomDimensions: { width: number; length: number; height: number };
  tiers: any[]
}) {
  const [ppfdStats, setPpfdStats] = useState({ min: 0, max: 0, avg: 0, uniformity: 0 });
  const [ppfdGrid, setPpfdGrid] = useState<number[][]>([]);
  const [photoperiod] = useState(18); // hours
  
  const activeFixtures = fixtures.filter(f => f.enabled);
  const totalPower = activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0);
  const totalPPF = activeFixtures.reduce((sum, f) => sum + f.model.ppf, 0);
  
  // Calculate real PPFD grid and stats
  useEffect(() => {
    if (activeFixtures.length > 0) {
      // Convert fixture positions to meters and add height
      const fixtureData = activeFixtures.map(f => ({
        x: (f.x / 100) * roomDimensions.width,
        y: (f.y / 100) * roomDimensions.length,
        z: roomDimensions.height - 0.5, // 0.5m below ceiling
        ppf: f.model.ppf,
        beamAngle: 120, // Default beam angle
        enabled: f.enabled,
        spectrumData: f.model.spectrumData
      }));
      
      // Calculate PPFD grid
      const grid = calculatePPFDGrid(
        fixtureData,
        roomDimensions.width,
        roomDimensions.length,
        1.0, // Canopy height 1m
        50 // Grid resolution
      );
      
      setPpfdGrid(grid);
      setPpfdStats(calculatePPFDStats(grid));
    } else {
      setPpfdStats({ min: 0, max: 0, avg: 0, uniformity: 0 });
      setPpfdGrid([]);
    }
  }, [activeFixtures, roomDimensions]);
  
  // Calculate spectrum mix
  const spectrumMix = calculateSpectrumMix(activeFixtures.map(f => ({
    ...f,
    x: 0, y: 0, z: 0, beamAngle: 120,
    spectrumData: f.model.spectrumData
  })));
  
  const dli = calculateDLI(ppfdStats.avg, photoperiod);
  const roomArea = roomDimensions.width * roomDimensions.length;
  
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold text-white mb-6">Lighting Analysis</h2>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Average PPFD</p>
          <p className="text-2xl font-bold text-white">{ppfdStats.avg} <span className="text-sm text-gray-400">μmol/m²/s</span></p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Total PPF</p>
          <p className="text-2xl font-bold text-white">{totalPPF} <span className="text-sm text-gray-400">μmol/s</span></p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Total Power</p>
          <p className="text-2xl font-bold text-white">{totalPower} <span className="text-sm text-gray-400">W</span></p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">System Efficacy</p>
          <p className="text-2xl font-bold text-white">{totalPower > 0 ? (totalPPF / totalPower).toFixed(2) : '0'} <span className="text-sm text-gray-400">μmol/J</span></p>
        </div>
      </div>
      
      {/* DLI and Additional Metrics */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">DLI ({photoperiod}h photoperiod)</p>
          <p className="text-2xl font-bold text-white">{dli} <span className="text-sm text-gray-400">mol/m²/day</span></p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Coverage Area</p>
          <p className="text-2xl font-bold text-white">{roomArea.toFixed(0)} <span className="text-sm text-gray-400">m²</span></p>
        </div>
        <div className="bg-gray-800/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-1">Fixtures/m²</p>
          <p className="text-2xl font-bold text-white">{roomArea > 0 ? (activeFixtures.length / roomArea).toFixed(2) : '0'} <span className="text-sm text-gray-400">units</span></p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-6">
        {/* PPFD Distribution */}
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">PPFD Distribution</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Min PPFD</span>
                <span className="text-white">{ppfdStats.min} μmol/m²/s</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-red-500 h-2 rounded-full" style={{ width: ppfdStats.max > 0 ? `${(ppfdStats.min / ppfdStats.max) * 100}%` : '0%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Average PPFD</span>
                <span className="text-white">{ppfdStats.avg} μmol/m²/s</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{ width: ppfdStats.max > 0 ? `${(ppfdStats.avg / ppfdStats.max) * 100}%` : '0%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Max PPFD</span>
                <span className="text-white">{ppfdStats.max} μmol/m²/s</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div className="mt-6 p-4 bg-gray-900/50 rounded">
              <p className="text-sm text-gray-400 mb-2">Uniformity Ratio</p>
              <p className="text-xl font-bold text-white">{ppfdStats.uniformity} <span className="text-sm text-gray-400">min/avg</span></p>
            </div>
          </div>
        </div>
        
        {/* Spectrum Coverage */}
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Spectrum Distribution</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Blue (400-500nm)</span>
                <span className="text-white">{spectrumMix.blue}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div className="bg-blue-500 h-3 rounded-full" style={{ width: `${spectrumMix.blue}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Green (500-600nm)</span>
                <span className="text-white">{spectrumMix.green}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div className="bg-green-500 h-3 rounded-full" style={{ width: `${spectrumMix.green}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Red (600-700nm)</span>
                <span className="text-white">{spectrumMix.red}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div className="bg-red-500 h-3 rounded-full" style={{ width: `${spectrumMix.red}%` }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">Far Red (700-800nm)</span>
                <span className="text-white">{spectrumMix.farRed}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div className="bg-red-900 h-3 rounded-full" style={{ width: `${spectrumMix.farRed}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Electrical Analysis */}
      <div className="mt-6 bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Electrical Requirements</h3>
        <ElectricalLoadBalancer fixtures={activeFixtures} />
      </div>
      
      {/* Energy Cost Analysis */}
      <div className="mt-6 bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Energy Cost Analysis</h3>
        <EnergyCostCalculator
          totalWattage={totalPower}
          hoursPerDay={18}
          electricityRate={0.12}
          utilityRebate={0}
        />
      </div>
    </div>
  );
}

function OptimizationView({ fixtures, roomDimensions }: { 
  fixtures: Fixture[]; 
  roomDimensions: { width: number; length: number; height: number };
}) {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [optimizationTarget, setOptimizationTarget] = useState<'uniformity' | 'energy' | 'coverage'>('uniformity');
  
  // Calculate current metrics for optimization
  const activeFixtures = fixtures.filter(f => f.enabled);
  const totalPower = activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0);
  const roomArea = roomDimensions.width * roomDimensions.length;
  
  // Calculate PPFD uniformity
  const calculateUniformity = () => {
    let ppfdValues: number[] = [];
    const samplePoints = 10;
    
    for (let x = 0; x < samplePoints; x++) {
      for (let y = 0; y < samplePoints; y++) {
        const xPos = (x / (samplePoints - 1)) * roomDimensions.width;
        const yPos = (y / (samplePoints - 1)) * roomDimensions.length;
        
        let ppfdAtPoint = 0;
        activeFixtures.forEach(fixture => {
          const fixtureX = (fixture.x / 100) * roomDimensions.width;
          const fixtureY = (fixture.y / 100) * roomDimensions.length;
          const dx = xPos - fixtureX;
          const dy = yPos - fixtureY;
          const distance = Math.sqrt(dx * dx + dy * dy + 6.25); // 2.5m height squared
          
          const intensity = fixture.model.ppf / (4 * Math.PI * distance * distance);
          ppfdAtPoint += intensity * 4.6;
        });
        
        ppfdValues.push(ppfdAtPoint);
      }
    }
    
    const avgPPFD = ppfdValues.reduce((a, b) => a + b, 0) / ppfdValues.length;
    const minPPFD = Math.min(...ppfdValues);
    return minPPFD / avgPPFD;
  };
  
  const runOptimization = () => {
    setIsOptimizing(true);
    setSuggestions([]);
    
    // Simulate optimization process
    setTimeout(() => {
      const newSuggestions = [];
      const currentUniformity = calculateUniformity();
      const fixturesPerM2 = activeFixtures.length / roomArea;
      const avgPPF = activeFixtures.reduce((sum, f) => sum + f.model.ppf, 0) / activeFixtures.length;
      
      // Generate AI-powered suggestions based on target
      if (optimizationTarget === 'uniformity') {
        if (currentUniformity < 0.7) {
          newSuggestions.push('Current uniformity is below optimal (0.7). Consider redistributing fixtures more evenly across the canopy.');
        }
        if (fixturesPerM2 < 0.15) {
          newSuggestions.push('Fixture density is low. Add more fixtures or use wider beam angle models for better coverage.');
        }
        if (activeFixtures.length > 0) {
          const gridSize = Math.ceil(Math.sqrt(activeFixtures.length));
          newSuggestions.push(`For optimal uniformity with ${activeFixtures.length} fixtures, arrange in a ${gridSize}×${gridSize} grid pattern.`);
        }
        newSuggestions.push('Consider using fixtures with 120° beam angles for better light overlap and uniformity.');
      } else if (optimizationTarget === 'energy') {
        const targetPPFD = 600; // μmol/m²/s for most crops
        const currentAvgPPFD = (activeFixtures.reduce((sum, f) => sum + f.model.ppf, 0) / roomArea);
        
        if (currentAvgPPFD > targetPPFD * 1.2) {
          newSuggestions.push(`Current PPFD exceeds target by ${Math.round((currentAvgPPFD / targetPPFD - 1) * 100)}%. Consider reducing fixture count or dimming.`);
        }
        const efficientFixtures = activeFixtures.filter(f => f.model.efficacy > 2.5);
        if (efficientFixtures.length < activeFixtures.length) {
          newSuggestions.push(`${activeFixtures.length - efficientFixtures.length} fixtures have efficacy below 2.5 μmol/J. Upgrade to more efficient models.`);
        }
        newSuggestions.push(`Implement dimming controls to reduce power by up to ${Math.round((1 - targetPPFD / currentAvgPPFD) * 100)}% during vegetative growth.`);
      } else if (optimizationTarget === 'coverage') {
        const uncoveredArea = roomArea - (activeFixtures.length * 16); // Assuming 4x4ft coverage per fixture
        if (uncoveredArea > 0) {
          newSuggestions.push(`Approximately ${Math.round(uncoveredArea)} m² of grow area has insufficient light coverage.`);
          newSuggestions.push(`Add ${Math.ceil(uncoveredArea / 16)} more fixtures for complete coverage.`);
        }
        newSuggestions.push('Position fixtures at 2.5-3m mounting height for optimal light distribution.');
      }
      
      // Calculate current metrics
      const activeFixtures = fixtures.filter(f => f.enabled);
      const totalPower = activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0);
      const totalPPF = activeFixtures.reduce((sum, f) => sum + f.model.ppf, 0);
      const roomArea = roomDimensions.width * roomDimensions.length;
      const avgPPFD = roomArea > 0 ? Math.round(totalPPF / roomArea) : 0;
      
      // Generate suggestions based on analysis
      if (avgPPFD < 400) {
        newSuggestions.push("Current PPFD is below optimal range (400-700). Consider adding more fixtures.");
      } else if (avgPPFD > 800) {
        newSuggestions.push("PPFD exceeds recommended levels. Consider reducing fixture count or using dimmers.");
      }
      
      if (activeFixtures.length === 0) {
        newSuggestions.push("No active fixtures detected. Add fixtures to begin optimization.");
      }
      
      // Check fixture spacing
      const idealSpacing = Math.sqrt(roomArea / activeFixtures.length);
      newSuggestions.push(`Optimal fixture spacing: ${idealSpacing.toFixed(1)}m for uniform coverage.`);
      
      // Energy efficiency suggestions
      const systemEfficacy = totalPower > 0 ? totalPPF / totalPower : 0;
      if (systemEfficacy < 2.5) {
        newSuggestions.push("System efficacy is below 2.5 μmol/J. Consider upgrading to more efficient fixtures.");
      }
      
      // Coverage suggestions
      if (activeFixtures.length < Math.ceil(roomArea / 4)) {
        newSuggestions.push("Fixture density appears low. Add more fixtures for better uniformity.");
      }
      
      setSuggestions(newSuggestions);
      setIsOptimizing(false);
    }, 2000);
  };
  
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold text-white mb-6">AI-Powered Design Optimization</h2>
      
      {/* Optimization Target Selector */}
      <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-semibold text-white mb-4">Select Optimization Target</h3>
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => setOptimizationTarget('uniformity')}
            className={`p-4 rounded-lg border-2 transition-all ${
              optimizationTarget === 'uniformity' 
                ? 'border-purple-500 bg-purple-900/30' 
                : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
            }`}
          >
            <Target className="w-6 h-6 text-yellow-400 mb-2 mx-auto" />
            <p className="text-sm font-medium text-white">Optimize Uniformity</p>
            <p className="text-xs text-gray-400 mt-1">Even light distribution</p>
          </button>
          <button
            onClick={() => setOptimizationTarget('energy')}
            className={`p-4 rounded-lg border-2 transition-all ${
              optimizationTarget === 'energy' 
                ? 'border-purple-500 bg-purple-900/30' 
                : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
            }`}
          >
            <Zap className="w-6 h-6 text-green-400 mb-2 mx-auto" />
            <p className="text-sm font-medium text-white">Minimize Energy</p>
            <p className="text-xs text-gray-400 mt-1">Reduce power usage</p>
          </button>
          <button
            onClick={() => setOptimizationTarget('coverage')}
            className={`p-4 rounded-lg border-2 transition-all ${
              optimizationTarget === 'coverage' 
                ? 'border-purple-500 bg-purple-900/30' 
                : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
            }`}
          >
            <TrendingUp className="w-6 h-6 text-purple-400 mb-2 mx-auto" />
            <p className="text-sm font-medium text-white">Maximize Coverage</p>
            <p className="text-xs text-gray-400 mt-1">Full canopy coverage</p>
          </button>
        </div>
      </div>
      
      {/* Current Performance */}
      <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-semibold text-white mb-4">Current Performance</h3>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-gray-400">Active Fixtures</p>
            <p className="text-xl font-bold text-white">{activeFixtures.length}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Total Power</p>
            <p className="text-xl font-bold text-white">{totalPower}W</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Coverage Area</p>
            <p className="text-xl font-bold text-white">{roomArea.toFixed(0)} m²</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Uniformity</p>
            <p className="text-xl font-bold text-white">{(calculateUniformity() * 100).toFixed(0)}%</p>
          </div>
        </div>
      </div>
      
      {/* Optimization Tools */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-400" />
            AI-Powered Optimization
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Let our AI analyze your design and suggest improvements for optimal PPFD distribution and energy efficiency.
          </p>
          <button 
            onClick={runOptimization}
            disabled={isOptimizing}
            className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Brain className="w-4 h-4" />
            {isOptimizing ? 'Analyzing...' : `Optimize for ${optimizationTarget.charAt(0).toUpperCase() + optimizationTarget.slice(1)}`}
          </button>
        </div>
        
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Grid className="w-5 h-5 text-blue-400" />
            Auto-Layout Generator
          </h3>
          <p className="text-sm text-gray-400 mb-4">
            Automatically generate optimal fixture placement based on room dimensions and target PPFD.
          </p>
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
            Generate Layout
          </button>
        </div>
      </div>
      
      {/* Optimization Suggestions */}
      {suggestions.length > 0 && (
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Optimization Suggestions</h3>
          <div className="space-y-3">
            {suggestions.map((suggestion, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-gray-900/50 rounded">
                <div className="w-2 h-2 bg-purple-400 rounded-full mt-1.5 flex-shrink-0" />
                <p className="text-sm text-gray-300">{suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ExportView({ fixtures, roomDimensions, tiers }: { 
  fixtures: Fixture[]; 
  roomDimensions: { width: number; length: number; height: number };
  tiers: any[]
}) {
  const [isExporting, setIsExporting] = useState(false);
  
  const handlePDFExport = async () => {
    setIsExporting(true);
    try {
      const reportData = {
        projectName: `Lighting Design - ${new Date().toLocaleDateString()}`,
        roomDimensions,
        fixtures: fixtures.map(f => ({
          brand: f.model.brand,
          model: f.model.model,
          wattage: f.model.wattage,
          ppf: f.model.ppf,
          position: { x: f.x, y: f.y },
          enabled: f.enabled
        })),
        tiers,
        metrics: {
          totalFixtures: fixtures.length,
          totalPower: fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.wattage : 0), 0),
          totalPPF: fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.ppf : 0), 0),
          avgPPFD: Math.round(fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.ppf : 0), 0) / (roomDimensions.width * roomDimensions.length))
        }
      };
      
      // Get white label settings
      const whiteLabel = getWhiteLabelConfig();
      const whitelabelOptions = {
        companyName: whiteLabel.companyName,
        hideBranding: whiteLabel.hideBranding,
        primaryColor: whiteLabel.primaryColor
      };
      
      await exportToPDF(reportData, whitelabelOptions);
    } catch (error) {
      console.error('PDF export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };
  
  const handleExcelExport = async () => {
    setIsExporting(true);
    try {
      const data = fixtures.map(f => ({
        'Fixture ID': f.id,
        'Brand': f.model.brand,
        'Model': f.model.model,
        'Wattage (W)': f.model.wattage,
        'PPF (μmol/s)': f.model.ppf,
        'Efficacy (μmol/J)': f.model.efficacy,
        'X Position': f.x,
        'Y Position': f.y,
        'Enabled': f.enabled ? 'Yes' : 'No'
      }));
      
      // Get white label settings
      const whiteLabel = getWhiteLabelConfig();
      await exportToExcel(data, 'lighting-design-export', {
        companyName: whiteLabel.companyName,
        hideBranding: whiteLabel.hideBranding
      });
    } catch (error) {
      console.error('Excel export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };
  
  const handleCADExport = () => {
    // TODO: Implement CAD export
    alert('CAD export coming soon!');
  };
  
  const handleJSONExport = () => {
    const exportData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      project: {
        roomDimensions,
        fixtures,
        tiers
      }
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vibelux-design-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold text-white mb-6">Export Options</h2>
      
      {/* Export Summary */}
      <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
        <h3 className="text-lg font-semibold text-white mb-4">Export Summary</h3>
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-gray-400">Total Fixtures</p>
            <p className="text-xl font-bold text-white">{fixtures.length}</p>
          </div>
          <div>
            <p className="text-gray-400">Total Power</p>
            <p className="text-xl font-bold text-white">
              {fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.wattage : 0), 0)}W
            </p>
          </div>
          <div>
            <p className="text-gray-400">Room Size</p>
            <p className="text-xl font-bold text-white">
              {roomDimensions.width}m × {roomDimensions.length}m
            </p>
          </div>
        </div>
      </div>
      
      {/* Export Options */}
      <div className="grid grid-cols-2 gap-6">
        <button 
          onClick={handlePDFExport}
          disabled={isExporting}
          className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors disabled:opacity-50"
        >
          <FileText className="w-8 h-8 text-purple-400 mb-3 mx-auto" />
          <p className="text-white font-medium mb-1">Export PDF Report</p>
          <p className="text-sm text-gray-400">Professional lighting design report</p>
        </button>
        
        <button 
          onClick={handleExcelExport}
          disabled={isExporting}
          className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors disabled:opacity-50"
        >
          <BarChart3 className="w-8 h-8 text-green-400 mb-3 mx-auto" />
          <p className="text-white font-medium mb-1">Export to Excel</p>
          <p className="text-sm text-gray-400">Fixture data spreadsheet</p>
        </button>
        
        <button 
          onClick={handleCADExport}
          className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors"
        >
          <Settings className="w-8 h-8 text-blue-400 mb-3 mx-auto" />
          <p className="text-white font-medium mb-1">Export CAD Files</p>
          <p className="text-sm text-gray-400">DWG/DXF format</p>
        </button>
        
        <button 
          onClick={handleJSONExport}
          className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors"
        >
          <Download className="w-8 h-8 text-yellow-400 mb-3 mx-auto" />
          <p className="text-white font-medium mb-1">Export Project Data</p>
          <p className="text-sm text-gray-400">JSON format for backup</p>
        </button>
      </div>
      
      {isExporting && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6">
            <p className="text-white">Exporting...</p>
          </div>
        </div>
      )}
    </div>
  );
}

function DesignCanvas({ 
  selectedTool,
  fixtures,
  setFixtures,
  roomDimensions,
  setRoomDimensions
}: { 
  selectedTool: string;
  fixtures: Fixture[];
  setFixtures: React.Dispatch<React.SetStateAction<Fixture[]>>;
  roomDimensions: { width: number; length: number; height: number };
  setRoomDimensions: React.Dispatch<React.SetStateAction<{ width: number; length: number; height: number }>>;
}) {
  const [showPPFDMap, setShowPPFDMap] = useState(true);
  const [ppfdData, setPpfdData] = useState<number[][]>([]);

  // Generate real PPFD data for visualization
  useEffect(() => {
    if (fixtures.length > 0) {
      // Convert fixture positions to meters and add height
      const fixtureData = fixtures.map(f => ({
        x: (f.x / 100) * roomDimensions.width,
        y: (f.y / 100) * roomDimensions.length,
        z: roomDimensions.height - 0.5, // 0.5m below ceiling
        ppf: f.model.ppf,
        beamAngle: 120, // Default beam angle
        enabled: f.enabled,
        spectrumData: f.model.spectrumData
      }));
      
      // Calculate PPFD grid
      const grid = calculatePPFDGrid(
        fixtureData,
        roomDimensions.width,
        roomDimensions.length,
        1.0, // Canopy height 1m
        50 // Grid resolution
      );
      
      setPpfdData(grid);
    } else {
      // Empty grid
      const emptyGrid = Array(50).fill(null).map(() => Array(50).fill(0));
      setPpfdData(emptyGrid);
    }
  }, [fixtures, roomDimensions]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (selectedTool === 'place') {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width * 100;
      const y = (e.clientY - rect.top) / rect.height * 100;
      
      // Add a default fixture
      const newFixture: Fixture = {
        id: `fixture-${Date.now()}`,
        x,
        y,
        rotation: 0,
        model: {
          id: 'default-led',
          brand: 'Generic',
          model: '600W LED',
          wattage: 600,
          ppf: 1600,
          efficacy: 2.67,
          spectrumData: {
            red: 65,
            blue: 20,
            green: 10,
            farRed: 5
          },
          coverage: 16 // 4x4 feet
        },
        enabled: true
      };
      
      setFixtures([...fixtures, newFixture]);
    }
  };

  return (
    <div className="absolute inset-0 p-4">
      <div className="relative w-full h-full">
        {showPPFDMap ? (
          <div className="w-full h-full">
            <FalseColorPPFDMap
              width={roomDimensions.width}
              height={roomDimensions.height}
              ppfdData={ppfdData}
              colorScale="turbo"
              showGrid={true}
              showContours={true}
              showLabels={false}
              targetPPFD={600}
            />
            <div 
              className="absolute inset-0 cursor-crosshair" 
              onClick={handleCanvasClick}
            >
              {/* Fixture overlays */}
              {fixtures.map(fixture => (
                <div
                  key={fixture.id}
                  className="absolute w-8 h-8 bg-white/20 border-2 border-white rounded-full"
                  style={{
                    left: `${fixture.x * 100}%`,
                    top: `${fixture.y * 100}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-500">
            <div className="text-center">
              <Package className="w-16 h-16 mx-auto mb-4 text-gray-600" />
              <p className="text-lg font-medium">Design Canvas</p>
              <p className="text-sm mt-2">Click "Place Fixture" to start designing</p>
            </div>
          </div>
        )}
        
        {/* Canvas controls */}
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <button
            onClick={() => setShowPPFDMap(!showPPFDMap)}
            className={`px-3 py-2 rounded flex items-center gap-2 transition-colors ${
              showPPFDMap 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-800 text-gray-400 hover:text-white'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span className="text-sm">PPFD Map</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function HelpModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full mx-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-white">Keyboard Shortcuts</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h3 className="text-sm font-semibold text-purple-400 mb-2">Tools</h3>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Select Tool</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">V</kbd>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Place Fixture</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">P</kbd>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Rotate</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">R</kbd>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-purple-400 mb-2">Actions</h3>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Save Project</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘S</kbd>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Undo</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘Z</kbd>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Redo</span>
                <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘⇧Z</kbd>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}