"use client"

import { useState, useEffect } from 'react'

export default function TestReact() {
  const [count, setCount] = useState(0)
  const [mounted, setMounted] = useState(false)
  
  useEffect(() => {
    setMounted(true)
    console.log('TestReact component mounted')
  }, [])
  
  // Force client-side only rendering to avoid hydration issues
  if (!mounted) {
    return (
      <div style={{ padding: '2rem', color: 'white' }}>
        <h1>Loading React Test...</h1>
      </div>
    )
  }
  
  return (
    <div style={{ 
      minHeight: '100vh', 
      backgroundColor: '#000', 
      color: '#fff', 
      padding: '2rem',
      fontFamily: 'sans-serif'
    }}>
      <h1 style={{ marginBottom: '2rem' }}>React Event Test</h1>
      
      <div style={{ marginBottom: '2rem' }}>
        <p>Count: {count}</p>
        <p>Mounted: {mounted ? 'Yes' : 'No'}</p>
        <p>Time: {new Date().toLocaleTimeString()}</p>
      </div>
      
      <button
        onClick={() => {
          console.log('Button clicked, current count:', count)
          setCount(c => c + 1)
        }}
        style={{
          padding: '1rem 2rem',
          backgroundColor: '#8b5cf6',
          color: 'white',
          border: 'none',
          borderRadius: '0.5rem',
          cursor: 'pointer',
          fontSize: '1rem',
          marginRight: '1rem'
        }}
      >
        Increment Count
      </button>
      
      <button
        onClick={() => {
          console.log('Alert button clicked')
          window.alert('React onClick works!')
        }}
        style={{
          padding: '1rem 2rem',
          backgroundColor: '#10b981',
          color: 'white',
          border: 'none',
          borderRadius: '0.5rem',
          cursor: 'pointer',
          fontSize: '1rem'
        }}
      >
        Show Alert
      </button>
      
      <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#1a1a1a', borderRadius: '0.5rem' }}>
        <h3>Instructions:</h3>
        <ol>
          <li>Open browser console (F12)</li>
          <li>Click the buttons</li>
          <li>Check if count increases and console logs appear</li>
        </ol>
      </div>
    </div>
  )
}