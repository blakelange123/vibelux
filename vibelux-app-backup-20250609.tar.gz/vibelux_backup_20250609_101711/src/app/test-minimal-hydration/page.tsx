"use client"

import { useState, useEffect } from 'react'

export default function TestMinimalHydration() {
  const [status, setStatus] = useState('initial')
  
  useEffect(() => {
    console.log('[TestMinimalHydration] Effect running')
    setStatus('mounted')
    
    // Log React version
    const React = require('react')
    console.log('[TestMinimalHydration] React version:', React.version)
    
    // Check if we're in browser
    console.log('[TestMinimalHydration] typeof window:', typeof window)
    console.log('[TestMinimalHydration] typeof document:', typeof document)
    
    // Try to access DOM directly
    const button = document.getElementById('test-button')
    if (button) {
      console.log('[TestMinimalHydration] Found button element')
      button.addEventListener('click', () => {
        console.log('[TestMinimalHydration] Native click event fired!')
      })
    }
  }, [])
  
  return (
    <div style={{ padding: '2rem', color: 'white' }}>
      <h1>Minimal Hydration Test</h1>
      <p>Status: {status}</p>
      <button
        id="test-button"
        onClick={() => {
          console.log('[TestMinimalHydration] React onClick fired!')
          setStatus('clicked')
        }}
        style={{
          padding: '1rem 2rem',
          backgroundColor: '#8b5cf6',
          color: 'white',
          border: 'none',
          borderRadius: '0.5rem',
          cursor: 'pointer'
        }}
      >
        Click Me
      </button>
      
      <script dangerouslySetInnerHTML={{
        __html: `
          console.log('[Inline Script] Running');
          window.addEventListener('load', () => {
            console.log('[Inline Script] Window loaded');
            const btn = document.getElementById('test-button');
            if (btn) {
              console.log('[Inline Script] Button found:', btn);
            }
          });
        `
      }} />
    </div>
  )
}