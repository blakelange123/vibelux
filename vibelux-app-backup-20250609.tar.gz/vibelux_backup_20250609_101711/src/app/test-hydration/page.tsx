"use client"

import { useState, useEffect } from 'react'

export default function TestHydration() {
  const [isClient, setIsClient] = useState(false)
  
  useEffect(() => {
    setIsClient(true)
  }, [])
  
  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-4">Hydration Test</h1>
      
      <div className="space-y-4">
        <p>Is Client: {isClient ? 'Yes ✅' : 'No ❌'}</p>
        <p>React Version: {isClient && (window as any).React?.version}</p>
        
        {isClient ? (
          <div>
            <p className="text-green-400 mb-4">Client-side rendered - events should work!</p>
            <button
              onClick={() => alert('Client-side button works!')}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded"
            >
              Test Client Button
            </button>
          </div>
        ) : (
          <p className="text-yellow-400">Server-side rendered - waiting for hydration...</p>
        )}
      </div>
    </div>
  )
}