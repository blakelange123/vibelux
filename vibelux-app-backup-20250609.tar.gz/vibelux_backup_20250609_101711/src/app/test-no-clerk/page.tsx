"use client"

import { useState, useEffect } from 'react'

export default function TestNoClerk() {
  const [mounted, setMounted] = useState(false)
  const [hydrated, setHydrated] = useState(false)
  const [clickCount, setClickCount] = useState(0)
  
  useEffect(() => {
    console.log('TestNoClerk: useEffect running')
    setMounted(true)
    
    // Check hydration status
    if (typeof window !== 'undefined') {
      setHydrated(true)
      console.log('TestNoClerk: Hydrated successfully')
    }
    
    // Add a global click listener to verify events work
    const handleGlobalClick = (e: MouseEvent) => {
      console.log('Global click detected at:', e.clientX, e.clientY)
    }
    window.addEventListener('click', handleGlobalClick)
    
    return () => window.removeEventListener('click', handleGlobalClick)
  }, [])
  
  const handleButtonClick = () => {
    console.log('Button clicked! Count:', clickCount)
    setClickCount(prev => prev + 1)
  }
  
  // Also test with a ref-based approach
  const handleRefClick = (e: React.MouseEvent) => {
    console.log('Ref-based click detected')
    e.currentTarget.textContent = 'Clicked!'
  }
  
  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-6">Test Without Clerk</h1>
      
      <div className="mb-8 p-4 bg-gray-900 rounded-lg">
        <h2 className="text-xl mb-4">Component Status:</h2>
        <p className="mb-2">Mounted: <span className={mounted ? 'text-green-500' : 'text-red-500'}>{mounted ? '✅ Yes' : '❌ No'}</span></p>
        <p className="mb-2">Hydrated: <span className={hydrated ? 'text-green-500' : 'text-red-500'}>{hydrated ? '✅ Yes' : '❌ No'}</span></p>
        <p className="mb-2">Click Count: <span className="text-blue-400">{clickCount}</span></p>
        <p className="text-sm text-gray-400">Time: {new Date().toLocaleTimeString()}</p>
      </div>
      
      <div className="space-y-4">
        <button
          onClick={handleButtonClick}
          className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors"
        >
          Test onClick Handler
        </button>
        
        <button
          onClick={handleRefClick}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors ml-4"
        >
          Test Ref Click
        </button>
        
        <div className="mt-8 p-4 bg-gray-900 rounded-lg">
          <h3 className="font-bold mb-2">Console Output Expected:</h3>
          <ul className="list-disc list-inside text-sm text-gray-400">
            <li>On page load: "TestNoClerk: useEffect running" and "TestNoClerk: Hydrated successfully"</li>
            <li>On any click: "Global click detected at: X Y"</li>
            <li>On purple button click: "Button clicked! Count: N"</li>
            <li>On blue button click: "Ref-based click detected" (and text changes)</li>
          </ul>
        </div>
      </div>
      
      <div className="mt-8 p-4 bg-yellow-900 rounded-lg">
        <p className="text-yellow-300">
          ⚠️ This page intentionally bypasses the root layout to test without ClerkProvider
        </p>
      </div>
    </div>
  )
}