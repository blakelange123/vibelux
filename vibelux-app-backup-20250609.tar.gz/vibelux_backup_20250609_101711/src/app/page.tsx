"use client"

import Link from 'next/link'
import { useState, useEffect, useRef } from 'react'
import { 
  ArrowRight, 
  Check,
  Sparkles,
  Brain,
  BarChart3,
  Shield,
  Globe,
  Zap,
  ChevronDown,
  Menu,
  X,
  Play,
  Minus,
  Activity
} from 'lucide-react'

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const menuButtonRef = useRef<HTMLButtonElement>(null)
  
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  // Use ref to attach click handler
  useEffect(() => {
    const button = menuButtonRef.current
    if (button) {
      const handleClick = () => {
        console.log('Menu button clicked via ref')
        setMobileMenuOpen(prev => !prev)
      }
      button.addEventListener('click', handleClick)
      return () => button.removeEventListener('click', handleClick)
    }
  }, [])
  

  return (
    <div className="min-h-screen relative">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${
        scrolled ? 'glass-dark border-b border-white/10 shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-purple-400" />
              <span className="text-2xl font-bold text-white tracking-tight">Vibelux</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              <Link href="/features" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Features
              </Link>
              <Link href="/pricing" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Pricing
              </Link>
              <Link href="/case-studies" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Case Studies
              </Link>
              <Link href="/docs" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Docs
              </Link>
              <Link href="/blog" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Blog
              </Link>
            </div>
            
            {/* CTA Buttons */}
            <div className="hidden md:flex items-center gap-4">
              <Link href="/sign-in" className="text-gray-300 hover:text-white transition-colors text-[15px] font-medium">
                Sign In
              </Link>
              <Link 
                href="/sign-up" 
                className="px-6 py-3 btn-purple-gradient text-white rounded-full text-[15px] font-semibold hover:shadow-purple-lg transition-all duration-300"
              >
                Start Free Trial
              </Link>
            </div>
            
            {/* Mobile Menu Button */}
            <button
              ref={menuButtonRef}
              className="md:hidden p-2 text-gray-300 hover:text-white relative z-50"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden glass-dark border-t border-white/10 absolute top-full left-0 right-0 z-50">
            <div className="px-6 py-4 space-y-3">
              <Link href="/features" className="block text-gray-300 hover:text-white transition-colors">
                Features
              </Link>
              <Link href="/pricing" className="block text-gray-300 hover:text-white transition-colors">
                Pricing
              </Link>
              <Link href="/case-studies" className="block text-gray-300 hover:text-white transition-colors">
                Case Studies
              </Link>
              <Link href="/docs" className="block text-gray-300 hover:text-white transition-colors">
                Docs
              </Link>
              <Link href="/blog" className="block text-gray-300 hover:text-white transition-colors">
                Blog
              </Link>
              <div className="pt-4 border-t border-gray-800 space-y-3">
                <Link href="/sign-in" className="block text-gray-300 hover:text-white transition-colors">
                  Sign In
                </Link>
                <Link 
                  href="/sign-up" 
                  className="block w-full px-4 py-2 btn-purple-gradient text-white rounded-full text-center font-semibold hover:shadow-purple-lg transition-all"
                >
                  Start Free Trial
                </Link>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-6 overflow-hidden min-h-[90vh] flex items-center">
        
        {/* Animated Gradient Orbs */}
        <div className="absolute top-20 left-1/4 w-[600px] h-[600px] bg-purple-600/20 rounded-full blur-[100px] animate-float" />
        <div className="absolute bottom-20 right-1/4 w-[500px] h-[500px] bg-pink-600/15 rounded-full blur-[120px] animate-float" style={{animationDelay: '1s'}} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-500/10 rounded-full blur-[150px] animate-pulse" />
        
        <div className="relative max-w-6xl mx-auto text-center flex flex-col justify-center">
          <h1 className="text-6xl md:text-7xl lg:text-8xl xl:text-[7rem] font-bold text-white mb-8 tracking-tight leading-[0.85]">
            <span className="block opacity-0 animate-fade-up" style={{animationDelay: '0.1s', animationFillMode: 'forwards'}}>Grow at the</span>
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-300% animate-gradient opacity-0 animate-fade-up" style={{animationDelay: '0.3s', animationFillMode: 'forwards'}}>
              speed of light.
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-12 leading-relaxed font-light opacity-0 animate-fade-up" style={{animationDelay: '0.5s', animationFillMode: 'forwards'}}>
            The most advanced horticultural lighting platform. 
            Design perfect systems in minutes with AI-powered intelligence.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 opacity-0 animate-fade-up" style={{animationDelay: '0.7s', animationFillMode: 'forwards'}}>
            <Link 
              href="/dashboard" 
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-white btn-purple-gradient rounded-full transition-all transform hover:scale-105 hover:shadow-purple-lg"
            >
              Start Free Trial
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <button 
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-medium text-white glass-dark border border-white/10 rounded-full hover:bg-white/10 transition-all"
            >
              <Play className="mr-2 w-5 h-5" />
              Watch Demo
            </button>
          </div>
          
          <div className="flex items-center justify-center gap-8 text-sm text-gray-400 opacity-0 animate-fade-up" style={{animationDelay: '0.9s', animationFillMode: 'forwards'}}>
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              No credit card
            </span>
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              14-day trial
            </span>
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              Cancel anytime
            </span>
          </div>
        </div>
      </section>

      {/* Video/Demo Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-purple-500/20">
            <div className="glass-card p-8 md:p-16">
              <div className="aspect-video glass-dark rounded-2xl flex items-center justify-center border border-white/10">
                <div className="text-center">
                  <div className="w-24 h-24 btn-purple-gradient rounded-full flex items-center justify-center mx-auto mb-6 shadow-purple-lg">
                    <Play className="w-12 h-12 text-white ml-1" />
                  </div>
                  <p className="text-gray-400 text-lg font-light">Product Demo Coming Soon</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
              Everything you need.
              <span className="block text-gray-400 text-3xl md:text-4xl mt-4 font-light">
                Nothing you don't.
              </span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Feature 1 */}
            <div className="relative group feature-card">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl opacity-0 group-hover:opacity-10 transition-opacity duration-500" />
              <div className="relative glass-card rounded-3xl p-10 hover:border-white/20 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600/30 to-pink-600/30 rounded-2xl flex items-center justify-center mb-8 shadow-lg">
                  <Brain className="w-8 h-8 text-purple-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">AI-Powered Design</h3>
                <p className="text-gray-300 leading-relaxed text-lg">
                  Our GPT-4 powered assistant helps you optimize every aspect of your lighting design, 
                  from spectrum selection to energy efficiency.
                </p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="relative group feature-card">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl opacity-0 group-hover:opacity-10 transition-opacity duration-500" />
              <div className="relative glass-card rounded-3xl p-10 hover:border-white/20 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600/30 to-pink-600/30 rounded-2xl flex items-center justify-center mb-8 shadow-lg">
                  <BarChart3 className="w-8 h-8 text-purple-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Advanced Analytics</h3>
                <p className="text-gray-300 leading-relaxed text-lg">
                  Real-time PPFD mapping, spectrum analysis, and 3D visualization give you unprecedented 
                  insight into your lighting performance.
                </p>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="relative group feature-card">
              <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl opacity-0 group-hover:opacity-10 transition-opacity duration-500" />
              <div className="relative glass-card rounded-3xl p-10 hover:border-white/20 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-br from-green-600/30 to-emerald-600/30 rounded-2xl flex items-center justify-center mb-8 shadow-lg">
                  <Shield className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Enterprise Security</h3>
                <p className="text-gray-300 leading-relaxed text-lg">
                  SOC 2 certified with end-to-end encryption. Your data is protected by the same 
                  security standards used by Fortune 500 companies.
                </p>
              </div>
            </div>

            {/* Feature 4 */}
            <div className="relative group feature-card">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-3xl opacity-0 group-hover:opacity-10 transition-opacity duration-500" />
              <div className="relative glass-card rounded-3xl p-10 hover:border-white/20 transition-all duration-500">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600/30 to-cyan-600/30 rounded-2xl flex items-center justify-center mb-8 shadow-lg">
                  <Globe className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Global Database</h3>
                <p className="text-gray-300 leading-relaxed text-lg">
                  Access 1,200+ DLC certified fixtures with real-time updates. The most comprehensive 
                  lighting database in the industry.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Tiers Section */}
      <section className="py-32 px-6 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-gradient-to-tl from-blue-600/20 to-purple-600/20 rounded-full blur-[120px]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-[150px]" />
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 tracking-tight">
              Choose your growth path
            </h2>
            <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Start with our all-in-one plans or build your perfect toolkit with individual modules
            </p>
          </div>
          
          {/* Pricing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className="text-gray-400">Monthly</span>
            <button className="relative w-14 h-8 bg-gray-800 rounded-full p-1 transition-colors hover:bg-gray-700">
              <div className="absolute left-1 top-1 w-6 h-6 bg-white rounded-full transition-transform" />
            </button>
            <span className="text-gray-400">Annual <span className="text-green-400 text-sm font-medium">(Save 20%)</span></span>
          </div>
          
          {/* All-in-One Plans */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full text-purple-400 text-sm font-medium mb-4">
                <Sparkles className="w-4 h-4" />
                All-in-One Plans
              </span>
              <p className="text-gray-400 text-base max-w-2xl mx-auto">
                Complete solutions with everything you need to design professional lighting systems
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {/* Starter Tier */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-gray-600 to-gray-700 rounded-2xl opacity-0 group-hover:opacity-20 blur transition duration-500" />
                <div className="relative bg-black/40 backdrop-blur-xl rounded-2xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300 h-full flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-2xl font-bold text-white">Starter</h3>
                  </div>
                  <p className="text-gray-400 mb-8">Perfect for small grow operations</p>
                  
                  <div className="mb-8">
                    <div className="flex items-baseline gap-1">
                      <span className="text-5xl font-bold text-white">$49</span>
                      <span className="text-gray-400 text-lg">/month</span>
                    </div>
                  </div>
                  
                  <div className="space-y-4 flex-grow mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-400" />
                      </div>
                      <span className="text-gray-300">Up to 5 room designs</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-400" />
                      </div>
                      <span className="text-gray-300">Basic 2D design tools</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-400" />
                      </div>
                      <span className="text-gray-300">PPFD heatmap visualization</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-400" />
                      </div>
                      <span className="text-gray-300">500+ DLC certified fixtures</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-green-400" />
                      </div>
                      <span className="text-gray-300">Email support</span>
                    </div>
                  </div>
                  
                  <Link 
                    href="/sign-up?plan=starter" 
                    className="w-full py-3 px-6 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-center font-semibold transition-all duration-300"
                  >
                    Get Started
                  </Link>
                </div>
              </div>

              {/* Professional Tier */}
              <div className="relative group transform md:scale-105">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl opacity-75 blur transition duration-500 group-hover:opacity-100" />
                <div className="relative bg-black/40 backdrop-blur-xl rounded-2xl p-8 border border-purple-500/30 hover:border-purple-400/50 transition-all duration-300 h-full flex flex-col">
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-white text-sm font-semibold shadow-lg">
                    MOST POPULAR
                  </div>
                  
                  <div className="flex items-center justify-between mb-4 pt-2">
                    <h3 className="text-2xl font-bold text-white">Professional</h3>
                  </div>
                  <p className="text-gray-400 mb-8">For serious commercial growers</p>
                  
                  <div className="mb-8">
                    <div className="flex items-baseline gap-1">
                      <span className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">$149</span>
                      <span className="text-gray-400 text-lg">/month</span>
                    </div>
                  </div>
                  
                  <div className="space-y-4 flex-grow mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-purple-400" />
                      </div>
                      <span className="text-gray-300">Unlimited room designs</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-purple-400" />
                      </div>
                      <span className="text-gray-300">Advanced 3D visualization</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-purple-400" />
                      </div>
                      <span className="text-gray-300">AI-powered design assistant</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-purple-400" />
                      </div>
                      <span className="text-gray-300">1,200+ premium fixtures</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-purple-400" />
                      </div>
                      <span className="text-gray-300">Priority support</span>
                    </div>
                  </div>
                  
                  <Link 
                    href="/sign-up?plan=professional" 
                    className="w-full py-3 px-6 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-xl text-center font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]"
                  >
                    Start Free Trial
                  </Link>
                </div>
              </div>

              {/* Enterprise Tier */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-amber-600 to-orange-600 rounded-2xl opacity-0 group-hover:opacity-20 blur transition duration-500" />
                <div className="relative bg-black/40 backdrop-blur-xl rounded-2xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300 h-full flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-2xl font-bold text-white">Enterprise</h3>
                  </div>
                  <p className="text-gray-400 mb-8">For large-scale operations</p>
                  
                  <div className="mb-8">
                    <div className="flex items-baseline gap-1">
                      <span className="text-5xl font-bold text-white">Custom</span>
                    </div>
                    <p className="text-gray-400 mt-2">Tailored to your needs</p>
                  </div>
                  
                  <div className="space-y-4 flex-grow mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-gray-300">Unlimited everything</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-gray-300">White-label branding</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-gray-300">Custom integrations</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-gray-300">Dedicated account team</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-amber-400" />
                      </div>
                      <span className="text-gray-300">SLA guarantee</span>
                    </div>
                  </div>
                  
                  <Link 
                    href="/contact-sales" 
                    className="w-full py-3 px-6 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-center font-semibold transition-all duration-300"
                  >
                    Contact Sales
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Individual Modules Section */}
          <div className="mt-24">
            <div className="text-center mb-12">
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-sm font-medium mb-4">
                <Activity className="w-4 h-4" />
                Individual Modules
              </span>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">
                Build Your Perfect Toolkit
              </h3>
              <p className="text-gray-400 text-base max-w-2xl mx-auto">
                Choose only what you need. Mix and match modules to create your ideal setup.
              </p>
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
              {/* Electrical Designer Module */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-600/50 to-amber-600/50 rounded-xl opacity-0 group-hover:opacity-100 blur transition duration-300" />
                <div className="relative bg-black/60 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-yellow-500/30 transition-all duration-300 h-full flex flex-col">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-600/20 to-amber-600/20 rounded-lg flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-yellow-400" />
                  </div>
                  
                  <h4 className="text-lg font-semibold text-white mb-2">Electrical Designer</h4>
                  <p className="text-gray-400 text-sm mb-4 flex-grow">Automated electrical planning & compliance</p>
                  
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-2xl font-bold text-white">$29</span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                  
                  <button className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-lg text-sm font-medium transition-all duration-300">
                    Add Module
                  </button>
                </div>
              </div>

              {/* TCO Analyzer Module */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-green-600/50 to-emerald-600/50 rounded-xl opacity-0 group-hover:opacity-100 blur transition duration-300" />
                <div className="relative bg-black/60 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-green-500/30 transition-all duration-300 h-full flex flex-col">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-lg flex items-center justify-center mb-4">
                    <BarChart3 className="w-6 h-6 text-green-400" />
                  </div>
                  
                  <h4 className="text-lg font-semibold text-white mb-2">TCO Analyzer</h4>
                  <p className="text-gray-400 text-sm mb-4 flex-grow">ROI calculations & cost projections</p>
                  
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-2xl font-bold text-white">$39</span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                  
                  <button className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-lg text-sm font-medium transition-all duration-300">
                    Add Module
                  </button>
                </div>
              </div>

              {/* Spectrum Designer Module */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600/50 to-pink-600/50 rounded-xl opacity-0 group-hover:opacity-100 blur transition duration-300" />
                <div className="relative bg-black/60 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-purple-500/30 transition-all duration-300 h-full flex flex-col">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-lg flex items-center justify-center mb-4">
                    <Activity className="w-6 h-6 text-purple-400" />
                  </div>
                  
                  <h4 className="text-lg font-semibold text-white mb-2">Spectrum Designer</h4>
                  <p className="text-gray-400 text-sm mb-4 flex-grow">Optimize light spectrums for growth</p>
                  
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-2xl font-bold text-white">$19</span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                  
                  <button className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-lg text-sm font-medium transition-all duration-300">
                    Add Module
                  </button>
                </div>
              </div>

              {/* AI Design Assistant Module */}
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600/50 to-cyan-600/50 rounded-xl opacity-0 group-hover:opacity-100 blur transition duration-300" />
                <div className="relative bg-black/60 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-blue-500/30 transition-all duration-300 h-full flex flex-col">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600/20 to-cyan-600/20 rounded-lg flex items-center justify-center mb-4">
                    <Brain className="w-6 h-6 text-blue-400" />
                  </div>
                  
                  <h4 className="text-lg font-semibold text-white mb-2">AI Assistant</h4>
                  <p className="text-gray-400 text-sm mb-4 flex-grow">GPT-4 powered design intelligence</p>
                  
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-2xl font-bold text-white">$49</span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                  
                  <button className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-lg text-sm font-medium transition-all duration-300">
                    Add Module
                  </button>
                </div>
              </div>
            </div>
            
            {/* Bundle Discount Message */}
            <div className="mt-8 text-center">
              <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-500/10 border border-purple-500/20 rounded-full">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-purple-400 text-sm font-medium">Bundle 3+ modules and save 25%</span>
              </div>
            </div>
          </div>

          {/* Comprehensive Feature Comparison Table */}
          <div className="mt-24">
            <h3 className="text-3xl font-bold text-white text-center mb-12">
              Detailed Feature Comparison
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left py-4 px-6 text-gray-400 font-medium">Features</th>
                    <th className="text-center py-4 px-6 text-white font-bold text-lg">Starter</th>
                    <th className="text-center py-4 px-6 text-white font-bold text-lg">Professional</th>
                    <th className="text-center py-4 px-6 text-white font-bold text-lg">Enterprise</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Design & Visualization */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6">
                      <h4 className="text-lg font-semibold text-purple-400">Design & Visualization</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Room designs</td>
                    <td className="text-center py-4 px-6 text-gray-400">5</td>
                    <td className="text-center py-4 px-6 text-gray-300">Unlimited</td>
                    <td className="text-center py-4 px-6 text-gray-300">Unlimited</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">2D design tools</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">3D visualization</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">3D walkthrough mode</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Room templates</td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced</td>
                    <td className="text-center py-4 px-6 text-gray-300">Custom</td>
                  </tr>

                  {/* Analysis & Optimization */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Analysis & Optimization</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">PPFD heatmap</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">AI design assistant</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Spectrum analysis</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">VPD calculations</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Energy cost calculator</td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced + ROI</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Electrical planning</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">HVAC integration</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>

                  {/* Fixture Library & Database */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Fixture Library & Database</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">DLC certified fixtures</td>
                    <td className="text-center py-4 px-6 text-gray-400">500+</td>
                    <td className="text-center py-4 px-6 text-gray-300">1,200+</td>
                    <td className="text-center py-4 px-6 text-gray-300">1,200+</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Custom fixture upload</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">5</td>
                    <td className="text-center py-4 px-6 text-gray-300">Unlimited</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Fixture comparison tool</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Private fixture library</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>

                  {/* Export & Reporting */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Export & Reporting</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">PDF reports</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">DWG/CAD export</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">IES file export</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">AGi32 integration</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Custom report branding</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>

                  {/* Collaboration & Teams */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Collaboration & Teams</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Team members</td>
                    <td className="text-center py-4 px-6 text-gray-400">1</td>
                    <td className="text-center py-4 px-6 text-gray-300">5</td>
                    <td className="text-center py-4 px-6 text-gray-300">Unlimited</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Project sharing</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Real-time collaboration</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Version history</td>
                    <td className="text-center py-4 px-6 text-gray-400">7 days</td>
                    <td className="text-center py-4 px-6 text-gray-300">30 days</td>
                    <td className="text-center py-4 px-6 text-gray-300">Unlimited</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Role-based permissions</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced</td>
                  </tr>

                  {/* Support & Training */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Support & Training</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Email support</td>
                    <td className="text-center py-4 px-6 text-gray-400">48hr response</td>
                    <td className="text-center py-4 px-6 text-gray-300">Priority</td>
                    <td className="text-center py-4 px-6 text-gray-300">Priority</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Chat support</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Phone support</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-300">24/7</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Training webinars</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-300">Monthly</td>
                    <td className="text-center py-4 px-6 text-gray-300">Custom</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Onboarding assistance</td>
                    <td className="text-center py-4 px-6 text-gray-400">Self-service</td>
                    <td className="text-center py-4 px-6 text-gray-300">Guided</td>
                    <td className="text-center py-4 px-6 text-gray-300">White-glove</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Dedicated account manager</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>

                  {/* API & Integrations */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">API & Integrations</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">API access</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">Read-only</td>
                    <td className="text-center py-4 px-6 text-gray-300">Full access</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Webhooks</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Third-party integrations</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Custom</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Bulk operations</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>

                  {/* Security & Compliance */}
                  <tr className="border-b border-white/5">
                    <td colSpan={4} className="py-4 px-6 pt-8">
                      <h4 className="text-lg font-semibold text-purple-400">Security & Compliance</h4>
                    </td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Data encryption</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Two-factor authentication</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">SSO/SAML</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">SOC 2 compliance</td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Custom security policies</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6"><Check className="w-5 h-5 text-green-400 mx-auto" /></td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">Audit logs</td>
                    <td className="text-center py-4 px-6"><X className="w-5 h-5 text-gray-600 mx-auto" /></td>
                    <td className="text-center py-4 px-6 text-gray-400">Basic</td>
                    <td className="text-center py-4 px-6 text-gray-300">Advanced</td>
                  </tr>
                  <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-4 px-6 text-gray-300">SLA guarantee</td>
                    <td className="text-center py-4 px-6 text-gray-400">99%</td>
                    <td className="text-center py-4 px-6 text-gray-300">99.9%</td>
                    <td className="text-center py-4 px-6 text-gray-300">99.99%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Feature Comparison Link */}
          <div className="text-center mt-12">
            <Link 
              href="/pricing" 
              className="text-purple-400 hover:text-purple-300 font-medium text-lg inline-flex items-center gap-2 transition-colors"
            >
              See full pricing details
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-purple-500/20">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-20" />
            <div className="relative glass-card rounded-3xl p-16 border border-white/20">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                  <h3 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-3">10k+</h3>
                  <p className="text-gray-300 text-lg">Active Users</p>
                </div>
                <div>
                  <h3 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-3">99.9%</h3>
                  <p className="text-gray-300 text-lg">Uptime SLA</p>
                </div>
                <div>
                  <h3 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-3">1.2k+</h3>
                  <p className="text-gray-300 text-lg">DLC Fixtures</p>
                </div>
                <div>
                  <h3 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-3">24/7</h3>
                  <p className="text-gray-300 text-lg">AI Support</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-6xl md:text-7xl font-bold text-white mb-10 tracking-tight">
            Ready to transform your grow?
          </h2>
          <p className="text-2xl md:text-3xl text-gray-300 mb-16 font-light max-w-3xl mx-auto">
            Join thousands of growers using Vibelux to maximize yields and minimize costs.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/dashboard" 
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-white btn-purple-gradient rounded-full transition-all transform hover:scale-105 hover:shadow-purple-lg"
            >
              Start Your Free Trial
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link 
              href="/contact" 
              className="inline-flex items-center justify-center px-8 py-4 text-lg font-medium text-white glass-dark border border-white/10 rounded-full hover:bg-white/10 transition-all"
            >
              Talk to Sales
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black backdrop-blur-xl border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 md:gap-12 mb-12">
            <div className="col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-8 h-8 text-purple-400" />
                <span className="text-2xl font-bold text-white">Vibelux</span>
              </div>
              <p className="text-gray-400 text-base leading-relaxed max-w-md">
                The industry's most comprehensive horticultural lighting platform. 
                Design perfect lighting systems in minutes, not hours.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-6 text-base tracking-wide">Product</h4>
              <ul className="space-y-3">
                <li><Link href="/features" className="text-gray-400 hover:text-white transition-colors text-base">Features</Link></li>
                <li><Link href="/pricing" className="text-gray-400 hover:text-white transition-colors text-base">Pricing</Link></li>
                <li><Link href="/changelog" className="text-gray-400 hover:text-white transition-colors text-base">Changelog</Link></li>
                <li><Link href="/roadmap" className="text-gray-400 hover:text-white transition-colors text-base">Roadmap</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-6 text-base tracking-wide">Resources</h4>
              <ul className="space-y-3">
                <li><Link href="/docs" className="text-gray-400 hover:text-white transition-colors text-base">Documentation</Link></li>
                <li><Link href="/api" className="text-gray-400 hover:text-white transition-colors text-base">API</Link></li>
                <li><Link href="/guides" className="text-gray-400 hover:text-white transition-colors text-base">Guides</Link></li>
                <li><Link href="/community-forum" className="text-gray-400 hover:text-white transition-colors text-base">Community</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-white mb-6 text-base tracking-wide">Company</h4>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors text-base">About</Link></li>
                <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors text-base">Blog</Link></li>
                <li><Link href="/careers" className="text-gray-400 hover:text-white transition-colors text-base">Careers</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors text-base">Contact</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-base">© 2024 Vibelux. All rights reserved.</p>
            <div className="flex gap-8 mt-6 md:mt-0">
              <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors text-base">Privacy</Link>
              <Link href="/terms" className="text-gray-400 hover:text-white transition-colors text-base">Terms</Link>
              <Link href="/security" className="text-gray-400 hover:text-white transition-colors text-base">Security</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}