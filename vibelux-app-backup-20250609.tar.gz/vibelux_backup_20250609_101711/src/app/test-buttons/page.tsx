"use client"

import { useState } from 'react'

export default function TestButtons() {
  const [count, setCount] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-2xl mb-8">Button Test Page</h1>
      
      <div className="space-y-4">
        <button 
          onClick={() => {
            console.log('Count button clicked')
            setCount(count + 1)
          }}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded"
        >
          Count: {count}
        </button>
        
        <button 
          onClick={() => {
            console.log('Menu button clicked')
            setMenuOpen(!menuOpen)
          }}
          className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded block"
        >
          Menu: {menuOpen ? 'Open' : 'Closed'}
        </button>
        
        <button 
          onClick={() => {
            console.log('Alert button clicked')
            alert('Button works!')
          }}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded block"
        >
          Test Alert
        </button>
        
        <div className="mt-8 p-4 border border-gray-600 rounded">
          <p>If these buttons don't work, there's a JavaScript/React issue.</p>
          <p>Check the browser console for errors.</p>
        </div>
      </div>
    </div>
  )
}