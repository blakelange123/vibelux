'use client';

export default function TestJSPage() {
  return (
    <div style={{ padding: '50px' }}>
      <h1>JavaScript Test Page</h1>
      
      <button 
        onClick={() => alert('Button clicked!')}
        style={{ 
          padding: '10px 20px',
          fontSize: '16px',
          backgroundColor: 'blue',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
          marginRight: '10px'
        }}
      >
        Click Me (Alert)
      </button>
      
      <button 
        onClick={() => console.log('Console log test')}
        style={{ 
          padding: '10px 20px',
          fontSize: '16px',
          backgroundColor: 'green',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer'
        }}
      >
        Click Me (Console)
      </button>
      
      <div style={{ marginTop: '20px' }}>
        <p>If these buttons don't work, JavaScript is not executing properly.</p>
        <p>Check the browser console for errors (F12 → Console tab)</p>
      </div>
    </div>
  );
}