import { CommunityForum } from '@/components/CommunityForum'

export default function CommunityForumPage() {
  return <CommunityForum />
}