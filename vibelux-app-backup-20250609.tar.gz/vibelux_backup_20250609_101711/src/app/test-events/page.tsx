"use client"

import { useState, useRef, useEffect } from 'react'

export default function TestEvents() {
  const [count, setCount] = useState(0)
  const [refCount, setRefCount] = useState(0)
  const buttonRef = useRef<HTMLButtonElement>(null)
  
  useEffect(() => {
    const button = buttonRef.current
    if (button) {
      const handleClick = () => {
        console.log('Ref click handler fired')
        setRefCount(prev => prev + 1)
      }
      button.addEventListener('click', handleClick)
      return () => button.removeEventListener('click', handleClick)
    }
  }, [])
  
  const handleDirectClick = () => {
    console.log('Direct onClick handler fired')
    setCount(prev => prev + 1)
  }
  
  // Test various event attachment methods
  useEffect(() => {
    // Test global event
    const handleGlobalClick = (e: MouseEvent) => {
      console.log('Global click detected:', e.target)
    }
    document.addEventListener('click', handleGlobalClick)
    return () => document.removeEventListener('click', handleGlobalClick)
  }, [])
  
  return (
    <div className="min-h-screen bg-black text-white p-8">
      <h1 className="text-3xl font-bold mb-8">Event Handler Test</h1>
      
      <div className="space-y-8">
        {/* Test 1: Direct onClick */}
        <div className="p-6 bg-gray-900 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Test 1: Direct onClick Handler</h2>
          <button 
            onClick={handleDirectClick}
            className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors"
          >
            Click Me (Direct)
          </button>
          <p className="mt-4">Count: {count}</p>
        </div>
        
        {/* Test 2: Ref-based event listener */}
        <div className="p-6 bg-gray-900 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Test 2: Ref-based Event Listener</h2>
          <button 
            ref={buttonRef}
            className="px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
          >
            Click Me (Ref)
          </button>
          <p className="mt-4">Ref Count: {refCount}</p>
        </div>
        
        {/* Test 3: Inline onClick */}
        <div className="p-6 bg-gray-900 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Test 3: Inline onClick</h2>
          <button 
            onClick={() => {
              console.log('Inline onClick fired')
              alert('Inline onClick works!')
            }}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            Click Me (Inline)
          </button>
        </div>
        
        {/* Test 4: Z-index test */}
        <div className="p-6 bg-gray-900 rounded-lg relative">
          <h2 className="text-xl font-semibold mb-4">Test 4: High Z-index Button</h2>
          <button 
            onClick={() => alert('High z-index button clicked!')}
            className="px-6 py-3 bg-yellow-600 hover:bg-yellow-700 rounded-lg transition-colors"
            style={{ position: 'relative', zIndex: 999999 }}
          >
            Click Me (Z-index: 999999)
          </button>
        </div>
      </div>
      
      {/* Floating button like AI Assistant */}
      <button
        onClick={() => alert('Floating button clicked!')}
        className="fixed bottom-6 right-6 p-4 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-full shadow-lg hover:shadow-xl transform transition-all duration-300 hover:scale-110"
        style={{ zIndex: 999999 }}
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>
    </div>
  )
}