import { EnhancedTCOCalculator } from '@/components/EnhancedTCOCalculator'

export default function TCOCalculatorPage() {
  return <EnhancedTCOCalculator />
}