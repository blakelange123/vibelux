import { EquipmentLeasingCalculator } from '@/components/EquipmentLeasingCalculator'

export default function EquipmentLeasingPage() {
  return <EquipmentLeasingCalculator />
}