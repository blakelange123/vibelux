import { UtilityRebateCalculator } from '@/components/UtilityRebateCalculator'

export default function RebateCalculatorPage() {
  return <UtilityRebateCalculator />
}