'use client';

import { Component, MouseEvent } from 'react';

// Class component to test if it's a React 19 issue
class ClassButton extends Component<{}, { count: number }> {
  constructor(props: {}) {
    super(props);
    this.state = { count: 0 };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    console.log('Class component click!');
    this.setState({ count: this.state.count + 1 });
  }

  render() {
    return (
      <button
        onClick={this.handleClick}
        style={{
          padding: '10px 20px',
          backgroundColor: '#8b5cf6',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
          marginRight: '10px'
        }}
      >
        Class Component (Count: {this.state.count})
      </button>
    );
  }
}

// Functional component with basic handler
function FunctionalButton() {
  const handleClick = (e: MouseEvent<HTMLButtonElement>) => {
    console.log('Functional component click!', e);
    alert('Functional component clicked!');
  };

  return (
    <button
      onClick={handleClick}
      style={{
        padding: '10px 20px',
        backgroundColor: '#06b6d4',
        color: 'white',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
        marginRight: '10px'
      }}
    >
      Functional Component
    </button>
  );
}

// Main component
export default function TestReactBasicPage() {
  // Test direct DOM manipulation
  const testDirectDOM = () => {
    const button = document.createElement('button');
    button.textContent = 'Dynamic Button';
    button.style.padding = '10px 20px';
    button.style.backgroundColor = '#f59e0b';
    button.style.color = 'white';
    button.style.border = 'none';
    button.style.borderRadius = '5px';
    button.style.cursor = 'pointer';
    button.onclick = () => alert('Dynamic button clicked!');
    
    const container = document.getElementById('dynamic-container');
    if (container) {
      container.appendChild(button);
    }
  };

  return (
    <div style={{ padding: '50px' }}>
      <h1>React Basic Event Test</h1>
      
      <div style={{ marginBottom: '20px' }}>
        <h2>Different React Patterns:</h2>
        
        <ClassButton />
        <FunctionalButton />
        
        <button
          onClick={() => console.log('Arrow function click!')}
          style={{
            padding: '10px 20px',
            backgroundColor: '#ec4899',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginRight: '10px'
          }}
        >
          Arrow Function
        </button>
        
        <button
          onClick={function() { console.log('Regular function click!'); }}
          style={{
            padding: '10px 20px',
            backgroundColor: '#84cc16',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Regular Function
        </button>
      </div>
      
      <div style={{ marginBottom: '20px' }}>
        <h2>Direct DOM Manipulation:</h2>
        <button
          onClick={testDirectDOM}
          style={{
            padding: '10px 20px',
            backgroundColor: '#6366f1',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Add Dynamic Button
        </button>
        <div id="dynamic-container" style={{ marginTop: '10px' }}></div>
      </div>
      
      <div style={{ marginTop: '20px' }}>
        <h2>Native HTML Button:</h2>
        <button
          type="button"
          {...{ onClick: () => alert('Native HTML button clicked!') }}
        >
          Native HTML Button
        </button>
      </div>
      
      {/* Test with dangerouslySetInnerHTML */}
      <div
        dangerouslySetInnerHTML={{
          __html: `
            <h2 style="margin-top: 20px;">Inline HTML Button:</h2>
            <button onclick="alert('Inline HTML onclick works!')" style="padding: 10px 20px; cursor: pointer;">
              Inline HTML onClick
            </button>
          `
        }}
      />
    </div>
  );
}