'use client'

import { AIAssistant } from '@/components/AIAssistant'

export default function TestAI() {
  return (
    <div className="min-h-screen p-8">
      <h1 className="text-2xl font-bold text-white mb-4">AI Assistant Test Page</h1>
      <p className="text-gray-400 mb-8">The AI Assistant button should appear in the bottom right corner.</p>
      
      <div className="bg-gray-800 p-4 rounded-lg">
        <h2 className="text-lg font-semibold text-white mb-2">Test Status:</h2>
        <ul className="list-disc list-inside text-gray-300">
          <li>AI Assistant component imported successfully</li>
          <li>Component should render a floating button (bottom-right)</li>
          <li>Button has z-50 class for proper layering</li>
        </ul>
      </div>

      {/* Force render the AI Assistant */}
      <AIAssistant />
    </div>
  )
}