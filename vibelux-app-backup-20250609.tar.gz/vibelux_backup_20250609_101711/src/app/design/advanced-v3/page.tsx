'use client';

import { AdvancedDesignerV2 } from '@/components/AdvancedDesignerV2';
import { useState, useEffect } from 'react';

export default function AdvancedDesignerV3Page() {
  const [devPanelHidden, setDevPanelHidden] = useState(false);
  
  // Hide/show the navigation directly via CSS
  useEffect(() => {
    const nav = document.querySelector('nav');
    const mainContent = document.querySelector('main') || document.querySelector('div[class*="ml-64"]');
    
    if (nav && mainContent) {
      if (devPanelHidden) {
        nav.style.display = 'none';
        mainContent.style.marginLeft = '0';
      } else {
        nav.style.display = 'block';
        mainContent.style.marginLeft = '16rem';
      }
    }
  }, [devPanelHidden]);
  
  return (
    <div>
      {/* Direct toggle button */}
      <button 
        onClick={() => {
          setDevPanelHidden(!devPanelHidden);
        }}
        style={{ 
          position: 'fixed',
          top: '10px',
          right: '10px',
          zIndex: 999999,
          padding: '10px 20px', 
          backgroundColor: '#8b5cf6', 
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: 'bold',
          boxShadow: '0 2px 8px rgba(0,0,0,0.2)'
        }}
      >
        {devPanelHidden ? 'Show Dev Panel' : 'Hide Dev Panel'}
      </button>
      <AdvancedDesignerV2 />
    </div>
  );
}