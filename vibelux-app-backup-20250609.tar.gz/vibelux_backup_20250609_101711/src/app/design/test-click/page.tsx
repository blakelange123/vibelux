'use client';

import { useState } from 'react';

export default function TestClickPage() {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('');

  const handleClick = () => {
    console.log('Button clicked!');
    setCount(count + 1);
    setMessage(`Clicked ${count + 1} times`);
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Test Click Handler</h1>
      <button
        onClick={handleClick}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Click me (Count: {count})
      </button>
      <p className="mt-4">{message}</p>
      
      <div className="mt-8">
        <h2 className="text-xl mb-2">Simple Toggle Test</h2>
        <button
          onClick={() => {
            console.log('Toggle button clicked');
            alert('Toggle clicked!');
          }}
          className="bg-green-500 text-white px-4 py-2 rounded"
        >
          Test Toggle
        </button>
      </div>
    </div>
  );
}