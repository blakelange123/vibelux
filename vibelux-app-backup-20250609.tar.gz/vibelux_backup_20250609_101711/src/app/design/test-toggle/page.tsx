'use client';

export default function TestTogglePage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold text-white mb-4">Test Toggle Button</h1>
      <p className="text-gray-300">This page is to test if the toggle button works. Click the "Hide Dev Panel" button in the top right corner.</p>
    </div>
  );
}