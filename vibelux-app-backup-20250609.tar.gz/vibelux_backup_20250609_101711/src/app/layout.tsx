import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import { LayoutWrapper } from "@/components/LayoutWrapper";
import { ServiceWorkerRegistration } from "@/components/ServiceWorkerRegistration";
import { CommandPalette } from "@/components/CommandPalette";
import { AIAssistant } from "@/components/AIAssistant";
import { DebugAIAssistant } from "@/components/DebugAIAssistant";
import { EventDebugger } from "@/components/EventDebugger";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Vibelux - Professional Horticultural Lighting Platform",
  description: "Advanced lighting design, analysis, and optimization for indoor farming and greenhouses",
  manifest: "/manifest.json",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider>
      <html lang="en" className="dark">
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
          <meta name="theme-color" content="#4f46e5" />
        </head>
        <body className={`${inter.className} gradient-background dark hide-sidebar`}>
          <ServiceWorkerRegistration />
          <CommandPalette />
          <AIAssistant />
          <LayoutWrapper>
            {children}
          </LayoutWrapper>
          <div className="gradient-overlay" />
          <script src="/sidebar-toggle.js" defer></script>
        </body>
      </html>
    </ClerkProvider>
  );
}