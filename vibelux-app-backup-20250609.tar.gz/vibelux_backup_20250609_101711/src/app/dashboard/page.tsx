"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@clerk/nextjs"
import { redirect } from "next/navigation"
import Link from "next/link"
import { 
  LayoutGrid, 
  Zap, 
  Leaf, 
  BarChart3, 
  Settings2,
  TrendingUp,
  TrendingDown,
  Calendar,
  Bell,
  Plus,
  ArrowRight,
  Sparkles,
  Sun,
  Timer,
  AlertCircle,
  CheckCircle2,
  Activity,
  Building2,
  FileText,
  Cpu,
  Users,
  MessageSquare,
  DollarSign,
  Wifi,
  X,
  Brain,
  Package
} from "lucide-react"

export default function DashboardPage() {
  const { isSignedIn, userId } = useAuth()
  const [timeOfDay, setTimeOfDay] = useState("")
  const [showNotifications, setShowNotifications] = useState(false)
  
  useEffect(() => {
    if (!isSignedIn) {
      redirect("/sign-in")
    }
  }, [isSignedIn])

  useEffect(() => {
    const hours = new Date().getHours()
    if (hours < 12) setTimeOfDay("morning")
    else if (hours < 17) setTimeOfDay("afternoon")
    else setTimeOfDay("evening")
  }, [])

  // Condensed stats
  const metrics = [
    { label: 'Active Projects', value: '3', change: '+1', trend: 'up' },
    { label: 'Energy Saved', value: '12.4k', unit: 'kWh', change: '+8%', trend: 'up' },
    { label: 'Monthly ROI', value: '24%', change: '+2.4%', trend: 'up' },
    { label: 'Fixtures', value: '42', change: '0', trend: 'neutral' }
  ]

  const alerts = [
    { type: 'warning', message: 'Fixture #12 efficiency below threshold', time: '5h' },
    { type: 'info', message: 'New DLC fixtures available', time: '1d' }
  ]

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Background */}
      <div className="fixed inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-gray-950 to-blue-900/20" />
      </div>
      
      <div className="relative z-10">
        {/* Compact Header */}
        <div className="bg-gray-900/30 backdrop-blur-2xl border-b border-gray-800/50">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h1 className="text-xl font-semibold text-white">
                  Good {timeOfDay}
                </h1>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Activity className="w-3 h-3 text-green-400" />
                  <span>All systems operational</span>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 hover:bg-gray-800/50 rounded-lg transition-colors"
                >
                  <Bell className="w-5 h-5 text-gray-400" />
                  {alerts.length > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-yellow-400 rounded-full" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-6 py-6">
          {/* Key Metrics - Single Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {metrics.map((metric, idx) => (
              <div key={idx} className="bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-400">{metric.label}</span>
                  {metric.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-400" />}
                  {metric.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-400" />}
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-white">{metric.value}</span>
                  {metric.unit && <span className="text-sm text-gray-400">{metric.unit}</span>}
                </div>
                {metric.change !== '0' && (
                  <span className={`text-xs ${metric.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                    {metric.change}
                  </span>
                )}
              </div>
            ))}
          </div>

          {/* Main Grid - 2 columns */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="lg:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link 
                href="/design/advanced-v3"
                className="group bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-6 hover:border-purple-700/50 transition-all duration-300 hover:translate-y-[-2px]"
                prefetch={false}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 bg-purple-500/10 rounded-xl mb-3 group-hover:scale-110 transition-transform">
                    <Plus className="w-6 h-6 text-purple-400" />
                  </div>
                  <span className="text-sm font-medium text-white">New Design</span>
                </div>
              </Link>

              <Link 
                href="/predictions"
                className="group bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-6 hover:border-blue-700/50 transition-all duration-300 hover:translate-y-[-2px]"
                prefetch={false}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 bg-blue-500/10 rounded-xl mb-3 group-hover:scale-110 transition-transform">
                    <Brain className="w-6 h-6 text-blue-400" />
                  </div>
                  <span className="text-sm font-medium text-white">AI Predictions</span>
                </div>
              </Link>

              <Link 
                href="/analytics"
                className="group bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-6 hover:border-green-700/50 transition-all duration-300 hover:translate-y-[-2px]"
                prefetch={false}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 bg-green-500/10 rounded-xl mb-3 group-hover:scale-110 transition-transform">
                    <BarChart3 className="w-6 h-6 text-green-400" />
                  </div>
                  <span className="text-sm font-medium text-white">Analytics</span>
                </div>
              </Link>

              <Link 
                href="/fixtures"
                className="group bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-6 hover:border-yellow-700/50 transition-all duration-300 hover:translate-y-[-2px]"
                prefetch={false}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-3 bg-yellow-500/10 rounded-xl mb-3 group-hover:scale-110 transition-transform">
                    <Package className="w-6 h-6 text-yellow-400" />
                  </div>
                  <span className="text-sm font-medium text-white">Fixtures</span>
                </div>
              </Link>

              {/* Recent Activity - Spans 2 columns */}
              <div className="col-span-2 md:col-span-4 bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-4">
                <h3 className="text-sm font-semibold text-white mb-3">Recent Activity</h3>
                <div className="space-y-2">
                  {[
                    { icon: CheckCircle2, text: 'Design completed for Room A', time: '2h', color: 'text-green-400' },
                    { icon: AlertCircle, text: 'Fixture #12 needs attention', time: '5h', color: 'text-yellow-400' },
                    { icon: Activity, text: 'Energy report generated', time: '1d', color: 'text-blue-400' }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 text-sm">
                      <item.icon className={`w-4 h-4 ${item.color} flex-shrink-0`} />
                      <span className="text-gray-300 flex-1">{item.text}</span>
                      <span className="text-xs text-gray-500">{item.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Alerts & Tips */}
            <div className="space-y-4">
              {/* Alerts */}
              {alerts.length > 0 && (
                <div className="bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-4">
                  <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                    <Bell className="w-4 h-4 text-yellow-400" />
                    Alerts
                  </h3>
                  <div className="space-y-2">
                    {alerts.map((alert, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-sm">
                        <AlertCircle className={`w-4 h-4 ${alert.type === 'warning' ? 'text-yellow-400' : 'text-blue-400'} flex-shrink-0 mt-0.5`} />
                        <div className="flex-1">
                          <p className="text-gray-300">{alert.message}</p>
                          <span className="text-xs text-gray-500">{alert.time} ago</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Stats */}
              <div className="bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 p-4">
                <h3 className="text-sm font-semibold text-white mb-3">System Health</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Uptime</span>
                    <span className="text-sm font-medium text-green-400">99.9%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">API Calls</span>
                    <span className="text-sm font-medium text-white">1,247</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Data Usage</span>
                    <span className="text-sm font-medium text-white">2.4 GB</span>
                  </div>
                </div>
              </div>

              {/* Pro Tip */}
              <div className="bg-purple-500/10 backdrop-blur-xl rounded-xl border border-purple-500/30 p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-purple-400 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-1">Pro Tip</h4>
                    <p className="text-xs text-gray-300">
                      Use AI predictions to optimize your lighting schedules and save up to 30% more energy.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notifications Dropdown */}
      {showNotifications && (
        <div className="fixed top-16 right-6 w-80 bg-gray-900/95 backdrop-blur-xl rounded-xl border border-gray-800/50 shadow-2xl z-50">
          <div className="p-4 border-b border-gray-800/50 flex items-center justify-between">
            <h3 className="font-semibold text-white">Notifications</h3>
            <button 
              onClick={() => setShowNotifications(false)}
              className="p-1 hover:bg-gray-800/50 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 text-gray-400" />
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto p-4 space-y-3">
            {alerts.map((alert, idx) => (
              <div key={idx} className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-sm text-gray-300">{alert.message}</p>
                <span className="text-xs text-gray-500">{alert.time} ago</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}