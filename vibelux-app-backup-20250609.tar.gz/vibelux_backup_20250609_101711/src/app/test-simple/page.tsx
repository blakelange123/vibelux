"use client"

import { useState, useEffect } from 'react'

export default function TestSimple() {
  const [hydrated, setHydrated] = useState(false)
  const [clickCount, setClickCount] = useState(0)
  
  useEffect(() => {
    setHydrated(true)
    console.log('TestSimple: Component hydrated')
    
    // Add a test listener to the window
    const handleWindowClick = (e: MouseEvent) => {
      console.log('Window clicked at:', e.clientX, e.clientY)
    }
    window.addEventListener('click', handleWindowClick)
    
    return () => window.removeEventListener('click', handleWindowClick)
  }, [])
  
  const handleClick = () => {
    console.log('Button clicked! Current count:', clickCount)
    setClickCount(prev => prev + 1)
  }
  
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Simple Test Page</h1>
      
      <div className="mb-4">
        <p>Hydrated: {hydrated ? '✅ Yes' : '❌ No'}</p>
        <p>Click count: {clickCount}</p>
      </div>
      
      <div className="space-x-4">
        <button
          onClick={handleClick}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Click Me (onClick)
        </button>
        
        <button
          onMouseDown={() => console.log('MouseDown event')}
          onMouseUp={() => console.log('MouseUp event')}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          Test Mouse Events
        </button>
        
        <button
          onPointerDown={() => console.log('PointerDown event')}
          onPointerUp={() => console.log('PointerUp event')}
          className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
        >
          Test Pointer Events
        </button>
      </div>
      
      <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded">
        <h2 className="font-bold mb-2">Instructions:</h2>
        <ol className="list-decimal list-inside space-y-1">
          <li>Open browser console</li>
          <li>Click anywhere on the page - you should see "Window clicked at: X Y"</li>
          <li>Click the buttons - you should see console logs</li>
          <li>If hydrated shows "Yes" but buttons don't work, it's an event issue</li>
        </ol>
      </div>
    </div>
  )
}