"use client"

import { useEffect, useState } from 'react'

export default function TestReactRoot() {
  const [mounted, setMounted] = useState(false)
  const [hydrationStatus, setHydrationStatus] = useState('checking...')
  
  useEffect(() => {
    console.log('TestReactRoot: Component mounted')
    setMounted(true)
    
    // Check for React 18 root
    const checkRoot = () => {
      const nextRoot = document.getElementById('__next')
      if (!nextRoot) {
        setHydrationStatus('No __next root found')
        return
      }
      
      // Check various React internal properties
      const checks = {
        '_reactRootContainer': !!(nextRoot as any)._reactRootContainer,
        '__reactContainer': !!(nextRoot as any).__reactContainer,
        '_internalRoot': !!(nextRoot as any)._internalRoot,
        'firstChild._reactRootContainer': nextRoot.firstChild && !!(nextRoot.firstChild as any)._reactRootContainer,
      }
      
      console.log('React root checks:', checks)
      
      // Check if React is available globally
      const globalChecks = {
        'window.React': !!(window as any).React,
        'window.ReactDOM': !!(window as any).ReactDOM,
        '__NEXT_DATA__': !!(window as any).__NEXT_DATA__,
        '__NEXT_HYDRATED__': !!(window as any).__NEXT_HYDRATED__,
      }
      
      console.log('Global checks:', globalChecks)
      
      const hasReactRoot = Object.values(checks).some(v => v)
      setHydrationStatus(hasReactRoot ? '✅ React root found' : '❌ No React root found')
    }
    
    // Check immediately and after a delay
    checkRoot()
    setTimeout(checkRoot, 1000)
    
    // Try to manually trigger hydration status
    if (typeof window !== 'undefined') {
      (window as any).__TEST_HYDRATED__ = true
    }
  }, [])
  
  return (
    <div className="p-8 bg-black text-white min-h-screen">
      <h1 className="text-2xl mb-6">React Root Test</h1>
      
      <div className="space-y-4">
        <div className="p-4 bg-gray-900 rounded">
          <p>Component Mounted: {mounted ? '✅ Yes' : '❌ No'}</p>
          <p>Hydration Status: {hydrationStatus}</p>
        </div>
        
        <button
          onClick={() => {
            console.log('Button clicked!')
            alert('If you see this, React events are working!')
          }}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded"
        >
          Test Click Event
        </button>
        
        <div className="p-4 bg-gray-900 rounded text-sm">
          <h2 className="font-bold mb-2">Console Checks:</h2>
          <p>Look for "React root checks" and "Global checks" in console</p>
          <p>This will help identify if React is properly attached to the DOM</p>
        </div>
      </div>
    </div>
  )
}