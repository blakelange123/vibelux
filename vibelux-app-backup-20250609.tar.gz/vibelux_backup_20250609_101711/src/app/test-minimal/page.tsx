"use client"

import { useState } from "react"

export default function TestMinimal() {
  const [count, setCount] = useState(0)
  
  return (
    <div style={{ 
      minHeight: "100vh", 
      backgroundColor: "black", 
      color: "white", 
      padding: "2rem" 
    }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "2rem" }}>Minimal Event Test</h1>
      
      <button
        onClick={() => {
          console.log("Button clicked\!")
          setCount(count + 1)
          alert(`Clicked ${count + 1} times`)
        }}
        style={{
          padding: "1rem 2rem",
          backgroundColor: "#8b5cf6",
          color: "white",
          border: "none",
          borderRadius: "0.5rem",
          cursor: "pointer",
          fontSize: "1rem"
        }}
      >
        Click Me (Count: {count})
      </button>
      
      <div style={{ marginTop: "2rem" }}>
        <p>If clicking the button shows an alert, JavaScript events are working.</p>
        <p>If not, there is a fundamental issue with event handling.</p>
      </div>
    </div>
  )
}
