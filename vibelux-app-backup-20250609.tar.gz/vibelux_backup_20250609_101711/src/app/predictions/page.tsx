"use client"

import { useState, useEffect } from 'react'
import { MachineLearningPredictions } from '@/components/MachineLearningPredictions'
import { Brain, TrendingUp, Activity, Sparkles } from 'lucide-react'

export default function PredictionsPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-950 overflow-x-hidden">
      {/* Modern animated gradient background */}
      <div className="fixed inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-gray-950 to-blue-900/20" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-900/10 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent" />
      </div>
      
      <div className="relative z-10">
        {/* Ultra-compact header */}
        <div className="bg-gray-900/30 backdrop-blur-2xl border-b border-gray-800/50">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Brain className="w-6 h-6 text-purple-400" />
                <h1 className="text-xl font-semibold text-white">AI Predictions</h1>
                <div className="hidden md:flex items-center gap-4 ml-6 text-xs">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-gray-400">Active</span>
                  </div>
                  <div className="text-gray-500">|</div>
                  <span className="text-gray-400">7 Models</span>
                  <div className="text-gray-500">|</div>
                  <span className="text-gray-400">94.5% Accuracy</span>
                  <div className="text-gray-500">|</div>
                  <span className="text-gray-400">247/hr</span>
                </div>
              </div>
              
              {/* Mobile stats */}
              <div className="md:hidden flex items-center gap-2 text-xs">
                <div className="w-2 h-2 bg-green-400 rounded-full" />
                <span className="text-gray-400">94.5%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content - tight spacing */}
        <div className="container mx-auto px-6 py-4">
          <MachineLearningPredictions />
        </div>
      </div>
    </div>
  )
}