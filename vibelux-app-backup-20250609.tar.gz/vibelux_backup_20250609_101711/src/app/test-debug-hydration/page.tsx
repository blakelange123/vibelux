"use client"

import { useState, useEffect, useRef } from 'react'

// Check if we're suppressing hydration warnings
if (typeof window !== 'undefined') {
  console.log('[Debug] Window available at module level')
  console.log('[Debug] React suppressHydrationWarning:', (window as any).__NEXT_REACT_SUPPRESS_HYDRATION_WARNING__)
}

export default function TestDebugHydration() {
  const [phase, setPhase] = useState('initial')
  const [clicks, setClicks] = useState(0)
  const buttonRef = useRef<HTMLButtonElement>(null)
  
  // Log at module level
  console.log('[Debug] Component function called, phase:', phase)
  
  useEffect(() => {
    console.log('[Debug] useEffect running')
    
    // Check Next.js hydration state
    const nextData = (window as any).__NEXT_DATA__
    if (nextData) {
      console.log('[Debug] __NEXT_DATA__ found:', {
        page: nextData.page,
        query: nextData.query,
        buildId: nextData.buildId,
        isFallback: nextData.isFallback,
        dynamicIds: nextData.dynamicIds,
        gssp: nextData.gssp,
        appGip: nextData.appGip,
        scriptLoader: nextData.scriptLoader
      })
    }
    
    // Check if hydration is complete
    const hydrated = (window as any).__NEXT_HYDRATED__
    console.log('[Debug] __NEXT_HYDRATED__:', hydrated)
    
    // Check React Fiber
    const reactFiber = (window as any).__REACT_DEVTOOLS_GLOBAL_HOOK__
    if (reactFiber) {
      console.log('[Debug] React DevTools hook found')
    }
    
    setPhase('mounted')
    
    // Add both React and native listeners
    const button = buttonRef.current
    if (button) {
      console.log('[Debug] Button ref found')
      
      // Native listener
      const nativeHandler = () => {
        console.log('[Debug] Native click detected')
        document.getElementById('native-result')!.textContent = 'Native: Clicked!'
      }
      button.addEventListener('click', nativeHandler)
      
      // Check if React event handlers are attached
      const reactProps = (button as any)._reactProps || (button as any).__reactEventHandlers
      console.log('[Debug] React props on button:', reactProps)
      
      return () => button.removeEventListener('click', nativeHandler)
    }
  }, [])
  
  const handleReactClick = () => {
    console.log('[Debug] React onClick fired, clicks:', clicks)
    setClicks(c => c + 1)
    setPhase('clicked')
  }
  
  return (
    <div className="p-8 text-white">
      <h1 className="text-2xl mb-4">Debug Hydration Test</h1>
      
      <div className="mb-6 p-4 bg-gray-900 rounded">
        <p>Phase: <span className="text-yellow-400">{phase}</span></p>
        <p>React Clicks: <span className="text-green-400">{clicks}</span></p>
        <p id="native-result">Native: Not clicked</p>
      </div>
      
      <button
        ref={buttonRef}
        onClick={handleReactClick}
        className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded"
      >
        Test Button
      </button>
      
      <div className="mt-6 p-4 bg-gray-900 rounded text-sm">
        <p>Open console and look for [Debug] messages</p>
        <p>Expected behavior:</p>
        <ul className="list-disc list-inside mt-2">
          <li>Both React onClick and native listener should fire</li>
          <li>React clicks counter should increment</li>
          <li>Native result should update</li>
        </ul>
      </div>
      
      {/* Inline script to check hydration from outside React */}
      <script dangerouslySetInnerHTML={{
        __html: `
          console.log('[Inline] Script executing');
          if (typeof window !== 'undefined') {
            window.__DEBUG_HYDRATION__ = true;
            
            // Monitor for hydration
            let checkCount = 0;
            const checkHydration = setInterval(() => {
              const root = document.getElementById('__next');
              const hasReactInternal = root && (root._reactRootContainer || root.__reactContainer);
              console.log('[Inline] Hydration check #' + (++checkCount) + ':', {
                hasRoot: !!root,
                hasReactInternal: hasReactInternal,
                reactVersion: window.React?.version
              });
              
              if (hasReactInternal || checkCount > 10) {
                clearInterval(checkHydration);
              }
            }, 500);
          }
        `
      }} />
    </div>
  )
}