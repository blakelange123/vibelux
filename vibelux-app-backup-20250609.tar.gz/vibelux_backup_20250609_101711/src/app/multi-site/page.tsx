import { MultiSiteManager } from '@/components/MultiSiteManager'

export default function MultiSitePage() {
  return <MultiSiteManager />
}