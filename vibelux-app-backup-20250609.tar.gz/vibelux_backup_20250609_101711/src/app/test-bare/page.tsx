"use client"

import { useState } from 'react'

export default function TestBare() {
  const [count, setCount] = useState(0)
  
  if (typeof window !== 'undefined') {
    console.log('TestBare: Window available during render')
  }
  
  return (
    <>
      <h1>Bare Test</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Click me</button>
    </>
  )
}