"use client"

import { useState, useEffect } from 'react'
import { Sparkles, Key, Info, Check, X, Loader2 } from 'lucide-react'

export function AIAssistantSettings() {
  const [useOpenAI, setUseOpenAI] = useState(false)
  const [apiKey, setApiKey] = useState('')
  const [orgId, setOrgId] = useState('')
  const [isTestingConnection, setIsTestingConnection] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)
  const [isSaving, setIsSaving] = useState(false)

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('aiAssistantSettings')
    if (savedSettings) {
      const settings = JSON.parse(savedSettings)
      setUseOpenAI(settings.useOpenAI || false)
      setApiKey(settings.apiKey || '')
      setOrgId(settings.orgId || '')
    }
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    
    // Save to localStorage
    const settings = {
      useOpenAI,
      apiKey: useOpenAI ? apiKey : '',
      orgId: useOpenAI ? orgId : ''
    }
    localStorage.setItem('aiAssistantSettings', JSON.stringify(settings))

    // If disabling OpenAI, clear the keys from environment
    if (!useOpenAI) {
      // In a real app, you'd make an API call to update server-side config
      // For now, we'll just use localStorage
    }

    setTimeout(() => {
      setIsSaving(false)
      setTestResult({ success: true, message: 'Settings saved successfully!' })
    }, 1000)
  }

  const testConnection = async () => {
    if (!apiKey) {
      setTestResult({ success: false, message: 'Please enter an API key' })
      return
    }

    setIsTestingConnection(true)
    setTestResult(null)

    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'OpenAI-Organization': orgId || ''
        }
      })

      if (response.ok) {
        setTestResult({ success: true, message: 'Connection successful! OpenAI API is working.' })
      } else {
        const error = await response.json()
        setTestResult({ success: false, message: error.error?.message || 'Invalid API key' })
      }
    } catch (error) {
      setTestResult({ success: false, message: 'Failed to connect to OpenAI API' })
    } finally {
      setIsTestingConnection(false)
    }
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">AI Assistant Configuration</h2>
        <p className="text-gray-400">Configure how the AI Assistant responds to questions</p>
      </div>

      {/* AI Mode Toggle */}
      <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-white mb-2">AI Response Mode</h3>
            <p className="text-sm text-gray-400">
              Choose between built-in responses or OpenAI-powered conversations
            </p>
          </div>
          <button
            onClick={() => setUseOpenAI(!useOpenAI)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              useOpenAI ? 'bg-purple-600' : 'bg-gray-600'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                useOpenAI ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg border-2 transition-all ${
            !useOpenAI ? 'border-purple-600 bg-purple-600/10' : 'border-gray-700 bg-gray-800/30'
          }`}>
            <h4 className="font-medium text-white mb-2">Built-in Responses</h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Instant responses
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                No API costs
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Accurate horticultural data
              </li>
              <li className="flex items-center gap-2">
                <X className="w-4 h-4 text-red-400" />
                Limited to preset responses
              </li>
            </ul>
          </div>

          <div className={`p-4 rounded-lg border-2 transition-all ${
            useOpenAI ? 'border-purple-600 bg-purple-600/10' : 'border-gray-700 bg-gray-800/30'
          }`}>
            <h4 className="font-medium text-white mb-2">OpenAI Integration</h4>
            <ul className="text-sm text-gray-400 space-y-1">
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Natural conversations
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Handles complex queries
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                Contextual understanding
              </li>
              <li className="flex items-center gap-2">
                <X className="w-4 h-4 text-red-400" />
                Requires API key & costs
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* OpenAI Configuration */}
      {useOpenAI && (
        <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-purple-400" />
            OpenAI API Configuration
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                API Key <span className="text-red-400">*</span>
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                Get your API key from <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300">platform.openai.com</a>
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Organization ID <span className="text-gray-500">(optional)</span>
              </label>
              <input
                type="text"
                value={orgId}
                onChange={(e) => setOrgId(e.target.value)}
                placeholder="org-..."
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={testConnection}
              disabled={isTestingConnection || !apiKey}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              {isTestingConnection ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Test Connection
                </>
              )}
            </button>

            {testResult && (
              <div className={`p-4 rounded-lg flex items-start gap-3 ${
                testResult.success ? 'bg-green-900/20 border border-green-800' : 'bg-red-900/20 border border-red-800'
              }`}>
                {testResult.success ? (
                  <Check className="w-5 h-5 text-green-400 mt-0.5" />
                ) : (
                  <X className="w-5 h-5 text-red-400 mt-0.5" />
                )}
                <p className={`text-sm ${testResult.success ? 'text-green-300' : 'text-red-300'}`}>
                  {testResult.message}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Info Box */}
      <div className="bg-blue-900/20 rounded-lg p-4 border border-blue-800/30 mb-6">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-400 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-blue-300 mb-1">About AI Responses</h4>
            <p className="text-sm text-blue-200/80">
              The built-in response system provides accurate, instant answers for common horticultural lighting questions. 
              Enable OpenAI integration for more dynamic, conversational responses and complex query handling.
            </p>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              Save Settings
            </>
          )}
        </button>
      </div>
    </div>
  )
}