'use client';

import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { FalseColorPPFDMap } from '@/components/FalseColorPPFDMap';
import { Room3DModal } from '@/components/Room3DModal';
import { FixtureLibrary, type FixtureModel } from '@/components/FixtureLibrary';
import { ElectricalLoadBalancer } from '@/components/ElectricalLoadBalancer';
import { EnergyCostCalculator } from '@/components/EnergyCostCalculator';
import { exportToPDF, exportToExcel, exportToCSV } from '@/lib/export-utils';
import { PDFReportGenerator } from '@/lib/pdf-report-generator';
import { exportCircuitScheduleCSV, exportElectricalBlueprint, exportSingleLineDiagram } from '@/lib/electrical-export';
import { calculatePFALMetrics, generatePFALRecommendations } from '@/lib/pfal-optimization';
import { getWhiteLabelConfig } from '@/lib/whitelabel-config';
import { calculatePPFDGrid, calculatePPFDStats, calculateDLI, calculateSpectrumMix } from '@/lib/ppfd-calculations';
import { calculateAdvancedPPFDGrid, getFixtureDimensions, getBeamAngle } from '@/lib/ppfd-calculations-advanced';
import { optimizeLightingDesign, generateOptimalLayout } from '@/lib/optimization-engine';
import { calculateVPDWithLighting, getVPDRecommendations, calculateTargetEnvironment, adjustPPFDForVPD } from '@/lib/vpd-integration';
import { 
  Settings,
  Eye,
  EyeOff,
  Save,
  Download,
  Undo,
  Redo,
  Grid,
  Move,
  RotateCw,
  Plus,
  Layers,
  Search,
  Filter,
  BarChart3,
  Zap,
  Sun,
  ChevronRight,
  ChevronDown,
  Package,
  Map,
  Activity,
  Calendar,
  Thermometer,
  Droplets,
  Brain,
  TrendingUp,
  FileText,
  HelpCircle,
  X,
  Edit2,
  Box as Cube,
  Target,
  Info,
  Shuffle,
  FileDown,
  Globe,
  Check
} from 'lucide-react';

interface Section {
  id: string;
  title: string;
  icon: React.ElementType;
  description: string;
  expanded: boolean;
}

interface Fixture {
  id: string;
  x: number;
  y: number;
  rotation: number;
  model: {
    id: string;
    brand: string;
    model: string;
    wattage: number;
    ppf: number;
    efficacy: number;
    spectrumData: {
      red: number;
      blue: number;
      green: number;
      farRed: number;
    };
    coverage: number;
  };
  enabled: boolean;
}

export function AdvancedDesignerV2() {
  const [activeTab, setActiveTab] = useState<'design' | 'analyze' | 'optimize' | 'export'>('design');
  const [selectedTool, setSelectedTool] = useState<string>('select');
  const [showHelp, setShowHelp] = useState(false);
  const [show3D, setShow3D] = useState(false);
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [selectedFixture, setSelectedFixture] = useState<string | null>(null);
  const [multiTierLayers, setMultiTierLayers] = useState<any[]>([]);
  const [roomDimensions, setRoomDimensions] = useState({ width: 10, length: 10, height: 3 });
  const [roomShape, setRoomShape] = useState('Rectangle');
  const [sidebarSections, setSidebarSections] = useState<Section[]>([
    {
      id: 'room',
      title: 'Room Configuration',
      icon: Package,
      description: 'Set room dimensions and shape',
      expanded: true
    },
    {
      id: 'fixtures',
      title: 'Fixture Library',
      icon: Zap,
      description: 'Browse and select fixtures',
      expanded: true
    },
    {
      id: 'layers',
      title: 'Canopy Layers',
      icon: Layers,
      description: 'Multi-tier growing setup',
      expanded: false
    }
  ]);

  const toggleSection = (sectionId: string) => {
    setSidebarSections(prev => 
      prev.map(section => 
        section.id === sectionId 
          ? { ...section, expanded: !section.expanded }
          : section
      )
    );
  };

  const tools = [
    { id: 'select', icon: Move, tooltip: 'Select & Move (V)' },
    { id: 'place', icon: Plus, tooltip: 'Place Fixture (P)' },
    { id: 'rotate', icon: RotateCw, tooltip: 'Rotate (R)' },
    { id: 'grid', icon: Grid, tooltip: 'Toggle Grid (G)' },
  ];

  const tabs = [
    { id: 'design', label: 'Design', icon: Grid },
    { id: 'analyze', label: 'Analyze', icon: BarChart3 },
    { id: 'optimize', label: 'Optimize', icon: Brain },
    { id: 'export', label: 'Export', icon: Download },
  ];

  // Component Panels
  function RoomConfiguration({ roomDimensions, onUpdateDimensions, roomShape, setRoomShape }: { 
    roomDimensions: { width: number; length: number; height: number };
    onUpdateDimensions: (dimensions: { width: number; length: number; height: number }) => void;
    roomShape: string;
    setRoomShape: (shape: string) => void;
  }) {
    const [lShapeConfig, setLShapeConfig] = useState({
      mainWidth: 10,
      mainLength: 10,
      extensionWidth: 5,
      extensionLength: 5,
      extensionPosition: 'top-right' as 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
    });

    return (
      <div className="space-y-4">
        <div>
          <label className="text-xs font-medium text-gray-400 mb-1 block">Room Shape</label>
          <select 
            value={roomShape}
            onChange={(e) => setRoomShape(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm"
          >
            <option>Rectangle</option>
            <option>Square</option>
            <option>L-Shape</option>
            <option>Custom Polygon</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-medium text-gray-400 mb-1 block">Width (m)</label>
            <input 
              type="number" 
              value={roomDimensions.width} 
              onChange={(e) => onUpdateDimensions({ ...roomDimensions, width: parseFloat(e.target.value) || 0 })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
            />
          </div>
          <div>
            <label className="text-xs font-medium text-gray-400 mb-1 block">Length (m)</label>
            <input 
              type="number" 
              value={roomDimensions.length} 
              onChange={(e) => onUpdateDimensions({ ...roomDimensions, length: parseFloat(e.target.value) || 0 })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
            />
          </div>
        </div>
        <div>
          <label className="text-xs font-medium text-gray-400 mb-1 block">Mounting Height (m)</label>
          <input 
            type="number" 
            value={roomDimensions.height} 
            onChange={(e) => onUpdateDimensions({ ...roomDimensions, height: parseFloat(e.target.value) || 0 })}
            step="0.1" 
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
          />
        </div>
        
        {/* Room Info */}
        <div className="col-span-2 bg-gray-800/50 rounded p-3 mb-3">
          <div className="text-xs text-gray-400">
            <p>Area: {(roomDimensions.width * roomDimensions.length).toFixed(1)} m²</p>
            <p>Volume: {(roomDimensions.width * roomDimensions.length * roomDimensions.height).toFixed(1)} m³</p>
          </div>
        </div>
        
        {/* Create/Update Room Button */}
        <button
          onClick={() => {
            console.log('Room dimensions set:', roomDimensions);
            onUpdateDimensions(roomDimensions);
          }}
          className="col-span-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded text-sm font-medium transition-colors mb-3"
        >
          Update Room Layout
        </button>

        {/* L-Shape Configuration */}
        {roomShape === 'L-Shape' && (
          <div className="space-y-3 p-3 bg-gray-800 rounded-lg">
            <h4 className="text-xs font-semibold text-purple-400">L-Shape Configuration</h4>
          
            {/* Main Section */}
            <div className="space-y-2">
              <p className="text-xs text-gray-400">Main Section</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-gray-500">Width (m)</label>
                  <input 
                    type="number" 
                    value={lShapeConfig.mainWidth}
                    onChange={(e) => setLShapeConfig({...lShapeConfig, mainWidth: parseFloat(e.target.value) || 0})}
                    className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Length (m)</label>
                  <input 
                    type="number" 
                    value={lShapeConfig.mainLength}
                    onChange={(e) => setLShapeConfig({...lShapeConfig, mainLength: parseFloat(e.target.value) || 0})}
                    className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
                  />
                </div>
              </div>
            </div>

            {/* Extension Section */}
            <div className="space-y-2">
              <p className="text-xs text-gray-400">Extension Section</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-gray-500">Width (m)</label>
                  <input 
                    type="number" 
                    value={lShapeConfig.extensionWidth}
                    onChange={(e) => setLShapeConfig({...lShapeConfig, extensionWidth: parseFloat(e.target.value) || 0})}
                    className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Length (m)</label>
                  <input 
                    type="number" 
                    value={lShapeConfig.extensionLength}
                    onChange={(e) => setLShapeConfig({...lShapeConfig, extensionLength: parseFloat(e.target.value) || 0})}
                    className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm" 
                  />
                </div>
              </div>
            </div>

            {/* Position */}
            <div>
              <label className="text-xs text-gray-500">Extension Position</label>
              <select 
                value={lShapeConfig.extensionPosition}
                onChange={(e) => setLShapeConfig({...lShapeConfig, extensionPosition: e.target.value as any})}
                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm mt-1"
              >
                <option value="top-right">Top Right</option>
                <option value="top-left">Top Left</option>
                <option value="bottom-right">Bottom Right</option>
                <option value="bottom-left">Bottom Left</option>
              </select>
            </div>

            {/* Visual Preview */}
            <div className="p-3 bg-gray-900 rounded">
              <p className="text-xs text-gray-400 mb-2">Preview</p>
              <div className="relative w-full h-32">
                {/* Simple L-shape preview */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative">
                    <div className="absolute bg-purple-600/30 border border-purple-500/50"
                      style={{
                        width: `${lShapeConfig.mainWidth * 8}px`,
                        height: `${lShapeConfig.mainLength * 8}px`,
                      }}
                    />
                    <div className="absolute bg-purple-600/30 border border-purple-500/50"
                      style={{
                        width: `${lShapeConfig.extensionWidth * 8}px`,
                        height: `${lShapeConfig.extensionLength * 8}px`,
                        ...(lShapeConfig.extensionPosition === 'top-right' && { top: 0, right: 0 }),
                        ...(lShapeConfig.extensionPosition === 'top-left' && { top: 0, left: 0 }),
                        ...(lShapeConfig.extensionPosition === 'bottom-right' && { bottom: 0, right: 0 }),
                        ...(lShapeConfig.extensionPosition === 'bottom-left' && { bottom: 0, left: 0 }),
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  const FixtureLibraryPanel = useMemo(() => {
    return function FixtureLibraryPanelComponent() {
      const [selectedFixture, setSelectedFixture] = useState<FixtureModel | null>(null);
      const [searchQuery, setSearchQuery] = useState('');
      const [selectedManufacturer, setSelectedManufacturer] = useState<string>('all');
      const [wattageRange, setWattageRange] = useState<[number, number]>([0, 2000]);
      const [selectedType, setSelectedType] = useState<string>('all');
      const [activeCategory, setActiveCategory] = useState<string>('all');
      const [showFilters, setShowFilters] = useState(false);
      const [editingProperty, setEditingProperty] = useState<string | null>(null);
      const [fixtureLibrary, setFixtureLibrary] = useState<FixtureModel[]>([]);

      // Load fixtures from FixtureLibrary component
      useEffect(() => {
        // In a real app, this would come from the FixtureLibrary component
        // For now, we'll create a mock dataset
        const mockFixtures: FixtureModel[] = [
        {
          id: 'fl-001',
          brand: 'Fluence',
          model: 'SPYDR 2p',
          category: 'LED Bar',
          wattage: 645,
          ppf: 1700,
          efficacy: 2.6,
          spectrum: 'Full Spectrum',
          spectrumData: { blue: 18, green: 8, red: 68, farRed: 6 },
          coverage: 16,
          price: 1299,
          voltage: '120-277V',
          dimmable: true,
          warranty: 5
        },
        {
          id: 'fl-002',
          brand: 'Gavita',
          model: 'Pro 1700e LED',
          category: 'LED Panel',
          wattage: 645,
          ppf: 1700,
          efficacy: 2.6,
          spectrum: 'Full Spectrum',
          spectrumData: { blue: 20, green: 10, red: 65, farRed: 5 },
          coverage: 20,
          price: 1199,
          voltage: '120-277V',
          dimmable: true,
          warranty: 5
        },
        {
          id: 'fl-003',
          brand: 'California Lightworks',
          model: 'MegaDrive 1000',
          category: 'LED Panel',
          wattage: 1000,
          ppf: 2200,
          efficacy: 2.2,
          spectrum: 'Variable Spectrum',
          spectrumData: { blue: 22, green: 12, red: 60, farRed: 6 },
          coverage: 25,
          price: 1599,
          voltage: '120-277V',
          dimmable: true,
          warranty: 5
        },
        {
          id: 'fl-004',
          brand: 'ChilLED',
          model: 'X6 600W',
          category: 'LED Bar',
          wattage: 600,
          ppf: 1620,
          efficacy: 2.7,
          spectrum: 'Full Spectrum',
          spectrumData: { blue: 19, green: 9, red: 67, farRed: 5 },
          coverage: 16,
          price: 999,
          voltage: '120-277V',
          dimmable: true,
          warranty: 5
        },
        {
          id: 'fl-005',
          brand: 'Mars Hydro',
          model: 'FC-E6500',
          category: 'LED Bar',
          wattage: 650,
          ppf: 1711,
          efficacy: 2.6,
          spectrum: 'Full Spectrum',
          spectrumData: { blue: 17, green: 7, red: 70, farRed: 6 },
          coverage: 20,
          price: 799,
          voltage: '120-240V',
          dimmable: true,
          warranty: 3
        },
        {
          id: 'fl-006',
          brand: 'Spider Farmer',
          model: 'SF7000',
          category: 'LED Bar',
          wattage: 650,
          ppf: 1676,
          efficacy: 2.58,
          spectrum: 'Full Spectrum',
          spectrumData: { blue: 21, green: 11, red: 63, farRed: 5 },
          coverage: 20,
          price: 849,
          voltage: '120-277V',
          dimmable: true,
          warranty: 3
        }
      ];
      setFixtureLibrary(mockFixtures);
    }, []);

    // Get unique manufacturers for filter
    const manufacturers = useMemo(() => {
      const brands = [...new Set(fixtureLibrary.map(f => f.brand))];
      return ['all', ...brands.sort()];
    }, [fixtureLibrary]);

    // Get unique categories for tabs
    const categories = useMemo(() => {
      const cats = [...new Set(fixtureLibrary.map(f => f.category))];
      return ['all', ...cats];
    }, [fixtureLibrary]);

    // Filter fixtures based on current filters
    const filteredFixtures = useMemo(() => {
      return fixtureLibrary.filter(fixture => {
        // Search filter
        if (searchQuery && !(
          fixture.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
          fixture.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
          fixture.spectrum.toLowerCase().includes(searchQuery.toLowerCase())
        )) {
          return false;
        }

        // Manufacturer filter
        if (selectedManufacturer !== 'all' && fixture.brand !== selectedManufacturer) {
          return false;
        }

        // Wattage filter
        if (fixture.wattage < wattageRange[0] || fixture.wattage > wattageRange[1]) {
          return false;
        }

        // Type/Category filter
        if (activeCategory !== 'all' && fixture.category !== activeCategory) {
          return false;
        }

        return true;
      });
    }, [fixtureLibrary, searchQuery, selectedManufacturer, wattageRange, activeCategory]);

    const handleFixtureSelect = (fixture: FixtureModel) => {
      setSelectedFixture(fixture);
    };

    const handleAddFixture = (fixture: FixtureModel) => {
      // TODO: Add logic to place fixture on canvas
      console.log('Adding fixture:', fixture);
      setSelectedFixture(fixture);
    };

    const handleDuplicateFixture = () => {
      if (selectedFixture) {
        // TODO: Add logic to duplicate fixture on canvas
        console.log('Duplicating fixture:', selectedFixture);
      }
    };

    const handlePropertyChange = (property: string, value: any) => {
      if (selectedFixture) {
        setSelectedFixture({
          ...selectedFixture,
          [property]: value
        });
        // TODO: Update fixture on canvas
      }
      setEditingProperty(null);
    };

    return (
      <div className="flex flex-col h-full space-y-4">
        {/* Search and Filter Header */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search fixtures by brand, model, or spectrum..."
                className="w-full pl-10 pr-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm placeholder-gray-400 focus:outline-none focus:border-purple-500"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`px-3 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors ${
                showFilters
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <Filter className="w-4 h-4" />
              Filters
            </button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="space-y-3 p-3 bg-gray-800/50 rounded-lg border border-gray-700">
              {/* Manufacturer Filter */}
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Manufacturer</label>
                <select
                  value={selectedManufacturer}
                  onChange={(e) => setSelectedManufacturer(e.target.value)}
                  className="w-full px-3 py-1.5 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:border-purple-500"
                >
                  {manufacturers.map(brand => (
                    <option key={brand} value={brand}>
                      {brand === 'all' ? 'All Manufacturers' : brand}
                    </option>
                  ))}
                </select>
              </div>

              {/* Wattage Range Filter */}
              <div>
                <label className="text-xs text-gray-400 mb-1 block">
                  Wattage Range: {wattageRange[0]}W - {wattageRange[1]}W
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="0"
                    max="2000"
                    step="50"
                    value={wattageRange[0]}
                    onChange={(e) => setWattageRange([Number(e.target.value), wattageRange[1]])}
                    className="flex-1"
                  />
                  <input
                    type="range"
                    min="0"
                    max="2000"
                    step="50"
                    value={wattageRange[1]}
                    onChange={(e) => setWattageRange([wattageRange[0], Number(e.target.value)])}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Category Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-colors ${
                  activeCategory === category
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {category === 'all' ? 'All Types' : category}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Fixture Grid */}
          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-1 gap-3">
              {filteredFixtures.map(fixture => (
                <div
                  key={fixture.id}
                  onClick={() => handleFixtureSelect(fixture)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-lg ${
                    selectedFixture?.id === fixture.id
                      ? 'bg-purple-900/30 border-purple-600 shadow-purple-600/20'
                      : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Fixture Icon/Image */}
                    <div className="w-16 h-16 bg-gray-700 rounded-lg flex items-center justify-center flex-shrink-0">
                      <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                      </svg>
                    </div>

                    {/* Fixture Details */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-white">{fixture.brand}</h4>
                          <p className="text-sm text-gray-300">{fixture.model}</p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAddFixture(fixture);
                          }}
                          className="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white text-xs rounded-lg transition-colors"
                        >
                          Add
                        </button>
                      </div>

                      {/* Key Specs */}
                      <div className="mt-2 flex flex-wrap gap-3 text-xs">
                        <div className="flex items-center gap-1">
                          <span className="text-gray-500">Power:</span>
                          <span className="text-gray-300 font-medium">{fixture.wattage}W</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-gray-500">PPF:</span>
                          <span className="text-gray-300 font-medium">{fixture.ppf} μmol/s</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-gray-500">Efficacy:</span>
                          <span className="text-gray-300 font-medium">{fixture.efficacy} μmol/J</span>
                        </div>
                      </div>

                      {/* Spectrum Bar */}
                      <div className="mt-2">
                        <div className="h-2 rounded-full overflow-hidden bg-gray-700 flex">
                          <div
                            className="bg-blue-500"
                            style={{ width: `${fixture.spectrumData.blue}%` }}
                          />
                          <div
                            className="bg-green-500"
                            style={{ width: `${fixture.spectrumData.green}%` }}
                          />
                          <div
                            className="bg-red-500"
                            style={{ width: `${fixture.spectrumData.red}%` }}
                          />
                          <div
                            className="bg-red-800"
                            style={{ width: `${fixture.spectrumData.farRed}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Selected Fixture Details */}
          {selectedFixture && (
            <div className="border-t border-gray-700 pt-4 mt-4">
              <div className="bg-purple-900/20 rounded-lg border border-purple-700/50 p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-medium text-white">
                      {selectedFixture.brand} {selectedFixture.model}
                    </h3>
                    <p className="text-sm text-gray-400">{selectedFixture.category}</p>
                  </div>
                  <button
                    onClick={handleDuplicateFixture}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg transition-colors flex items-center gap-1"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    Duplicate
                  </button>
                </div>

                {/* Full Specifications */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-500">Wattage:</span>
                    {editingProperty === 'wattage' ? (
                      <input
                        type="number"
                        value={selectedFixture.wattage}
                        onChange={(e) => handlePropertyChange('wattage', Number(e.target.value))}
                        onBlur={() => setEditingProperty(null)}
                        className="ml-2 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white w-20"
                        autoFocus
                      />
                    ) : (
                      <span
                        className="ml-2 text-white font-medium cursor-pointer hover:text-purple-400"
                        onClick={() => setEditingProperty('wattage')}
                      >
                        {selectedFixture.wattage}W
                      </span>
                    )}
                  </div>
                  <div>
                    <span className="text-gray-500">PPF:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.ppf} μmol/s</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Efficacy:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.efficacy} μmol/J</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Coverage:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.coverage} sq ft</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Spectrum:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.spectrum}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Voltage:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.voltage || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Dimmable:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.dimmable ? 'Yes' : 'No'}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Warranty:</span>
                    <span className="ml-2 text-white font-medium">{selectedFixture.warranty || 'N/A'} years</span>
                  </div>
                </div>

                {/* Spectrum Details */}
                <div className="mt-3 pt-3 border-t border-gray-700">
                  <p className="text-sm text-gray-400 mb-2">Spectrum Distribution</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-blue-400">Blue (400-500nm)</span>
                      <span className="text-gray-300">{selectedFixture.spectrumData.blue}%</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-green-400">Green (500-600nm)</span>
                      <span className="text-gray-300">{selectedFixture.spectrumData.green}%</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-red-400">Red (600-700nm)</span>
                      <span className="text-gray-300">{selectedFixture.spectrumData.red}%</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-red-600">Far Red (700-800nm)</span>
                      <span className="text-gray-300">{selectedFixture.spectrumData.farRed}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
    }
  }, []);

  function CanopyLayersPanel({ onLayersChange }: { onLayersChange?: (layers: any[]) => void }) {
    const [layers, setLayers] = useState([
      {
        id: 'ground',
        name: 'Ground Level',
        height: 30, // inches
        benchDepth: 4, // feet
        canopyHeight: 12, // inches
        targetPPFD: 600,
        cropType: 'Lettuce',
        enabled: true,
        visible: true,
        color: '#10B981',
        plantDensity: 16,
        growthStage: 'vegetative' as const
      }
    ]);
  
    const [showAddForm, setShowAddForm] = useState(false);
    const [editingLayer, setEditingLayer] = useState<string | null>(null);
  
    // Notify parent when layers change
    useEffect(() => {
      onLayersChange?.(layers.map(layer => ({
        ...layer,
        height: layer.height / 39.37, // Convert inches to meters for 3D view
        canopyHeight: layer.canopyHeight / 39.37,
        benchDepth: layer.benchDepth * 0.3048 // Convert feet to meters
      })));
    }, [layers, onLayersChange]);
  
    const addLayer = () => {
      const newLayer = {
        id: `layer-${Date.now()}`,
        name: `Tier ${layers.length + 1}`,
        height: 60 + (layers.length * 30), // Auto-increment height
        benchDepth: 4,
        canopyHeight: 12,
        targetPPFD: 500 - (layers.length * 50),
        cropType: 'Herbs',
        enabled: true,
        visible: true,
        color: ['#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6'][layers.length % 4],
        plantDensity: 12,
        growthStage: 'vegetative' as const
      };
      setLayers([...layers, newLayer]);
      setShowAddForm(false);
    };
  
    const removeLayer = (layerId: string) => {
      setLayers(layers.filter(l => l.id !== layerId));
    };
  
    const updateLayer = (layerId: string, updates: any) => {
      setLayers(layers.map(l => l.id === layerId ? { ...l, ...updates } : l));
    };
  
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-medium text-gray-300">Growing Tiers</h4>
          <button 
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-xs flex items-center gap-1"
          >
            <Plus className="w-3 h-3" />
            Add
          </button>
        </div>
      
        {showAddForm && (
          <div className="p-3 bg-gray-700/70 rounded border border-purple-500/30">
            <div className="grid grid-cols-2 gap-2 mb-2">
              <input
                type="text"
                placeholder="Tier name"
                className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
              />
              <input
                type="number"
                placeholder="Height (in)"
                className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={addLayer}
                className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs"
              >
                Add Tier
              </button>
              <button
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1 bg-gray-600 hover:bg-gray-500 text-white rounded text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      
        <div className="space-y-2">
          {layers
            .sort((a, b) => b.height - a.height)
            .map((layer) => (
            <div key={layer.id} className="p-3 bg-gray-700/50 rounded border border-gray-600">
              {editingLayer === layer.id ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={layer.name}
                    onChange={(e) => updateLayer(layer.id, { name: e.target.value })}
                    className="w-full px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      value={layer.height}
                      onChange={(e) => updateLayer(layer.id, { height: Number(e.target.value) })}
                      className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                      placeholder="Height (in)"
                    />
                    <input
                      type="number"
                      value={layer.targetPPFD}
                      onChange={(e) => updateLayer(layer.id, { targetPPFD: Number(e.target.value) })}
                      className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-white text-xs"
                      placeholder="PPFD"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setEditingLayer(null)}
                      className="px-2 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => removeLayer(layer.id)}
                      className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: layer.color }}
                      />
                      <p className="text-sm font-medium text-white">{layer.name}</p>
                      <button
                        onClick={() => updateLayer(layer.id, { visible: !layer.visible })}
                        className="p-1 text-gray-400 hover:text-white"
                      >
                        {layer.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      </button>
                    </div>
                    <button
                      onClick={() => setEditingLayer(layer.id)}
                      className="p-1 text-gray-400 hover:text-white"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="text-xs text-gray-400 space-y-1">
                    <p>Height: {layer.height}" • {layer.cropType}</p>
                    <p>Target: {layer.targetPPFD} PPFD • {layer.plantDensity} plants/ft²</p>
                    <p>Bench: {layer.benchDepth}' × full width</p>
                  </div>
                
                  {/* Mini visualization */}
                  <div className="mt-2 h-2 bg-gray-800 rounded overflow-hidden relative">
                    <div 
                      className="absolute left-0 top-0 h-full rounded"
                      style={{
                        backgroundColor: layer.color,
                        width: `${Math.min(100, (layer.targetPPFD / 1000) * 100)}%`,
                        opacity: 0.7
                      }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xs text-white font-medium">
                        {layer.targetPPFD} PPFD
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      
        {layers.length > 1 && (
          <div className="p-2 bg-blue-900/30 border border-blue-600/50 rounded">
            <p className="text-xs text-blue-300">
              ✓ {layers.length} tier system • Total height: {Math.max(...layers.map(l => l.height + l.canopyHeight))}"</p>
            <p className="text-xs text-blue-400">
              Grow area: {layers.reduce((sum, l) => sum + (l.benchDepth * 10), 0)} ft²
            </p>
          </div>
        )}
      </div>
    );
  }

  function MetricsPanel({ activeTab }: { activeTab: string }) {
    const [environmentData, setEnvironmentData] = useState({
      temperature: 24,
      humidity: 60,
      co2: 1000
    });
    const [vpdData, setVpdData] = useState({
      temperature: 24,
      humidity: 60,
      leafTemperature: 24,
      vpd: 1.2,
      optimal: true,
      stress: 'none' as 'none' | 'low' | 'moderate' | 'high'
    });

    // Update VPD calculations when environment changes
    useEffect(() => {
      // Assume 400 PPFD as default for calculation
      const vpdResult = calculateVPDWithLighting(
        environmentData.temperature,
        environmentData.humidity,
        400, // Default PPFD
        { blue: 20, red: 65, farRed: 5 }
      );
      setVpdData({
        ...vpdResult,
        leafTemperature: vpdResult.leafTemperature || environmentData.temperature
      });
    }, [environmentData]);

    return (
      <div className="p-4 space-y-4">
        <h2 className="text-lg font-semibold text-white">Performance Metrics</h2>
      
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gray-800/50 p-3 rounded">
            <p className="text-xs text-gray-400 mb-1">Avg PPFD</p>
            <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">μmol/m²/s</span></p>
          </div>
          <div className="bg-gray-800/50 p-3 rounded">
            <p className="text-xs text-gray-400 mb-1">Uniformity</p>
            <p className="text-xl font-bold text-white">0% <span className="text-sm text-gray-400">avg/max</span></p>
          </div>
          <div className="bg-gray-800/50 p-3 rounded">
            <p className="text-xs text-gray-400 mb-1">DLI</p>
            <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">mol/m²/d</span></p>
          </div>
          <div className="bg-gray-800/50 p-3 rounded">
            <p className="text-xs text-gray-400 mb-1">Power</p>
            <p className="text-xl font-bold text-white">0 <span className="text-sm text-gray-400">kW</span></p>
          </div>
        </div>


        {/* Environment Controls */}
        <div className="bg-gray-800/50 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Droplets className="w-4 h-4 text-cyan-400" />
            Environment Settings
          </h3>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-gray-400">Temperature (°C)</label>
              <input
                type="number"
                value={environmentData.temperature}
                onChange={(e) => setEnvironmentData({
                  ...environmentData,
                  temperature: parseFloat(e.target.value) || 24
                })}
                className="w-full mt-1 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-sm text-white"
                step="0.5"
              />
            </div>
            <div>
              <label className="text-xs text-gray-400">Humidity (%)</label>
              <input
                type="number"
                value={environmentData.humidity}
                onChange={(e) => setEnvironmentData({
                  ...environmentData,
                  humidity: parseFloat(e.target.value) || 60
                })}
                className="w-full mt-1 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-sm text-white"
                step="5"
                min="0"
                max="100"
              />
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-purple-900/20 rounded-lg p-4 border border-purple-700/30">
          <div className="flex items-start gap-3">
            <Brain className="w-5 h-5 text-purple-400 mt-0.5" />
            <div>
              <h3 className="text-sm font-semibold text-white mb-1">AI Recommendations</h3>
              {vpdData.stress !== 'none' ? (
                <p className="text-xs text-gray-400">
                  {getVPDRecommendations(vpdData)[0]}
                </p>
              ) : (
                <p className="text-xs text-gray-400">VPD optimal for current conditions</p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  function AnalysisView({ fixtures, roomDimensions, tiers }: { 
    fixtures: Fixture[]; 
    roomDimensions: { width: number; length: number; height: number };
    tiers: any[]
  }) {
    const [ppfdStats, setPpfdStats] = useState({ min: 0, max: 0, avg: 0, uniformity: 0 });
    const [ppfdGrid, setPpfdGrid] = useState<number[][]>([]);
    const [photoperiod] = useState(18); // hours
  
    const activeFixtures = useMemo(() => fixtures.filter(f => f.enabled), [fixtures]);
    const totalPower = useMemo(() => activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0), [activeFixtures]);
    const totalPPF = useMemo(() => activeFixtures.reduce((sum, f) => sum + f.model.ppf, 0), [activeFixtures]);
  
    // Calculate real PPFD grid and stats
    useEffect(() => {
      if (activeFixtures.length > 0) {
        // Convert fixture positions to meters and add height
        const fixtureData = activeFixtures.map(f => ({
          x: (f.x / 100) * roomDimensions.width,
          y: (f.y / 100) * roomDimensions.length,
          z: roomDimensions.height - 0.5, // 0.5m below ceiling
          ppf: f.model.ppf,
          beamAngle: 120, // Default beam angle
          enabled: f.enabled,
          spectrumData: f.model.spectrumData
        }));
      
        // Calculate PPFD grid
        const grid = calculatePPFDGrid(
          fixtureData,
          roomDimensions.width,
          roomDimensions.length,
          1.0, // Canopy height 1m
          50 // Grid resolution
        );
      
        setPpfdGrid(grid);
        setPpfdStats(calculatePPFDStats(grid));
      } else {
        setPpfdStats({ min: 0, max: 0, avg: 0, uniformity: 0 });
        setPpfdGrid([]);
      }
    }, [activeFixtures, roomDimensions]);
  
    // Calculate spectrum mix
    const spectrumMix = calculateSpectrumMix(activeFixtures.map(f => ({
      ...f,
      x: 0, y: 0, z: 0, beamAngle: 120,
      ppf: f.model.ppf,
      spectrumData: f.model.spectrumData
    })));
  
    const dli = calculateDLI(ppfdStats.avg, photoperiod);
    const roomArea = roomDimensions.width * roomDimensions.length;
  
    return (
      <div className="p-8">
        <h2 className="text-2xl font-bold text-white mb-6">Lighting Analysis</h2>
      
        {/* Key Metrics */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">Average PPFD</p>
            <p className="text-2xl font-bold text-white">{ppfdStats.avg} <span className="text-sm text-gray-400">μmol/m²/s</span></p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">Total PPF</p>
            <p className="text-2xl font-bold text-white">{totalPPF} <span className="text-sm text-gray-400">μmol/s</span></p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">Total Power</p>
            <p className="text-2xl font-bold text-white">{totalPower} <span className="text-sm text-gray-400">W</span></p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">System Efficacy</p>
            <p className="text-2xl font-bold text-white">{totalPower > 0 ? (totalPPF / totalPower).toFixed(2) : '0'} <span className="text-sm text-gray-400">μmol/J</span></p>
          </div>
        </div>
      
        {/* DLI and Additional Metrics */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">DLI ({photoperiod}h photoperiod)</p>
            <p className="text-2xl font-bold text-white">{dli} <span className="text-sm text-gray-400">mol/m²/day</span></p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">Coverage Area</p>
            <p className="text-2xl font-bold text-white">{roomArea.toFixed(0)} <span className="text-sm text-gray-400">m²</span></p>
          </div>
          <div className="bg-gray-800/50 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-1">Fixtures/m²</p>
            <p className="text-2xl font-bold text-white">{roomArea > 0 ? (activeFixtures.length / roomArea).toFixed(2) : '0'} <span className="text-sm text-gray-400">units</span></p>
          </div>
        </div>
      
        <div className="grid grid-cols-2 gap-6">
          {/* PPFD Distribution */}
          <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">PPFD Distribution</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Min PPFD</span>
                  <span className="text-white">{ppfdStats.min} μmol/m²/s</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: ppfdStats.max > 0 ? `${(ppfdStats.min / ppfdStats.max) * 100}%` : '0%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Average PPFD</span>
                  <span className="text-white">{ppfdStats.avg} μmol/m²/s</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: ppfdStats.max > 0 ? `${(ppfdStats.avg / ppfdStats.max) * 100}%` : '0%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Max PPFD</span>
                  <span className="text-white">{ppfdStats.max} μmol/m²/s</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
              <div className="mt-6 p-4 bg-gray-900/50 rounded">
                <p className="text-sm text-gray-400 mb-2">Uniformity Ratio</p>
                <p className="text-xl font-bold text-white">{ppfdStats.uniformity} <span className="text-sm text-gray-400">min/avg</span></p>
              </div>
            </div>
          </div>
        
          {/* Spectrum Coverage */}
          <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Spectrum Distribution</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Blue (400-500nm)</span>
                  <span className="text-white">{spectrumMix.blue}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div className="bg-blue-500 h-3 rounded-full" style={{ width: `${spectrumMix.blue}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Green (500-600nm)</span>
                  <span className="text-white">{spectrumMix.green}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div className="bg-green-500 h-3 rounded-full" style={{ width: `${spectrumMix.green}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Red (600-700nm)</span>
                  <span className="text-white">{spectrumMix.red}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div className="bg-red-500 h-3 rounded-full" style={{ width: `${spectrumMix.red}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Far Red (700-800nm)</span>
                  <span className="text-white">{spectrumMix.farRed}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div className="bg-red-900 h-3 rounded-full" style={{ width: `${spectrumMix.farRed}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* VPD Analysis Section */}
        <div className="mt-6 bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Thermometer className="w-5 h-5 text-blue-400" />
            VPD Analysis
          </h3>
          <VPDAnalysis 
            avgPPFD={ppfdStats.avg} 
            spectrumMix={spectrumMix}
            roomDimensions={roomDimensions}
          />
        </div>
      
        {/* Electrical Analysis */}
        <div className="mt-6 bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Electrical Requirements</h3>
          <ElectricalLoadBalancer fixtures={activeFixtures.map(f => ({
            id: f.id,
            wattage: f.model.wattage,
            enabled: f.enabled
          }))} />
        </div>
      
        {/* Energy Cost Analysis */}
        <div className="mt-6 bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Energy Cost Analysis</h3>
          <EnergyCostCalculator
            fixtures={activeFixtures.map(f => ({
              wattage: f.model.wattage,
              enabled: f.enabled
            }))}
            photoperiod={photoperiod}
          />
        </div>
      </div>
    );
  }

  function OptimizationView({ fixtures, roomDimensions, onUpdateFixtures }: { 
    fixtures: Fixture[]; 
    roomDimensions: { width: number; length: number; height: number };
    onUpdateFixtures: (fixtures: Fixture[]) => void;
  }) {
    const [isOptimizing, setIsOptimizing] = useState(false);
    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [optimizationTarget, setOptimizationTarget] = useState<'uniformity' | 'energy' | 'coverage'>('uniformity');
  
    // Calculate current metrics for optimization
    const activeFixtures = fixtures.filter(f => f.enabled);
    const totalPower = activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0);
    const roomArea = roomDimensions.width * roomDimensions.length;
  
    // Calculate PPFD uniformity
    const calculateUniformity = () => {
      let ppfdValues: number[] = [];
      const samplePoints = 10;
    
      for (let x = 0; x < samplePoints; x++) {
        for (let y = 0; y < samplePoints; y++) {
          const xPos = (x / (samplePoints - 1)) * roomDimensions.width;
          const yPos = (y / (samplePoints - 1)) * roomDimensions.length;
        
          let ppfdAtPoint = 0;
          activeFixtures.forEach(fixture => {
            const fixtureX = (fixture.x / 100) * roomDimensions.width;
            const fixtureY = (fixture.y / 100) * roomDimensions.length;
            const dx = xPos - fixtureX;
            const dy = yPos - fixtureY;
            const distance = Math.sqrt(dx * dx + dy * dy + 6.25); // 2.5m height squared
          
            const intensity = fixture.model.ppf / (4 * Math.PI * distance * distance);
            ppfdAtPoint += intensity * 4.6;
          });
        
          ppfdValues.push(ppfdAtPoint);
        }
      }
    
      const avgPPFD = ppfdValues.reduce((a, b) => a + b, 0) / ppfdValues.length;
      const minPPFD = Math.min(...ppfdValues);
      return minPPFD / avgPPFD;
    };
  
    const runOptimization = () => {
      setIsOptimizing(true);
      setSuggestions([]);
    
      // Run real optimization
      setTimeout(() => {
        const constraints = {
          minPPFD: 400,
          maxPPFD: 800,
          targetPPFD: 600,
          minUniformity: 0.7,
          maxPowerDensity: 50 // W/m²
        };
      
        const goals = [
          { 
            type: optimizationTarget as 'uniformity' | 'efficiency' | 'coverage', 
            weight: 1 
          }
        ];
      
        const result = optimizeLightingDesign(fixtures, roomDimensions, constraints, goals);
        const newSuggestions = result.suggestions.map(s => s.description + ' - ' + s.implementation);
      
        setSuggestions(newSuggestions);
        setIsOptimizing(false);
      }, 2000);
    };
  
    const applyOptimalLayout = () => {
      const optimalLayout = generateOptimalLayout(
        roomDimensions,
        400, // Target PPFD
        { ppf: 1800, coverage: 4 } // Typical fixture specs
      );
    
      // Update fixtures with optimal positions
      const updatedFixtures = fixtures.map((f, i) => {
        if (i < optimalLayout.length) {
          return {
            ...f,
            x: (optimalLayout[i].x / roomDimensions.width) * 100,
            y: (optimalLayout[i].y / roomDimensions.length) * 100
          };
        }
        return f;
      });
    
      onUpdateFixtures(updatedFixtures);
    };
  
    return (
      <div className="p-8">
        <h2 className="text-2xl font-bold text-white mb-6">AI-Powered Design Optimization</h2>
      
        {/* Optimization Target Selector */}
        <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Select Optimization Target</h3>
          <div className="grid grid-cols-3 gap-4">
            <button
              onClick={() => setOptimizationTarget('uniformity')}
              className={`p-4 rounded-lg border-2 transition-all ${
                optimizationTarget === 'uniformity' 
                  ? 'border-purple-500 bg-purple-900/30' 
                  : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
              }`}
            >
              <Target className="w-6 h-6 text-yellow-400 mb-2 mx-auto" />
              <p className="text-sm font-medium text-white">Optimize Uniformity</p>
              <p className="text-xs text-gray-400 mt-1">Even light distribution</p>
            </button>
            <button
              onClick={() => setOptimizationTarget('energy')}
              className={`p-4 rounded-lg border-2 transition-all ${
                optimizationTarget === 'energy' 
                  ? 'border-purple-500 bg-purple-900/30' 
                  : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
              }`}
            >
              <Zap className="w-6 h-6 text-green-400 mb-2 mx-auto" />
              <p className="text-sm font-medium text-white">Minimize Energy</p>
              <p className="text-xs text-gray-400 mt-1">Reduce power usage</p>
            </button>
            <button
              onClick={() => setOptimizationTarget('coverage')}
              className={`p-4 rounded-lg border-2 transition-all ${
                optimizationTarget === 'coverage' 
                  ? 'border-purple-500 bg-purple-900/30' 
                  : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
              }`}
            >
              <TrendingUp className="w-6 h-6 text-purple-400 mb-2 mx-auto" />
              <p className="text-sm font-medium text-white">Maximize Coverage</p>
              <p className="text-xs text-gray-400 mt-1">Full canopy coverage</p>
            </button>
          </div>
        </div>
      
        {/* Current Performance */}
        <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Current Performance</h3>
          <div className="grid grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-400">Active Fixtures</p>
              <p className="text-xl font-bold text-white">{activeFixtures.length}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Power</p>
              <p className="text-xl font-bold text-white">{totalPower}W</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Coverage Area</p>
              <p className="text-xl font-bold text-white">{roomArea.toFixed(0)} m²</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Uniformity</p>
              <p className="text-xl font-bold text-white">{(calculateUniformity() * 100).toFixed(0)}%</p>
            </div>
          </div>
        </div>
      
        {/* Optimization Tools */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              AI-Powered Optimization
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Let our AI analyze your design and suggest improvements for optimal PPFD distribution and energy efficiency.
            </p>
            <button 
              onClick={runOptimization}
              disabled={isOptimizing}
              className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Brain className="w-4 h-4" />
              {isOptimizing ? 'Analyzing...' : `Optimize for ${optimizationTarget.charAt(0).toUpperCase() + optimizationTarget.slice(1)}`}
            </button>
          </div>
        
          <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Grid className="w-5 h-5 text-blue-400" />
              Auto-Layout Generator
            </h3>
            <p className="text-sm text-gray-400 mb-4">
              Automatically generate optimal fixture placement based on room dimensions and target PPFD.
            </p>
            <button 
              onClick={applyOptimalLayout}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Generate Layout
            </button>
          </div>
        </div>
      
        {/* Optimization Suggestions */}
        {suggestions.length > 0 && (
          <div className="bg-gray-800/50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Optimization Suggestions</h3>
            <div className="space-y-3">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-gray-900/50 rounded">
                  <div className="w-2 h-2 bg-purple-400 rounded-full mt-1.5 flex-shrink-0" />
                  <p className="text-sm text-gray-300">{suggestion}</p>
                </div>
              ))}
            </div>
          
            {/* Apply Optimal Layout Button */}
            <div className="mt-6 flex justify-center">
              <button
                onClick={applyOptimalLayout}
                className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <Check className="w-5 h-5" />
                Apply Optimal Layout
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  function ExportView({ fixtures, roomDimensions, tiers }: { 
    fixtures: Fixture[]; 
    roomDimensions: { width: number; length: number; height: number };
    tiers: any[]
  }) {
    const [isExporting, setIsExporting] = useState(false);
  
    const handlePDFExport = async () => {
      setIsExporting(true);
      try {
        const reportData = {
          projectName: `Lighting Design - ${new Date().toLocaleDateString()}`,
          roomDimensions,
          fixtures: fixtures.map(f => ({
            brand: f.model.brand,
            model: f.model.model,
            wattage: f.model.wattage,
            ppf: f.model.ppf,
            position: { x: f.x, y: f.y },
            enabled: f.enabled
          })),
          tiers,
          metrics: {
            totalFixtures: fixtures.length,
            totalPower: fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.wattage : 0), 0),
            totalPPF: fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.ppf : 0), 0),
            avgPPFD: Math.round(fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.ppf : 0), 0) / (roomDimensions.width * roomDimensions.length))
          }
        };
      
        // Get white label settings
        const whiteLabel = getWhiteLabelConfig();
        const whitelabelOptions = {
          companyName: whiteLabel.companyName,
          hideBranding: whiteLabel.hideBranding,
          primaryColor: whiteLabel.primaryColor
        };
      
        await exportToPDF(reportData, whitelabelOptions);
      } catch (error) {
        console.error('PDF export failed:', error);
      } finally {
        setIsExporting(false);
      }
    };
  
    const handleExcelExport = async () => {
      setIsExporting(true);
      try {
        const data = fixtures.map(f => ({
          'Fixture ID': f.id,
          'Brand': f.model.brand,
          'Model': f.model.model,
          'Wattage (W)': f.model.wattage,
          'PPF (μmol/s)': f.model.ppf,
          'Efficacy (μmol/J)': f.model.efficacy,
          'X Position': f.x,
          'Y Position': f.y,
          'Enabled': f.enabled ? 'Yes' : 'No'
        }));
      
        // Get white label settings
        const whiteLabel = getWhiteLabelConfig();
        await exportToExcel(data, 'lighting-design-export', {
          companyName: whiteLabel.companyName,
          hideBranding: whiteLabel.hideBranding
        });
      } catch (error) {
        console.error('Excel export failed:', error);
      } finally {
        setIsExporting(false);
      }
    };
  
    const handleCADExport = () => {
      // TODO: Implement CAD export
      alert('CAD export coming soon!');
    };
  
    const handleJSONExport = () => {
      const exportData = {
        version: '1.0',
        timestamp: new Date().toISOString(),
        project: {
          roomDimensions,
          fixtures,
          tiers
        }
      };
    
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `vibelux-design-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    };
  
    const handleEnhancedPDFExport = async () => {
      setIsExporting(true);
      try {
        const activeFixtures = fixtures.filter(f => f.enabled);
        const grid = calculatePPFDGrid(
          activeFixtures.map(f => ({
            x: (f.x / 100) * roomDimensions.width,
            y: (f.y / 100) * roomDimensions.length,
            z: roomDimensions.height - 0.5,
            ppf: f.model.ppf,
            beamAngle: 120,
            enabled: f.enabled
          })),
          roomDimensions.width,
          roomDimensions.length,
          1.0,
          50
        );
        const ppfdStats = calculatePPFDStats(grid);
      
        const reportData = {
          projectName: `Lighting Design - ${new Date().toLocaleDateString()}`,
          roomDimensions,
          fixtures: fixtures.map(f => ({
            brand: f.model.brand,
            model: f.model.model,
            wattage: f.model.wattage,
            ppf: f.model.ppf,
            efficacy: f.model.efficacy,
            position: { x: f.x, y: f.y },
            enabled: f.enabled,
            dimensions: getFixtureDimensions(f.model.model)
          })),
          ppfdAnalysis: {
            ...ppfdStats,
            dli: calculateDLI(ppfdStats.avg, 18)
          }
        };
      
        const whiteLabel = getWhiteLabelConfig();
        const generator = new PDFReportGenerator({
          companyName: whiteLabel.companyName,
          hideBranding: whiteLabel.hideBranding,
          primaryColor: whiteLabel.primaryColor
        });
      
        generator.generateReport(reportData);
      } catch (error) {
        console.error('Enhanced PDF export failed:', error);
      } finally {
        setIsExporting(false);
      }
    };
  
  const handleElectricalExport = () => {
      setIsExporting(true);
      try {
        // Group fixtures by power/location for circuit assignment
        const activeFixtures = fixtures.filter(f => f.enabled);
        const circuits: any[] = [];
        let currentCircuit: any = null;
        let circuitLoad = 0;
        let circuitNum = 1;
      
        activeFixtures.forEach(fixture => {
          if (!currentCircuit || circuitLoad + fixture.model.wattage > 3250) {
            // Start new circuit (80% of 20A @ 208V = 3328W)
            if (currentCircuit) circuits.push(currentCircuit);
            currentCircuit = {
              id: `C-${String(circuitNum).padStart(2, '0')}`,
              type: '20A_208V',
              voltage: 208,
              amperage: 20,
              phase: '1P',
              loadWatts: 0,
              loadPercent: 0,
              fixtures: []
            };
            circuitNum++;
            circuitLoad = 0;
          }
        
          currentCircuit.fixtures.push({
            id: fixture.id,
            model: `${fixture.model.brand} ${fixture.model.model}`,
            wattage: fixture.model.wattage,
            position: { x: fixture.x, y: fixture.y }
          });
          circuitLoad += fixture.model.wattage;
          currentCircuit.loadWatts = circuitLoad;
          currentCircuit.loadPercent = (circuitLoad / (20 * 208 * 0.8)) * 100;
        });
      
        if (currentCircuit) circuits.push(currentCircuit);
      
        const electricalData = {
          projectName: `Lighting Design`,
          totalLoad: activeFixtures.reduce((sum, f) => sum + f.model.wattage, 0),
          voltage: 208,
          phase: '1P',
          circuits,
          panelSchedule: {
            panelName: 'LP-1',
            mainBreaker: Math.ceil(circuits.length * 20 * 1.25),
            busRating: Math.ceil(circuits.length * 20 * 1.5),
            spaces: circuits.length + 4 // Some spares
          },
          roomDimensions
        };
      
        // Export circuit schedule CSV
        exportCircuitScheduleCSV(electricalData, 'circuit_schedule');
      
        // Export electrical blueprint PDF
        exportElectricalBlueprint(electricalData);
      
        // Export single line diagram
        exportSingleLineDiagram(electricalData);
      } catch (error) {
        console.error('Electrical export failed:', error);
      } finally {
        setIsExporting(false);
      }
    };
  
  const handlePFALAnalysis = () => {
      const metrics = calculatePFALMetrics(
        roomDimensions,
        tiers?.length || 1,
        fixtures,
        'leafy_greens' // Default crop type
      );
    
      const recommendations = generatePFALRecommendations(metrics);
    
      // Export PFAL analysis as CSV
      const analysisData = [
        { Category: 'Light Use Efficiency', Metric: 'Target PPFD', Value: `${metrics.lue.ppfdTarget} μmol/m²/s` },
        { Category: 'Light Use Efficiency', Metric: 'Actual PPFD', Value: `${metrics.lue.ppfdActual} μmol/m²/s` },
        { Category: 'Light Use Efficiency', Metric: 'DLI', Value: `${metrics.lue.dli} mol/m²/day` },
        { Category: 'Space Use Efficiency', Metric: 'Cultivation Area', Value: `${metrics.sue.cultivationArea} m²` },
        { Category: 'Space Use Efficiency', Metric: 'Volume Utilization', Value: `${metrics.sue.volumeUtilization}%` },
        { Category: 'Energy Use Efficiency', Metric: 'Total Power', Value: `${metrics.eue.totalPower} W` },
        { Category: 'Energy Use Efficiency', Metric: 'Power per m²', Value: `${metrics.eue.powerPerArea} W/m²` },
        { Category: 'Economics', Metric: 'Yield per m²', Value: `${metrics.economics.yieldPerArea} kg/m²` },
        { Category: 'Economics', Metric: 'Energy Cost per kg', Value: `$${metrics.economics.energyCostPerKg}` }
      ];
    
      exportToCSV(analysisData, 'pfal_analysis');
    };
  
  return (
      <div className="p-8">
        <h2 className="text-2xl font-bold text-white mb-6">Export Options</h2>
      
        {/* Export Summary */}
        <div className="bg-gray-800/50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Export Summary</h3>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-gray-400">Total Fixtures</p>
              <p className="text-xl font-bold text-white">{fixtures.length}</p>
            </div>
            <div>
              <p className="text-gray-400">Total Power</p>
              <p className="text-xl font-bold text-white">
                {fixtures.reduce((sum, f) => sum + (f.enabled ? f.model.wattage : 0), 0)}W
              </p>
            </div>
            <div>
              <p className="text-gray-400">Room Size</p>
              <p className="text-xl font-bold text-white">
                {roomDimensions.width}m × {roomDimensions.length}m
              </p>
            </div>
          </div>
        </div>
      
        {/* Export Options */}
        <div className="grid grid-cols-2 gap-6">
          <button 
            onClick={handlePDFExport}
            disabled={isExporting}
            className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors disabled:opacity-50"
          >
            <FileText className="w-8 h-8 text-purple-400 mb-3 mx-auto" />
            <p className="text-white font-medium mb-1">Export PDF Report</p>
            <p className="text-sm text-gray-400">Professional lighting design report</p>
          </button>
        
          <button 
            onClick={handleExcelExport}
            disabled={isExporting}
            className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors disabled:opacity-50"
          >
            <BarChart3 className="w-8 h-8 text-green-400 mb-3 mx-auto" />
            <p className="text-white font-medium mb-1">Export to Excel</p>
            <p className="text-sm text-gray-400">Fixture data spreadsheet</p>
          </button>
        
          <button 
            onClick={handleCADExport}
            className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors"
          >
            <Settings className="w-8 h-8 text-blue-400 mb-3 mx-auto" />
            <p className="text-white font-medium mb-1">Export CAD Files</p>
            <p className="text-sm text-gray-400">DWG/DXF format</p>
          </button>
        
          <button 
            onClick={handleJSONExport}
            className="p-6 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors"
          >
            <Download className="w-8 h-8 text-yellow-400 mb-3 mx-auto" />
            <p className="text-white font-medium mb-1">Export Project Data</p>
            <p className="text-sm text-gray-400">JSON format for backup</p>
          </button>
        </div>
      
        {/* Advanced Export Options */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-white mb-4">Advanced Export Options</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <button
              onClick={handleEnhancedPDFExport}
              className="p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors border border-purple-700/50"
            >
              <FileText className="w-6 h-6 text-purple-400 mb-2 mx-auto" />
              <p className="text-white font-medium text-sm mb-1">Enhanced PDF Report</p>
              <p className="text-xs text-gray-400">Detailed analysis with charts</p>
            </button>
          
            <button
              onClick={handleElectricalExport}
              className="p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors border border-blue-700/50"
            >
              <Zap className="w-6 h-6 text-blue-400 mb-2 mx-auto" />
              <p className="text-white font-medium text-sm mb-1">Electrical Plans</p>
              <p className="text-xs text-gray-400">Circuit schedule & blueprint</p>
            </button>
          
            <button
              onClick={handlePFALAnalysis}
              className="p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors border border-green-700/50"
            >
              <Activity className="w-6 h-6 text-green-400 mb-2 mx-auto" />
              <p className="text-white font-medium text-sm mb-1">PFAL Analysis</p>
              <p className="text-xs text-gray-400">Dr. Kozai methodology</p>
            </button>
          </div>
        </div>
      
        {isExporting && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-800 rounded-lg p-6">
              <p className="text-white">Exporting...</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  function DesignCanvas({ 
    selectedTool,
    fixtures,
    setFixtures,
    roomDimensions,
    setRoomDimensions,
    roomShape
  }: { 
    selectedTool: string;
    fixtures: Fixture[];
    setFixtures: React.Dispatch<React.SetStateAction<Fixture[]>>;
    roomDimensions: { width: number; length: number; height: number };
    setRoomDimensions: React.Dispatch<React.SetStateAction<{ width: number; length: number; height: number }>>;
    roomShape: string;
  }) {
    const [showPPFDMap, setShowPPFDMap] = useState(true);
    const [ppfdData, setPpfdData] = useState<number[][]>([]);
    const [selectedFixtures, setSelectedFixtures] = useState<string[]>([]);
    const [isDragging, setIsDragging] = useState(false);
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
    const [isSelecting, setIsSelecting] = useState(false);
    const [selectionBox, setSelectionBox] = useState({ startX: 0, startY: 0, endX: 0, endY: 0 });
    const canvasRef = useRef<HTMLDivElement>(null);

    // Generate real PPFD data for visualization
    useEffect(() => {
      if (fixtures.length > 0) {
        // Convert fixture positions to meters and add height
        const fixtureData = fixtures.map(f => ({
          x: (f.x / 100) * roomDimensions.width,
          y: (f.y / 100) * roomDimensions.length,
          z: roomDimensions.height - 0.5, // 0.5m below ceiling
          ppf: f.model.ppf,
          beamAngle: 120, // Default beam angle
          enabled: f.enabled,
          spectrumData: f.model.spectrumData
        }));
      
        // Calculate PPFD grid
        const grid = calculatePPFDGrid(
          fixtureData,
          roomDimensions.width,
          roomDimensions.length,
          1.0, // Canopy height 1m
          50 // Grid resolution
        );
      
        setPpfdData(grid);
      } else {
        // Empty grid
        const emptyGrid = Array(50).fill(null).map(() => Array(50).fill(0));
        setPpfdData(emptyGrid);
      }
    }, [fixtures, roomDimensions]);

    // Handle keyboard events for deletion and rotation
    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (selectedFixtures.length > 0) {
          if (e.key === 'Delete' || e.key === 'Backspace') {
            // Delete selected fixtures
            setFixtures(fixtures.filter(f => !selectedFixtures.includes(f.id)));
            setSelectedFixtures([]);
          } else if (e.key === 'r' || e.key === 'R') {
            // Rotate selected fixtures by 15 degrees
            setFixtures(fixtures.map(f => 
              selectedFixtures.includes(f.id) 
                ? { ...f, rotation: (f.rotation + 15) % 360 }
                : f
            ));
          } else if (e.key === 'Escape') {
            // Clear selection
            setSelectedFixtures([]);
          }
        }
      };

      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }, [selectedFixtures, fixtures, setFixtures]);

    const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
      if (selectedTool === 'place') {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
      
        // Add a default fixture
        const newFixture: Fixture = {
          id: `fixture-${Date.now()}`,
          x,
          y,
          rotation: 0,
          model: {
            id: 'default-led',
            brand: 'Generic',
            model: '600W LED',
            wattage: 600,
            ppf: 1600,
            efficacy: 2.67,
            spectrumData: {
              red: 65,
              blue: 20,
              green: 10,
              farRed: 5
            },
            coverage: 16 // 4x4 feet
          },
          enabled: true
        };
      
        setFixtures([...fixtures, newFixture]);
      } else if (selectedTool === 'select' && !isDragging && !isSelecting) {
        // Clear selection when clicking on empty space
        setSelectedFixtures([]);
      }
    };

    const handleFixtureClick = (e: React.MouseEvent, fixtureId: string) => {
      e.stopPropagation();
      
      if (selectedTool === 'select') {
        if (e.shiftKey) {
          // Multi-select with shift key
          setSelectedFixtures(prev => 
            prev.includes(fixtureId) 
              ? prev.filter(id => id !== fixtureId)
              : [...prev, fixtureId]
          );
        } else {
          // Single select
          setSelectedFixtures([fixtureId]);
        }
      }
    };

    const handleMouseDown = (e: React.MouseEvent, fixtureId?: string) => {
      if (selectedTool === 'select') {
        if (fixtureId && selectedFixtures.includes(fixtureId)) {
          // Start dragging
          const fixture = fixtures.find(f => f.id === fixtureId);
          if (fixture && canvasRef.current) {
            const rect = canvasRef.current.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            setDragOffset({ x: x - fixture.x, y: y - fixture.y });
            setIsDragging(true);
          }
        } else if (!fixtureId) {
          // Start selection box
          const rect = canvasRef.current!.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          setSelectionBox({ startX: x, startY: y, endX: x, endY: y });
          setIsSelecting(true);
        }
      }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
      if (isDragging && canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        
        // Update positions of all selected fixtures
        setFixtures(fixtures.map(f => {
          if (selectedFixtures.includes(f.id)) {
            return {
              ...f,
              x: Math.max(0, Math.min(100, x - dragOffset.x)),
              y: Math.max(0, Math.min(100, y - dragOffset.y))
            };
          }
          return f;
        }));
      } else if (isSelecting && canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        setSelectionBox(prev => ({ ...prev, endX: x, endY: y }));
      }
    };

    const handleMouseUp = () => {
      if (isSelecting) {
        // Select fixtures within selection box
        const minX = Math.min(selectionBox.startX, selectionBox.endX);
        const maxX = Math.max(selectionBox.startX, selectionBox.endX);
        const minY = Math.min(selectionBox.startY, selectionBox.endY);
        const maxY = Math.max(selectionBox.startY, selectionBox.endY);
        
        const selected = fixtures
          .filter(f => f.x >= minX && f.x <= maxX && f.y >= minY && f.y <= maxY)
          .map(f => f.id);
        
        setSelectedFixtures(selected);
      }
      
      setIsDragging(false);
      setIsSelecting(false);
    };

    console.log('DesignCanvas rendering with:', { roomDimensions, roomShape, fixtures: fixtures.length });
    
    return (
      <div className="absolute inset-0 p-4">
        <div 
          ref={canvasRef}
          className="relative w-full h-full"
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Base canvas with room boundaries and grid */}
          <div className="w-full h-full relative bg-slate-600 rounded-lg overflow-hidden border-4 border-white">
            {/* Grid background - more visible */}
            <div 
              className="absolute inset-0" 
              style={{
                backgroundImage: `
                  linear-gradient(rgba(255,255,255,0.5) 2px, transparent 2px),
                  linear-gradient(90deg, rgba(255,255,255,0.5) 2px, transparent 2px)
                `,
                backgroundSize: '40px 40px',
                backgroundColor: '#475569'
              }}
            />
            
            {/* Help text when room is small */}
            {roomDimensions.width === 0 || roomDimensions.length === 0 ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8 bg-gray-900/80 rounded-lg border border-purple-500/50">
                  <h3 className="text-xl font-semibold text-white mb-2">No Room Configured</h3>
                  <p className="text-gray-400 mb-4">Use the Room Configuration panel on the left to set your grow room dimensions.</p>
                  <p className="text-sm text-gray-500">Enter width, length, and height, then click "Update Room Layout"</p>
                </div>
              </div>
            ) : null}
            
            {/* Room shape with clear boundaries */}
            {roomShape === 'L-Shape' ? (
              // L-Shape room
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <defs>
                  <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="0.5"/>
                  </pattern>
                </defs>
                <rect width="100" height="100" fill="url(#grid)" />
                <path
                  d="M 10 10 L 60 10 L 60 40 L 90 40 L 90 90 L 10 90 Z"
                  fill="rgba(55, 65, 81, 0.8)"
                  stroke="rgb(209, 213, 219)"
                  strokeWidth="3"
                  vectorEffect="non-scaling-stroke"
                />
              </svg>
            ) : roomShape === 'Square' ? (
              // Square room (centered)
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="aspect-square h-full max-w-full border-4 border-gray-300 bg-gray-700 rounded-lg shadow-inner">
                  <div className="w-full h-full bg-gray-600"></div>
                </div>
              </div>
            ) : (
              // Rectangle room (default)
              <div className="absolute inset-0 p-8">
                <div className="w-full h-full border-8 border-yellow-400 bg-slate-700 rounded-xl shadow-2xl relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-600 to-slate-800 opacity-50"></div>
                  <div className="absolute top-4 left-4 text-white text-lg font-bold bg-black/70 px-4 py-2 rounded">
                    Room: {roomDimensions.width}m × {roomDimensions.length}m × {roomDimensions.height}m
                  </div>
                  {/* Inner grid */}
                  <div 
                    className="absolute inset-4" 
                    style={{
                      backgroundImage: `
                        linear-gradient(rgba(255,255,255,0.2) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(255,255,255,0.2) 1px, transparent 1px)
                      `,
                      backgroundSize: '20px 20px'
                    }}
                  />
                </div>
              </div>
            )}
            
            {/* PPFD Map overlay - only show if enabled and has fixtures */}
            {showPPFDMap && fixtures.length > 0 && (
              <div className="absolute inset-0">
                <FalseColorPPFDMap
                  width={roomDimensions.width}
                  height={roomDimensions.height}
                  ppfdData={ppfdData}
                  colorScale="turbo"
                  showGrid={false}
                  showContours={true}
                  showLabels={false}
                  targetPPFD={600}
                  opacity={0.8}
                />
              </div>
            )}
          </div>
            
          {/* Interactive overlay for fixtures and interactions */}
          <div 
              className={`absolute inset-0 ${selectedTool === 'place' ? 'cursor-crosshair' : 'cursor-default'}`}
              onClick={handleCanvasClick}
              onMouseDown={(e) => handleMouseDown(e)}
            >
                {/* Fixture overlays */}
                {fixtures.map(fixture => {
                  const isSelected = selectedFixtures.includes(fixture.id);
                  return (
                    <div
                      key={fixture.id}
                      className={`absolute w-10 h-10 transition-all duration-150 ${
                        isSelected 
                          ? 'z-10' 
                          : 'z-0'
                      }`}
                      style={{
                        left: `${fixture.x}%`,
                        top: `${fixture.y}%`,
                        transform: `translate(-50%, -50%) rotate(${fixture.rotation}deg)`,
                        cursor: selectedTool === 'select' ? 'pointer' : 'default'
                      }}
                      onClick={(e) => handleFixtureClick(e, fixture.id)}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        handleMouseDown(e, fixture.id);
                      }}
                    >
                      {/* Fixture visual */}
                      <div 
                        className={`w-full h-full rounded-lg transition-all duration-150 ${
                          isSelected 
                            ? 'bg-purple-500/30 border-2 border-purple-400 shadow-lg shadow-purple-500/50' 
                            : 'bg-white/20 border-2 border-white hover:border-purple-300'
                        }`}
                      >
                        <Sun className="w-5 h-5 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                      </div>
                      
                      {/* Rotation handle when selected */}
                      {isSelected && (
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
                          <div className="w-4 h-4 bg-purple-500 rounded-full cursor-move" title="Press R to rotate">
                            <RotateCw className="w-3 h-3 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Selection box */}
                {isSelecting && (
                  <div
                    className="absolute border-2 border-purple-400 bg-purple-400/10"
                    style={{
                      left: `${Math.min(selectionBox.startX, selectionBox.endX)}%`,
                      top: `${Math.min(selectionBox.startY, selectionBox.endY)}%`,
                      width: `${Math.abs(selectionBox.endX - selectionBox.startX)}%`,
                      height: `${Math.abs(selectionBox.endY - selectionBox.startY)}%`
                    }}
                  />
                )}
              </div>
          
          {/* Canvas controls and room info */}
          <div className="absolute top-4 right-4 flex items-center gap-4">
            {/* Room dimensions display */}
            <div className="bg-gray-900/90 backdrop-blur rounded-lg px-3 py-2 text-sm text-gray-300">
              <span className="font-medium">{roomShape}:</span> {roomDimensions.width}m × {roomDimensions.length}m × {roomDimensions.height}m
            </div>
            
            <button
              onClick={() => setShowPPFDMap(!showPPFDMap)}
              className={`px-3 py-2 rounded flex items-center gap-2 transition-colors ${
                showPPFDMap 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-gray-800 text-gray-400 hover:text-white'
              }`}
            >
              <Eye className="w-4 h-4" />
              <span className="text-sm">PPFD Map</span>
            </button>
          </div>
          
          {/* Instructions when no fixtures */}
          {fixtures.length === 0 && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
              <p className="text-gray-500 mb-2">Room layout ready</p>
              <p className="text-gray-400 text-sm">Select "Place Fixture (P)" tool to add lights</p>
            </div>
          )}

          {/* Selected fixture info */}
          {selectedFixtures.length > 0 && (
            <div className="absolute bottom-4 left-4 bg-gray-900/90 backdrop-blur rounded-lg p-4 max-w-sm">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-white">
                  {selectedFixtures.length} Fixture{selectedFixtures.length > 1 ? 's' : ''} Selected
                </h4>
                <button
                  onClick={() => {
                    setFixtures(fixtures.filter(f => !selectedFixtures.includes(f.id)));
                    setSelectedFixtures([]);
                  }}
                  className="text-red-400 hover:text-red-300 transition-colors"
                  title="Delete selected fixtures"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              {selectedFixtures.length === 1 && (
                <div className="space-y-1 text-xs text-gray-300">
                  {(() => {
                    const fixture = fixtures.find(f => f.id === selectedFixtures[0]);
                    if (!fixture) return null;
                    return (
                      <>
                        <p>Model: {fixture.model.brand} {fixture.model.model}</p>
                        <p>Power: {fixture.model.wattage}W</p>
                        <p>PPF: {fixture.model.ppf} μmol/s</p>
                        <p>Position: ({fixture.x.toFixed(1)}%, {fixture.y.toFixed(1)}%)</p>
                        <p>Rotation: {fixture.rotation}°</p>
                      </>
                    );
                  })()}
                </div>
              )}
              
              <div className="mt-3 text-xs text-gray-400">
                <p>• Press R to rotate</p>
                <p>• Press Delete to remove</p>
                <p>• Drag to move</p>
                <p>• Shift+Click for multi-select</p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  function VPDAnalysis({ avgPPFD, spectrumMix, roomDimensions }: { 
    avgPPFD: number; 
    spectrumMix: { blue: number; green: number; red: number; farRed: number };
    roomDimensions: { width: number; length: number; height: number };
  }) {
    // Use fixed optimal environmental values
    const environment = {
      temperature: 24,
      humidity: 60,
      co2: 1000
    };
    const targetVPD = 1.2;
  
    // Calculate VPD based on optimal conditions
    const vpdData = calculateVPDWithLighting(
      environment.temperature,
      environment.humidity,
      avgPPFD,
      spectrumMix
    );
  
    // Get target environment for desired VPD
    const targetEnv = calculateTargetEnvironment(targetVPD, avgPPFD, environment.temperature);
  
    // Adjust PPFD recommendation based on VPD
    const adjustedPPFD = adjustPPFDForVPD(avgPPFD, vpdData.vpd, targetVPD);
  
    // Get recommendations
    const recommendations = getVPDRecommendations(vpdData);
  
    return (
      <div className="space-y-4">
        {/* Current VPD Status */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-900/50 rounded p-3">
            <p className="text-xs text-gray-400 mb-1">Estimated VPD</p>
            <p className={`text-xl font-bold ${
              vpdData.optimal ? 'text-green-400' : 
              vpdData.stress === 'low' ? 'text-yellow-400' : 
              'text-red-400'
            }`}>
              {vpdData.vpd} kPa
            </p>
          </div>
          <div className="bg-gray-900/50 rounded p-3">
            <p className="text-xs text-gray-400 mb-1">Leaf Temperature</p>
            <p className="text-xl font-bold text-white">
              {vpdData.leafTemperature?.toFixed(1)}°C
              <span className="text-sm text-gray-400 ml-1">
                (+{(vpdData.leafTemperature! - vpdData.temperature).toFixed(1)}°C)
              </span>
            </p>
          </div>
          <div className="bg-gray-900/50 rounded p-3">
            <p className="text-xs text-gray-400 mb-1">Status</p>
            <p className={`text-xl font-bold ${
              vpdData.optimal ? 'text-green-400' : 'text-yellow-400'
            }`}>
              {vpdData.optimal ? 'Optimal' : 'Adjust'}
            </p>
          </div>
        </div>
      
        {/* Optimal Environment Info */}
        <div className="bg-gray-900/50 rounded p-3">
          <p className="text-xs text-gray-400 mb-2">Assumed Optimal Environment</p>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-gray-400">Temperature:</span>
              <span className="text-white ml-1">{environment.temperature}°C</span>
            </div>
            <div>
              <span className="text-gray-400">Humidity:</span>
              <span className="text-white ml-1">{environment.humidity}%</span>
            </div>
            <div>
              <span className="text-gray-400">Target VPD:</span>
              <span className="text-white ml-1">{targetVPD} kPa</span>
            </div>
          </div>
        </div>
      
        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div className="bg-yellow-900/20 border border-yellow-700/30 rounded p-4">
            <h4 className="text-sm font-semibold text-yellow-400 mb-2">VPD Recommendations</h4>
            <ul className="space-y-1 text-xs text-yellow-300">
              {recommendations.map((rec, idx) => (
                <li key={idx}>• {rec}</li>
              ))}
            </ul>
          </div>
        )}
      
        {/* Target Achievement */}
        <div className="bg-blue-900/20 border border-blue-700/30 rounded p-4">
          <h4 className="text-sm font-semibold text-blue-400 mb-2">To Achieve Target VPD of {targetVPD} kPa:</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-400">Option 1: Adjust Environment</p>
              <p className="text-white">
                Set humidity to {targetEnv.humidity.toFixed(0)}% at {targetEnv.temperature}°C
              </p>
            </div>
            <div>
              <p className="text-gray-400">Option 2: Adjust Lighting</p>
              <p className="text-white">
                {adjustedPPFD < avgPPFD ? 'Reduce' : 'Increase'} PPFD to {adjustedPPFD.toFixed(0)} μmol/m²/s
              </p>
            </div>
          </div>
        </div>
      
        {/* VPD Chart */}
        <div className="bg-gray-900/50 rounded p-4">
          <h4 className="text-sm font-semibold text-white mb-3">VPD Range by Growth Stage</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Propagation (0.4-0.8 kPa)</span>
              <div className="w-32 bg-gray-700 rounded-full h-2 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full" 
                     style={{ width: '40%' }}></div>
                {vpdData.vpd >= 0.4 && vpdData.vpd <= 0.8 && (
                  <div className="absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"
                       style={{ left: `${((vpdData.vpd - 0.4) / 0.4) * 40}%` }}></div>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Vegetative (0.8-1.2 kPa)</span>
              <div className="w-32 bg-gray-700 rounded-full h-2 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-green-600 rounded-full" 
                     style={{ width: '40%', left: '40%' }}></div>
                {vpdData.vpd >= 0.8 && vpdData.vpd <= 1.2 && (
                  <div className="absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"
                       style={{ left: `${40 + ((vpdData.vpd - 0.8) / 0.4) * 40}%` }}></div>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Flowering (1.0-1.5 kPa)</span>
              <div className="w-32 bg-gray-700 rounded-full h-2 relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full" 
                     style={{ width: '50%', left: '50%' }}></div>
                {vpdData.vpd >= 1.0 && vpdData.vpd <= 1.5 && (
                  <div className="absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"
                       style={{ left: `${50 + ((vpdData.vpd - 1.0) / 0.5) * 50}%` }}></div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  function HelpModal({ onClose }: { onClose: () => void }) {
    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
        <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full mx-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Keyboard Shortcuts</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-semibold text-purple-400 mb-2">Tools</h3>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Select Tool</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">V</kbd>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Place Fixture</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">P</kbd>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Rotate</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">R</kbd>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-purple-400 mb-2">Actions</h3>
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Save Project</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘S</kbd>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Undo</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘Z</kbd>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Redo</span>
                  <kbd className="px-2 py-1 bg-gray-800 rounded text-xs">⌘⇧Z</kbd>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-gray-950" style={{ backgroundColor: '#000000' }}>
      {/* Header Toolbar */}
      <div className="bg-gray-900/90 backdrop-blur-xl border-b border-gray-700 sticky top-0 z-40">
        <div className="px-4 py-2">
          <div className="flex items-center justify-between">
            {/* Left: Project Info & Tools */}
            <div className="flex items-center gap-4">
              <h1 className="text-lg font-semibold text-white">Advanced Lighting Designer</h1>
              
              {/* Tool Selection */}
              <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
                {tools.map(tool => (
                  <button
                    key={tool.id}
                    onClick={() => setSelectedTool(tool.id)}
                    className={`p-2 rounded transition-colors ${
                      selectedTool === tool.id 
                        ? 'bg-purple-600 text-white' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-700'
                    }`}
                    title={tool.tooltip}
                  >
                    <tool.icon className="w-4 h-4" />
                  </button>
                ))}
              </div>

              {/* View Options */}
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShow3D(true)}
                  className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors flex items-center gap-2"
                  title="3D View"
                >
                  <Cube className="w-4 h-4" />
                  <span className="text-sm">3D View</span>
                </button>
                <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Center: Tabs */}
            <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 py-2 rounded flex items-center gap-2 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2">
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                <Undo className="w-4 h-4" />
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors">
                <Redo className="w-4 h-4" />
              </button>
              <div className="w-px h-6 bg-gray-700" />
              <button className="px-3 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded flex items-center gap-2 transition-colors">
                <Save className="w-4 h-4" />
                <span className="text-sm">Save</span>
              </button>
              <button
                onClick={() => setShowHelp(true)}
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors"
              >
                <HelpCircle className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex h-[calc(100vh-60px)] bg-gray-950">
        {/* Left Sidebar */}
        <div className="w-80 bg-gray-900/50 backdrop-blur-xl border-r border-gray-700 overflow-y-auto">
          <div className="p-4 space-y-4">
            {sidebarSections.map(section => (
              <div key={section.id} className="bg-gray-800/50 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-800/70 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {React.createElement(section.icon, { className: "w-5 h-5 text-purple-400" })}
                    <div className="text-left">
                      <h3 className="text-sm font-semibold text-white">{section.title}</h3>
                      <p className="text-xs text-gray-400">{section.description}</p>
                    </div>
                  </div>
                  {section.expanded ? (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  )}
                </button>
                
                {section.expanded && (
                  <div className="p-4 pt-0">
                    {section.id === 'room' && <RoomConfiguration roomDimensions={roomDimensions} onUpdateDimensions={setRoomDimensions} roomShape={roomShape} setRoomShape={setRoomShape} />}
                    {section.id === 'fixtures' && <FixtureLibraryPanel />}
                    {section.id === 'layers' && <CanopyLayersPanel onLayersChange={setMultiTierLayers} />}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Center: Canvas Area */}
        <div className="flex-1 relative bg-gray-800 border-2 border-purple-500">
          {activeTab === 'design' && (
            <DesignCanvas 
              selectedTool={selectedTool}
              fixtures={fixtures}
              setFixtures={setFixtures}
              roomDimensions={roomDimensions}
              setRoomDimensions={setRoomDimensions}
              roomShape={roomShape}
            />
          )}
          
          {activeTab === 'analyze' && (
            <AnalysisView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
              tiers={multiTierLayers}
            />
          )}
          {activeTab === 'optimize' && (
            <OptimizationView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
              onUpdateFixtures={setFixtures}
            />
          )}
          {activeTab === 'export' && (
            <ExportView 
              fixtures={fixtures}
              roomDimensions={roomDimensions}
              tiers={multiTierLayers}
            />
          )}
        </div>

        {/* Right Panel: Metrics & Analysis */}
        <div className="w-96 bg-gray-900/50 backdrop-blur-xl border-l border-gray-700 overflow-y-auto">
          <MetricsPanel activeTab={activeTab} />
        </div>
      </div>

      {/* Help Modal */}
      {showHelp && (
        <HelpModal onClose={() => setShowHelp(false)} />
      )}
      
      {/* 3D WebGL View Modal */}
      <Room3DModal
        isOpen={show3D}
        onClose={() => setShow3D(false)}
        roomDimensions={roomDimensions}
        fixtures={fixtures.map(f => ({
          id: f.id,
          x: f.x - 50, // Convert from percentage to meters
          y: f.y - 50,
          z: 2.5, // Default mounting height
          rotation: f.rotation,
          model: {
            brand: f.model.brand,
            model: f.model.model,
            wattage: f.model.wattage,
            ppf: f.model.ppf,
            beamAngle: 120
          },
          enabled: f.enabled
        }))}
        tiers={multiTierLayers}
      />
    </div>
  );
}
