"use client"

import { useState, useRef, useEffect } from 'react'
import { MessageSquare, X, Send, Sparkles, Loader2, Minimize2, Maximize2 } from 'lucide-react'

interface Message {
  id: string
  text: string
  sender: 'user' | 'assistant' | 'system'
  timestamp: Date
}

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your Vibelux AI Assistant. I can help you with:",
      sender: 'assistant',
      timestamp: new Date()
    },
    {
      id: '2',
      text: "• Lighting calculations (PPFD, DLI)\n• Fixture recommendations\n• Energy optimization\n• Spectrum tuning\n• Growing tips",
      sender: 'assistant',
      timestamp: new Date()
    }
  ])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Listen for open events from other components
  useEffect(() => {
    const handleOpenEvent = () => {
      console.log('AI Assistant: Received open event')
      setIsOpen(true)
    }
    
    window.addEventListener('openAIAssistant', handleOpenEvent)
    console.log('AI Assistant: Event listener registered')
    return () => window.removeEventListener('openAIAssistant', handleOpenEvent)
  }, [])

  const sendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    // Check if OpenAI is enabled in settings
    const aiSettings = localStorage.getItem('aiAssistantSettings')
    const settings = aiSettings ? JSON.parse(aiSettings) : { useOpenAI: false }

    if (settings.useOpenAI && settings.apiKey) {
      try {
        const response = await fetch('/api/ai-assistant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            messages: [{ role: 'user', content: input }],
            apiKey: settings.apiKey,
            orgId: settings.orgId
          })
        })

        if (response.ok) {
          const data = await response.json()
          
          const assistantMessage: Message = {
            id: (Date.now() + 1).toString(),
            text: data.content || "I'm here to help! Could you please rephrase your question?",
            sender: 'assistant',
            timestamp: new Date()
          }

          setMessages(prev => [...prev, assistantMessage])
          
          // Show usage info if available
          if (data.usage) {
            const usageMessage: Message = {
              id: (Date.now() + 2).toString(),
              text: `💡 Credits: ${data.usage.remaining}/${data.usage.monthlyLimit} remaining this month`,
              sender: 'system',
              timestamp: new Date()
            }
            setTimeout(() => {
              setMessages(prev => [...prev, usageMessage])
            }, 500)
          }
          
          setIsLoading(false)
          return
        }
        
        // Handle rate limit error
        if (response.status === 429) {
          const errorData = await response.json()
          const errorMessage: Message = {
            id: (Date.now() + 1).toString(),
            text: errorData.message || 'You have reached your monthly AI query limit. Please upgrade your plan for more queries.',
            sender: 'assistant',
            timestamp: new Date()
          }
          setMessages(prev => [...prev, errorMessage])
          setIsLoading(false)
          return
        }
      } catch (error) {
        console.error('Error calling AI Assistant API:', error)
      }
    }

    // Use fallback responses
    const fallbackResponse = getFallbackResponse(input.toLowerCase())
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: fallbackResponse,
      sender: 'assistant',
      timestamp: new Date()
    }
    setMessages(prev => [...prev, assistantMessage])
    setIsLoading(false)
  }

  const getFallbackResponse = (query: string): string => {
    // Check for specific crops
    if (query.includes('pineapple') || query.includes('pinapple')) {
      return "For pineapple cultivation:\n• PPFD: 300-500 μmol/m²/s for optimal growth\n• Photoperiod: 12-14 hours\n• DLI: 15-20 mol/m²/day\n• Temperature: 68-86°F (20-30°C), ideally 75-85°F\n• Humidity: 60-70%\n• Spectrum: Balanced red:blue (3:1 ratio)\n\nPineapples are CAM plants, so they photosynthesize differently. They need:\n• Moderate to high light intensity\n• Good air circulation\n• Can be induced to flower with ethylene treatment\n• Full growth cycle: 14-20 months"
    }
    if (query.includes('lettuce')) {
      return "For lettuce:\n• PPFD: 150-250 μmol/m²/s (optimal 200)\n• Photoperiod: 14-16 hours\n• DLI: 12-17 mol/m²/day\n• Spectrum: Higher blue ratio (20-30%) for compact growth\n• Temperature: 60-70°F (15-21°C)\n\nSeedlings need 100-150 μmol/m²/s, while mature plants can handle up to 250 μmol/m²/s."
    }
    if (query.includes('tomato')) {
      return "For tomatoes:\n• Seedlings: 200-300 μmol/m²/s\n• Vegetative: 400-600 μmol/m²/s\n• Flowering/Fruiting: 600-900 μmol/m²/s\n• DLI: 20-30 mol/m²/day\n• Photoperiod: 16-18 hours\n• Use higher red:far-red ratio during fruiting"
    }
    if (query.includes('cannabis') || query.includes('hemp')) {
      return "For cannabis:\n• Vegetative: 400-600 μmol/m²/s (18-24h photoperiod)\n• Flowering: 600-900 μmol/m²/s (12h photoperiod)\n• DLI: 25-50 mol/m²/day\n• CO₂ enrichment allows up to 1200 μmol/m²/s\n• Maintain high red:far-red ratio for dense flowers"
    }
    if (query.includes('herbs') || query.includes('basil')) {
      return "For herbs (basil, cilantro, parsley):\n• PPFD: 150-300 μmol/m²/s\n• Photoperiod: 14-16 hours\n• DLI: 10-16 mol/m²/day\n• Higher blue spectrum (25-30%) for flavor compounds\n• Most herbs prefer 200-250 μmol/m²/s for optimal growth"
    }
    if (query.includes('strawberry') || query.includes('berries')) {
      return "For strawberries:\n• Vegetative: 200-300 μmol/m²/s\n• Flowering: 300-500 μmol/m²/s\n• Fruiting: 400-600 μmol/m²/s\n• DLI: 15-20 mol/m²/day\n• Photoperiod: 12-16 hours depending on variety\n• Increase far-red during flowering initiation"
    }
    if (query.includes('ppfd') || query.includes('light intensity')) {
      return "PPFD (Photosynthetic Photon Flux Density) measures the amount of light that reaches your plants. For most crops:\n• Seedlings: 100-300 μmol/m²/s\n• Vegetative: 300-600 μmol/m²/s\n• Flowering: 600-1000 μmol/m²/s\n\nAsk about specific crops for detailed recommendations!"
    }
    if (query.includes('dli')) {
      return "DLI (Daily Light Integral) is the total amount of light received per day. Calculate it with: DLI = PPFD × photoperiod hours × 0.0036. Most crops need:\n• Leafy greens: 12-17 mol/m²/day\n• Herbs: 10-16 mol/m²/day\n• Fruiting crops: 20-30 mol/m²/day\n• High-light crops: 30-50 mol/m²/day"
    }
    if (query.includes('spectrum') || query.includes('color')) {
      return "Light spectrum affects plant growth:\n• Blue (400-500nm): Promotes compact growth, strong stems\n• Red (600-700nm): Drives photosynthesis and flowering\n• Far-red (700-800nm): Controls flowering and stem elongation\n• Green (500-600nm): Penetrates canopy, overall plant health\n• UV (280-400nm): Enhances flavor and color compounds"
    }
    if (query.includes('uniformity')) {
      return "Light uniformity ensures even growth across your canopy. Aim for:\n• Minimum uniformity ratio: 0.7 (min/avg PPFD)\n• CV (coefficient of variation): <30%\n• Use our PPFD heat map tool to visualize and optimize uniformity\n• Proper fixture spacing: typically 2-4 feet on center"
    }
    if (query.includes('calculate') || query.includes('how many')) {
      return "To calculate your lighting needs:\n1. Determine target PPFD for your crop\n2. Measure your growing area\n3. Calculate total PPF needed: Area × PPFD\n4. Divide by fixture PPF output\n5. Add 10-20% for wall losses\n\nUse our calculators for precise results!"
    }
    return "I can help you with lighting calculations, fixture recommendations, spectrum optimization, and growing tips. Try asking about:\n• Specific crops (lettuce, tomatoes, herbs, etc.)\n• PPFD requirements\n• DLI calculations\n• Spectrum optimization\n• Energy efficiency"
  }

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => {
          console.log('AI Assistant: Floating button clicked')
          setIsOpen(true)
        }}
        className="fixed bottom-6 right-6 p-4 bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-full shadow-lg hover:shadow-xl transform transition-all duration-300 hover:scale-110"
        style={{ zIndex: 999999, position: 'fixed', display: 'block' }}
        aria-label="Open AI Assistant"
      >
        <div className="relative">
          <MessageSquare className="w-6 h-6" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse" />
        </div>
      </button>

      {/* Chat Panel */}
      <div
        className={`fixed transition-all duration-300 ${
          isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full pointer-events-none'
        } ${
          isMinimized ? 'bottom-6 right-6 w-80 h-16' : 'bottom-6 right-6 w-96 h-[600px]'
        }`}
        style={{ zIndex: 999999, position: 'fixed' }}
      >
        <div className="bg-gray-900 rounded-2xl shadow-2xl border border-gray-800 h-full flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 backdrop-blur rounded-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-semibold">AI Assistant</h3>
                <p className="text-purple-100 text-xs">Ask me anything about lighting</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                {isMinimized ? <Maximize2 className="w-4 h-4 text-white" /> : <Minimize2 className="w-4 h-4 text-white" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.sender === 'user' ? 'justify-end' : 
                      message.sender === 'system' ? 'justify-center' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                        message.sender === 'user'
                          ? 'bg-purple-600 text-white'
                          : message.sender === 'system'
                          ? 'bg-gray-900 text-gray-400 border border-gray-700 text-center text-xs'
                          : 'bg-gray-800 text-gray-100 border border-gray-700'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                      {message.sender !== 'system' && (
                        <p className="text-xs opacity-70 mt-1">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 rounded-2xl px-4 py-2 border border-gray-700">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                        <span className="text-sm text-gray-400">Thinking...</span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Actions */}
              <div className="p-3 border-t border-gray-800">
                <div className="flex gap-2 mb-3 overflow-x-auto">
                  {['Calculate PPFD', 'Optimize Spectrum', 'Energy Savings'].map((action) => (
                    <button
                      key={action}
                      onClick={() => setInput(action)}
                      className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded-full text-xs text-gray-300 whitespace-nowrap transition-colors"
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              {/* Input */}
              <div className="p-4 border-t border-gray-800">
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    sendMessage()
                  }}
                  className="flex gap-2"
                >
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask about lighting, PPFD, DLI..."
                    className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    disabled={isLoading}
                  />
                  <button
                    type="submit"
                    disabled={isLoading || !input.trim()}
                    className="p-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed rounded-xl transition-colors"
                  >
                    <Send className="w-5 h-5 text-white" />
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  )
}