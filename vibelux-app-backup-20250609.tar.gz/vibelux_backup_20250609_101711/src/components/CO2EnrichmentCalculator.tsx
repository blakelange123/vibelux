"use client"

import { useState } from 'react'
import { 
  Wind, 
  TrendingUp, 
  Leaf, 
  Calculator,
  AlertCircle,
  Gauge,
  Target,
  Info,
  Flame,
  Factory,
  DollarSign
} from 'lucide-react'

export function CO2EnrichmentCalculator() {
  const [roomVolume, setRoomVolume] = useState(1000) // cubic feet
  const [currentCO2, setCurrentCO2] = useState(400) // ppm
  const [targetCO2, setTargetCO2] = useState(1200) // ppm
  const [airExchanges, setAirExchanges] = useState(0.5) // per hour
  const [lightIntensity, setLightIntensity] = useState(600) // PPFD
  const [temperature, setTemperature] = useState(25) // Celsius
  const [plantCount, setPlantCount] = useState(100)
  const [growthStage, setGrowthStage] = useState<'seedling' | 'vegetative' | 'flowering'>('vegetative')
  const [enrichmentMethod, setEnrichmentMethod] = useState<'tanks' | 'burner' | 'generator'>('tanks')
  const [operatingHours, setOperatingHours] = useState(12)
  const [co2Cost, setCo2Cost] = useState(0.50) // per pound

  // Calculate CO2 enrichment requirements
  const co2Deficit = targetCO2 - currentCO2
  const roomVolumeM3 = roomVolume * 0.0283168
  const co2NeededGrams = (roomVolumeM3 * co2Deficit * 1.8) / 1000
  const co2NeededPounds = co2NeededGrams * 0.00220462
  
  // Account for air exchanges
  const hourlyLoss = co2NeededPounds * airExchanges
  const totalDailyNeed = (co2NeededPounds + (hourlyLoss * operatingHours))
  const monthlyNeed = totalDailyNeed * 30
  
  // Calculate costs
  const dailyCost = totalDailyNeed * co2Cost
  const monthlyCost = monthlyNeed * co2Cost
  const yearlyCost = monthlyCost * 12

  // Photosynthesis rate calculation
  const photosynthesisIncrease = Math.min(
    ((targetCO2 - 400) / 400) * 30, // Max 30% increase
    (lightIntensity / 1000) * 35 // Light limited
  )

  // Optimal CO2 based on light intensity
  const optimalCO2 = Math.min(400 + (lightIntensity * 1.5), 1500)

  // Tank calculations
  const tankSize = 20 // pounds
  const tanksPerMonth = Math.ceil(monthlyNeed / tankSize)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-400 mb-2">
          CO₂ Enrichment Calculator
        </h1>
        <p className="text-gray-400">
          Optimize CO₂ levels for maximum photosynthesis efficiency
        </p>
      </div>

      {/* Input Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Room Parameters */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Factory className="w-5 h-5 text-blue-400" />
            Room Parameters
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Room Volume (ft³)
              </label>
              <input
                type="number"
                value={roomVolume}
                onChange={(e) => setRoomVolume(Number(e.target.value))}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Air Exchanges per Hour
              </label>
              <input
                type="number"
                value={airExchanges}
                onChange={(e) => setAirExchanges(Number(e.target.value))}
                step="0.1"
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Light Intensity (PPFD)
              </label>
              <input
                type="number"
                value={lightIntensity}
                onChange={(e) => setLightIntensity(Number(e.target.value))}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Operating Hours per Day
              </label>
              <input
                type="number"
                value={operatingHours}
                onChange={(e) => setOperatingHours(Number(e.target.value))}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              />
            </div>
          </div>
        </div>

        {/* CO2 Settings */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Wind className="w-5 h-5 text-green-400" />
            CO₂ Settings
          </h3>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Current CO₂ (ppm)
                </label>
                <input
                  type="number"
                  value={currentCO2}
                  onChange={(e) => setCurrentCO2(Number(e.target.value))}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Target CO₂ (ppm)
                </label>
                <input
                  type="number"
                  value={targetCO2}
                  onChange={(e) => setTargetCO2(Number(e.target.value))}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Enrichment Method
              </label>
              <select
                value={enrichmentMethod}
                onChange={(e) => setEnrichmentMethod(e.target.value as any)}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              >
                <option value="tanks">CO₂ Tanks</option>
                <option value="burner">Natural Gas Burner</option>
                <option value="generator">CO₂ Generator</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Growth Stage
              </label>
              <select
                value={growthStage}
                onChange={(e) => setGrowthStage(e.target.value as any)}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              >
                <option value="seedling">Seedling</option>
                <option value="vegetative">Vegetative</option>
                <option value="flowering">Flowering</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                CO₂ Cost ($/lb)
              </label>
              <input
                type="number"
                value={co2Cost}
                onChange={(e) => setCo2Cost(Number(e.target.value))}
                step="0.01"
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-green-500 focus:outline-none transition-colors"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 backdrop-blur-xl rounded-xl border border-green-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Wind className="w-5 h-5 text-green-400" />
            <p className="text-sm text-gray-400">Daily CO₂ Need</p>
          </div>
          <p className="text-2xl font-bold text-white">{totalDailyNeed.toFixed(1)} lbs</p>
          <p className="text-xs text-gray-400 mt-1">{(totalDailyNeed * 453.592).toFixed(0)}g</p>
        </div>

        <div className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 backdrop-blur-xl rounded-xl border border-blue-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-blue-400" />
            <p className="text-sm text-gray-400">Photosynthesis Boost</p>
          </div>
          <p className="text-2xl font-bold text-white">+{photosynthesisIncrease.toFixed(0)}%</p>
          <p className="text-xs text-gray-400 mt-1">From baseline</p>
        </div>

        <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-xl rounded-xl border border-purple-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-purple-400" />
            <p className="text-sm text-gray-400">Monthly Cost</p>
          </div>
          <p className="text-2xl font-bold text-white">${monthlyCost.toFixed(0)}</p>
          <p className="text-xs text-gray-400 mt-1">${yearlyCost.toFixed(0)}/year</p>
        </div>

        <div className="bg-gradient-to-br from-yellow-900/50 to-orange-900/50 backdrop-blur-xl rounded-xl border border-yellow-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-5 h-5 text-yellow-400" />
            <p className="text-sm text-gray-400">Optimal CO₂</p>
          </div>
          <p className="text-2xl font-bold text-white">{Math.round(optimalCO2)} ppm</p>
          <p className="text-xs text-gray-400 mt-1">For {lightIntensity} PPFD</p>
        </div>
      </div>

      {/* Detailed Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Supply Requirements */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Supply Requirements</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Room Volume</span>
              <span className="text-white font-medium">{roomVolumeM3.toFixed(1)} m³</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">CO₂ Deficit</span>
              <span className="text-white font-medium">{co2Deficit} ppm</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Initial Fill</span>
              <span className="text-white font-medium">{co2NeededPounds.toFixed(2)} lbs</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Hourly Loss</span>
              <span className="text-white font-medium">{hourlyLoss.toFixed(2)} lbs/hr</span>
            </div>
            
            {enrichmentMethod === 'tanks' && (
              <div className="flex justify-between items-center p-3 bg-green-500/10 rounded-lg border border-green-500/30">
                <span className="text-green-400">Tanks per Month</span>
                <span className="text-white font-bold">{tanksPerMonth} × {tankSize}lb</span>
              </div>
            )}
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Recommendations</h3>
          
          <div className="space-y-3">
            {targetCO2 > optimalCO2 + 100 && (
              <div className="flex items-start gap-2 p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-yellow-400 font-medium">Target CO₂ Too High</p>
                  <p className="text-sm text-gray-300 mt-1">
                    Your target exceeds optimal levels for {lightIntensity} PPFD. Consider {Math.round(optimalCO2)} ppm.
                  </p>
                </div>
              </div>
            )}
            
            {photosynthesisIncrease > 20 && (
              <div className="flex items-start gap-2 p-3 bg-green-500/10 rounded-lg border border-green-500/30">
                <Leaf className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-green-400 font-medium">Significant Growth Boost</p>
                  <p className="text-sm text-gray-300 mt-1">
                    Expect {photosynthesisIncrease.toFixed(0)}% faster growth and higher yields.
                  </p>
                </div>
              </div>
            )}
            
            {airExchanges > 1 && (
              <div className="flex items-start gap-2 p-3 bg-blue-500/10 rounded-lg border border-blue-500/30">
                <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-blue-400 font-medium">High Air Exchange Rate</p>
                  <p className="text-sm text-gray-300 mt-1">
                    Consider reducing ventilation during CO₂ enrichment to minimize losses.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Cost Breakdown */}
      <div className="bg-gradient-to-br from-purple-900/20 to-pink-900/20 backdrop-blur-xl rounded-2xl border border-purple-500/30 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Cost Analysis</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Daily Cost</p>
            <p className="text-2xl font-bold text-white">${dailyCost.toFixed(2)}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Weekly Cost</p>
            <p className="text-2xl font-bold text-white">${(dailyCost * 7).toFixed(2)}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Monthly Cost</p>
            <p className="text-2xl font-bold text-white">${monthlyCost.toFixed(2)}</p>
          </div>
          <div className="text-center">
            <p className="text-gray-400 text-sm mb-1">Yearly Cost</p>
            <p className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              ${yearlyCost.toFixed(0)}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}