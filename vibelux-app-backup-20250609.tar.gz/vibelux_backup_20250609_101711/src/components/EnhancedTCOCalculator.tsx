"use client"
import { useState } from 'react'
import {
  Calculator,
  DollarSign,
  TrendingUp,
  Zap,
  Building,
  Calendar,
  BarChart3,
  Download,
  Lightbulb,
  Users,
  Package,
  FileText,
  ChevronRight,
  Info,
  Settings,
  PieChart
} from 'lucide-react'
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts'

interface CostCategory {
  id: string
  name: string
  icon: React.FC<any>
  color: string
}

interface CostItem {
  category: string
  item: string
  quantity: number
  unitCost: number
  totalCost: number
  lifespan: number
  annualMaintenance: number
  notes?: string
}

interface FacilityData {
  name: string
  size: number // sq ft
  rooms: number
  tiers: number
  canopyArea: number
  targetPPFD: number
  photoperiod: number
  daysPerYear: number
  cropCycles: number
  yieldPerSqFt: number
  pricePerPound: number
  utilityRate: number
}

const costCategories: CostCategory[] = [
  { id: 'lighting', name: 'Lighting Equipment', icon: Lightbulb, color: '#8b5cf6' },
  { id: 'infrastructure', name: 'Infrastructure', icon: Building, color: '#3b82f6' },
  { id: 'hvac', name: 'HVAC & Environment', icon: Zap, color: '#10b981' },
  { id: 'automation', name: 'Automation & Controls', icon: Settings, color: '#f59e0b' },
  { id: 'labor', name: 'Labor & Operations', icon: Users, color: '#ef4444' }
]

export function EnhancedTCOCalculator() {
  const [activeTab, setActiveTab] = useState<'setup' | 'capex' | 'opex' | 'analysis' | 'report'>('setup')
  const [facility, setFacility] = useState<FacilityData>({
    name: 'Vertical Farm Facility',
    size: 50000,
    rooms: 10,
    tiers: 5,
    canopyArea: 40000,
    targetPPFD: 300,
    photoperiod: 16,
    daysPerYear: 365,
    cropCycles: 12,
    yieldPerSqFt: 0.5,
    pricePerPound: 2000,
    utilityRate: 0.12
  })

  const [capexItems, setCapexItems] = useState<CostItem[]>([
    {
      category: 'lighting',
      item: 'LED Grow Lights (660W)',
      quantity: 500,
      unitCost: 1200,
      totalCost: 600000,
      lifespan: 10,
      annualMaintenance: 2
    },
    {
      category: 'infrastructure',
      item: 'Grow Racks & Tables',
      quantity: 200,
      unitCost: 2500,
      totalCost: 500000,
      lifespan: 15,
      annualMaintenance: 1
    },
    {
      category: 'hvac',
      item: 'HVAC System',
      quantity: 1,
      unitCost: 350000,
      totalCost: 350000,
      lifespan: 15,
      annualMaintenance: 5
    },
    {
      category: 'automation',
      item: 'Environmental Controls',
      quantity: 1,
      unitCost: 75000,
      totalCost: 75000,
      lifespan: 10,
      annualMaintenance: 3
    }
  ])

  const [opexItems, setOpexItems] = useState<{
    electricity: number
    water: number
    nutrients: number
    labor: number
    rent: number
    insurance: number
    other: number
  }>({
    electricity: 720000, // Annual
    water: 48000,
    nutrients: 120000,
    labor: 480000,
    rent: 600000,
    insurance: 36000,
    other: 60000
  })

  const calculateTotalCapex = () => {
    return capexItems.reduce((sum, item) => sum + item.totalCost, 0)
  }

  const calculateTotalOpex = () => {
    return Object.values(opexItems).reduce((sum, cost) => sum + cost, 0)
  }

  const calculateAnnualRevenue = () => {
    const annualYield = facility.canopyArea * facility.yieldPerSqFt * facility.cropCycles
    return annualYield * facility.pricePerPound
  }

  const calculateROI = () => {
    const annualRevenue = calculateAnnualRevenue()
    const annualOpex = calculateTotalOpex()
    const totalCapex = calculateTotalCapex()
    const annualProfit = annualRevenue - annualOpex
    return ((annualProfit / totalCapex) * 100).toFixed(1)
  }

  const calculatePayback = () => {
    const annualRevenue = calculateAnnualRevenue()
    const annualOpex = calculateTotalOpex()
    const totalCapex = calculateTotalCapex()
    const annualProfit = annualRevenue - annualOpex
    return (totalCapex / annualProfit).toFixed(1)
  }

  const generateCashFlow = () => {
    const years = 10
    const data = []
    const totalCapex = calculateTotalCapex()
    const annualRevenue = calculateAnnualRevenue()
    const annualOpex = calculateTotalOpex()
    
    for (let year = 0; year <= years; year++) {
      const revenue = year === 0 ? 0 : annualRevenue * (1 + 0.05) ** (year - 1) // 5% growth
      const opex = year === 0 ? 0 : annualOpex * (1 + 0.03) ** (year - 1) // 3% inflation
      const capex = year === 0 ? -totalCapex : 0
      const cashFlow = revenue - opex + capex
      const cumulativeCashFlow: number = data.length > 0 
        ? data[data.length - 1].cumulative + cashFlow
        : cashFlow
      
      data.push({
        year: `Year ${year}`,
        revenue,
        opex: -opex,
        capex,
        cashFlow,
        cumulative: cumulativeCashFlow
      })
    }
    
    return data
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-100 mb-2">
          Total Cost of Ownership Calculator
        </h1>
        <p className="text-gray-400">
          Comprehensive business case analysis for vertical farming operations
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 mb-8 border-b border-gray-200 dark:border-gray-700">
        {[
          { id: 'setup', label: 'Facility Setup', icon: Building },
          { id: 'capex', label: 'Capital Expenses', icon: Package },
          { id: 'opex', label: 'Operating Expenses', icon: DollarSign },
          { id: 'analysis', label: 'Financial Analysis', icon: BarChart3 },
          { id: 'report', label: 'Executive Report', icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 font-medium transition-all ${
                activeTab === tab.id
                  ? 'text-purple-600 border-b-2 border-purple-600'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          )
        })}
      </div>

      {/* Content Sections */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        {activeTab === 'setup' && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-100 mb-4">
              Facility Configuration
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Facility Name</label>
                <input
                  type="text"
                  value={facility.name}
                  onChange={(e) => setFacility({...facility, name: e.target.value})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Total Size (sq ft)</label>
                <input
                  type="number"
                  value={facility.size}
                  onChange={(e) => setFacility({...facility, size: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Number of Grow Rooms</label>
                <input
                  type="number"
                  value={facility.rooms}
                  onChange={(e) => setFacility({...facility, rooms: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Vertical Tiers</label>
                <input
                  type="number"
                  value={facility.tiers}
                  onChange={(e) => setFacility({...facility, tiers: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Total Canopy Area (sq ft)</label>
                <input
                  type="number"
                  value={facility.canopyArea}
                  onChange={(e) => setFacility({...facility, canopyArea: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Target PPFD (μmol/m²/s)</label>
                <input
                  type="number"
                  value={facility.targetPPFD}
                  onChange={(e) => setFacility({...facility, targetPPFD: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Photoperiod (hours)</label>
                <input
                  type="number"
                  value={facility.photoperiod}
                  onChange={(e) => setFacility({...facility, photoperiod: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Crop Cycles per Year</label>
                <input
                  type="number"
                  value={facility.cropCycles}
                  onChange={(e) => setFacility({...facility, cropCycles: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Yield per sq ft per Cycle (lbs)</label>
                <input
                  type="number"
                  step="0.1"
                  value={facility.yieldPerSqFt}
                  onChange={(e) => setFacility({...facility, yieldPerSqFt: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Average Price per Pound ($)</label>
                <input
                  type="number"
                  value={facility.pricePerPound}
                  onChange={(e) => setFacility({...facility, pricePerPound: Number(e.target.value)})}
                  className="w-full px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                />
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <h3 className="font-medium text-purple-900 dark:text-purple-100 mb-2">Quick Metrics</h3>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-purple-700 dark:text-purple-300">Annual Production</p>
                  <p className="text-xl font-semibold text-purple-900 dark:text-purple-100">
                    {(facility.canopyArea * facility.yieldPerSqFt * facility.cropCycles).toLocaleString()} lbs
                  </p>
                </div>
                <div>
                  <p className="text-purple-700 dark:text-purple-300">Canopy per Room</p>
                  <p className="text-xl font-semibold text-purple-900 dark:text-purple-100">
                    {Math.round(facility.canopyArea / facility.rooms).toLocaleString()} sq ft
                  </p>
                </div>
                <div>
                  <p className="text-purple-700 dark:text-purple-300">Revenue Potential</p>
                  <p className="text-xl font-semibold text-purple-900 dark:text-purple-100">
                    ${(calculateAnnualRevenue() / 1000000).toFixed(1)}M
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'capex' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-100">
                Capital Expenditures
              </h2>
              <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                Add Item
              </button>
            </div>
            
            <div className="space-y-4">
              {costCategories.map(category => {
                const categoryItems = capexItems.filter(item => item.category === category.id)
                const Icon = category.icon
                
                return (
                  <div key={category.id} className="border rounded-lg p-4 dark:border-gray-700">
                    <div className="flex items-center gap-2 mb-3">
                      <Icon className="w-5 h-5" style={{ color: category.color }} />
                      <h3 className="font-medium text-gray-100">{category.name}</h3>
                      <span className="ml-auto text-sm font-medium text-gray-400">
                        ${categoryItems.reduce((sum, item) => sum + item.totalCost, 0).toLocaleString()}
                      </span>
                    </div>
                    
                    {categoryItems.map((item, index) => (
                      <div key={index} className="flex items-center justify-between py-2 px-3 bg-gray-50 dark:bg-gray-700/50 rounded mb-2">
                        <div className="flex-1">
                          <p className="font-medium text-gray-100">{item.item}</p>
                          <p className="text-sm text-gray-400">
                            {item.quantity} units × ${item.unitCost.toLocaleString()} = ${item.totalCost.toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-400">
                            {item.lifespan} yr lifespan
                          </p>
                          <p className="text-sm text-gray-400">
                            {item.annualMaintenance}% maintenance
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )
              })}
            </div>
            
            <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-purple-900 dark:text-purple-100">
                  Total Capital Investment
                </h3>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  ${calculateTotalCapex().toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'opex' && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-100 mb-4">
              Annual Operating Expenses
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-medium text-gray-100">Utilities</h3>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Electricity (Annual)</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.electricity}
                      onChange={(e) => setOpexItems({...opexItems, electricity: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Estimated: {Math.round(facility.canopyArea * 50 * facility.photoperiod * 365 * facility.utilityRate / 1000).toLocaleString()} kWh/year
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Water & Wastewater</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.water}
                      onChange={(e) => setOpexItems({...opexItems, water: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-medium text-gray-100">Operations</h3>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Labor Costs</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.labor}
                      onChange={(e) => setOpexItems({...opexItems, labor: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Estimated: {Math.round(facility.canopyArea / 5000)} FTEs @ $60k/year
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Nutrients & Supplies</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.nutrients}
                      onChange={(e) => setOpexItems({...opexItems, nutrients: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-medium text-gray-100">Facility</h3>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Rent/Lease</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.rent}
                      onChange={(e) => setOpexItems({...opexItems, rent: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    ${(opexItems.rent / facility.size).toFixed(2)}/sq ft/year
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Insurance</label>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600 dark:text-gray-400">$</span>
                    <input
                      type="number"
                      value={opexItems.insurance}
                      onChange={(e) => setOpexItems({...opexItems, insurance: Number(e.target.value)})}
                      className="flex-1 px-3 py-2 border rounded-lg bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Other Operating Expenses</label>
                <div className="flex items-center gap-2">
                  <span className="text-gray-600 dark:text-gray-400">$</span>
                  <input
                    type="number"
                    value={opexItems.other}
                    onChange={(e) => setOpexItems({...opexItems, other: Number(e.target.value)})}
                    className="flex-1 px-3 py-2 border rounded-lg dark:bg-gray-700 dark:border-gray-600"
                  />
                </div>
              </div>
            </div>
            
            {/* OPEX Breakdown Chart */}
            <div className="mt-8">
              <h3 className="font-medium text-gray-100 mb-4">Operating Expense Breakdown</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={[
                        { name: 'Electricity', value: opexItems.electricity, color: '#8b5cf6' },
                        { name: 'Labor', value: opexItems.labor, color: '#3b82f6' },
                        { name: 'Rent', value: opexItems.rent, color: '#10b981' },
                        { name: 'Nutrients', value: opexItems.nutrients, color: '#f59e0b' },
                        { name: 'Water', value: opexItems.water, color: '#06b6d4' },
                        { name: 'Insurance', value: opexItems.insurance, color: '#ec4899' },
                        { name: 'Other', value: opexItems.other, color: '#6b7280' }
                      ]}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {[0,1,2,3,4,5,6].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#06b6d4', '#ec4899', '#6b7280'][index]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} contentStyle={{ backgroundColor: '#374151', border: 'none', borderRadius: '0.375rem' }} itemStyle={{ color: '#e5e7eb' }} labelStyle={{ color: '#e5e7eb' }} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-purple-900 dark:text-purple-100">
                  Total Annual Operating Expenses
                </h3>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  ${calculateTotalOpex().toLocaleString()}
                </p>
              </div>
              <p className="text-sm text-purple-700 dark:text-purple-300 mt-2">
                ${(calculateTotalOpex() / facility.canopyArea).toFixed(2)} per sq ft of canopy
              </p>
            </div>
          </div>
        )}

        {activeTab === 'analysis' && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-100 mb-4">
              Financial Analysis
            </h2>
            
            {/* Key Metrics */}
            <div className="grid md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-lg p-4">
                <p className="text-sm text-purple-700 dark:text-purple-300">ROI</p>
                <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                  {calculateROI()}%
                </p>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg p-4">
                <p className="text-sm text-green-700 dark:text-green-300">Payback Period</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                  {calculatePayback()} years
                </p>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-4">
                <p className="text-sm text-blue-700 dark:text-blue-300">Annual Revenue</p>
                <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                  ${(calculateAnnualRevenue() / 1000000).toFixed(1)}M
                </p>
              </div>
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-lg p-4">
                <p className="text-sm text-orange-700 dark:text-orange-300">Gross Margin</p>
                <p className="text-2xl font-bold text-orange-900 dark:text-orange-100">
                  {((1 - calculateTotalOpex() / calculateAnnualRevenue()) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
            
            {/* Cash Flow Chart */}
            <div className="mt-8">
              <h3 className="font-medium text-gray-100 mb-4">10-Year Cash Flow Projection</h3>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={generateCashFlow()}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="year" stroke="#9ca3af" />
                    <YAxis tickFormatter={(value) => `$${(value / 1000000).toFixed(1)}M`} stroke="#9ca3af" />
                    <Tooltip formatter={(value: number) => `$${(value / 1000).toFixed(0)}k`} contentStyle={{ backgroundColor: '#374151', border: 'none', borderRadius: '0.375rem' }} itemStyle={{ color: '#e5e7eb' }} labelStyle={{ color: '#e5e7eb' }} />
                    <Legend />
                    <Area type="monotone" dataKey="revenue" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="opex" stackId="1" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="capex" stackId="1" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.6} />
                    <Line type="monotone" dataKey="cumulative" stroke="#8b5cf6" strokeWidth={3} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            {/* Sensitivity Analysis */}
            <div className="mt-8">
              <h3 className="font-medium text-gray-100 mb-4">Sensitivity Analysis</h3>
              <div className="space-y-3">
                {[
                  { factor: 'Yield per sq ft', current: facility.yieldPerSqFt, impact: 'high' },
                  { factor: 'Price per pound', current: facility.pricePerPound, impact: 'high' },
                  { factor: 'Electricity cost', current: opexItems.electricity, impact: 'medium' },
                  { factor: 'Labor cost', current: opexItems.labor, impact: 'medium' }
                ].map((item) => (
                  <div key={item.factor} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-100">{item.factor}</p>
                      <p className="text-sm text-gray-400">
                        Current: ${typeof item.current === 'number' && item.current > 100 ? item.current.toLocaleString() : item.current}
                      </p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      item.impact === 'high' 
                        ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                        : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300'
                    }`}>
                      {item.impact === 'high' ? 'High Impact' : 'Medium Impact'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'report' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-100">
                Executive Summary Report
              </h2>
              <button className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            </div>
            
            <div className="prose prose-gray dark:prose-invert max-w-none">
              <h3>Investment Overview</h3>
              <p>
                The proposed {facility.name} represents a total capital investment of ${calculateTotalCapex().toLocaleString()} 
                with projected annual revenues of ${calculateAnnualRevenue().toLocaleString()}. Based on our analysis, 
                this investment will achieve a {calculateROI()}% ROI with a payback period of {calculatePayback()} years.
              </p>
              
              <h3>Facility Specifications</h3>
              <ul>
                <li>Total Facility Size: {facility.size.toLocaleString()} sq ft</li>
                <li>Canopy Area: {facility.canopyArea.toLocaleString()} sq ft</li>
                <li>Number of Grow Rooms: {facility.rooms}</li>
                <li>Vertical Tiers: {facility.tiers}</li>
                <li>Annual Production Capacity: {(facility.canopyArea * facility.yieldPerSqFt * facility.cropCycles).toLocaleString()} lbs</li>
              </ul>
              
              <h3>Financial Projections</h3>
              <p>
                With a gross margin of {((1 - calculateTotalOpex() / calculateAnnualRevenue()) * 100).toFixed(1)}%, 
                the facility is projected to generate positive cash flow by year {Math.ceil(Number(calculatePayback()))}. 
                The 10-year NPV is estimated at ${(calculateAnnualRevenue() * 10 - calculateTotalOpex() * 10 - calculateTotalCapex()).toLocaleString()}.
              </p>
              
              <h3>Risk Analysis</h3>
              <p>
                Key risk factors include market price volatility, yield consistency, and energy cost fluctuations. 
                Our sensitivity analysis indicates that a 10% reduction in yield or market price would extend the 
                payback period by approximately 1-2 years.
              </p>
              
              <h3>Recommendations</h3>
              <ol>
                <li>Implement phased construction to reduce initial capital requirements</li>
                <li>Secure long-term energy contracts to stabilize operating costs</li>
                <li>Establish offtake agreements to ensure stable revenue streams</li>
                <li>Invest in automation to reduce labor costs over time</li>
              </ol>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}