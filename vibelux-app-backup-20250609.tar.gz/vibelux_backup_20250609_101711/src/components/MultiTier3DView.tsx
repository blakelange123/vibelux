'use client';

import { useEffect, useRef, useState } from 'react';
import { 
  RotateCcw, 
  ZoomIn, 
  ZoomOut, 
  Move, 
  Eye, 
  EyeOff,
  Layers,
  Lightbulb,
  Settings,
  X
} from 'lucide-react';

interface Tier {
  id: string;
  name: string;
  height: number; // feet
  benchDepth: number; // feet
  canopyHeight: number; // inches
  targetPPFD: number;
  cropType: string;
  enabled: boolean;
  visible: boolean;
  color: string;
  plantDensity: number;
  growthStage: 'seedling' | 'vegetative' | 'flowering' | 'fruiting';
}

interface Fixture {
  id: string;
  x: number; // percentage
  y: number; // percentage
  z: number; // feet
  ppf: number;
  beamAngle: number;
  enabled: boolean;
  assignedTiers?: string[];
}

interface MultiTier3DViewProps {
  tiers: Tier[];
  fixtures: Fixture[];
  roomDimensions: { width: number; height: number; depth: number };
  onClose?: () => void;
  showLightBeams?: boolean;
  showShadows?: boolean;
}

export function MultiTier3DView({
  tiers,
  fixtures,
  roomDimensions,
  onClose,
  showLightBeams = true,
  showShadows = true
}: MultiTier3DViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [rotation, setRotation] = useState({ x: -20, y: 45 });
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [lastMouse, setLastMouse] = useState({ x: 0, y: 0 });
  const [viewSettings, setViewSettings] = useState({
    showTiers: true,
    showFixtures: true,
    showLightBeams,
    showShadows,
    showGrid: true,
    wireframe: false
  });

  // 3D projection functions
  const project3D = (x: number, y: number, z: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const centerX = canvas.width / 2 + pan.x;
    const centerY = canvas.height / 2 + pan.y;
    
    // Apply rotation
    const radX = (rotation.x * Math.PI) / 180;
    const radY = (rotation.y * Math.PI) / 180;
    
    // Rotate around Y axis first, then X axis
    const cosY = Math.cos(radY);
    const sinY = Math.sin(radY);
    const cosX = Math.cos(radX);
    const sinX = Math.sin(radX);
    
    const x1 = x * cosY - z * sinY;
    const z1 = x * sinY + z * cosY;
    
    const y1 = y * cosX - z1 * sinX;
    const z2 = y * sinX + z1 * cosX;
    
    // Apply zoom and perspective
    const scale = zoom * 20;
    const perspective = 200 / (200 + z2);
    
    return {
      x: centerX + x1 * scale * perspective,
      y: centerY - y1 * scale * perspective // Negative for screen coordinates
    };
  };

  const drawRoom = (ctx: CanvasRenderingContext2D) => {
    const { width, height, depth } = roomDimensions;
    
    // Draw room outline
    ctx.strokeStyle = '#4B5563';
    ctx.lineWidth = 2;
    
    // Floor corners
    const floorCorners = [
      project3D(-width/2, -depth, -height/2),
      project3D(width/2, -depth, -height/2),
      project3D(width/2, -depth, height/2),
      project3D(-width/2, -depth, height/2)
    ];
    
    // Ceiling corners
    const ceilingCorners = [
      project3D(-width/2, 0, -height/2),
      project3D(width/2, 0, -height/2),
      project3D(width/2, 0, height/2),
      project3D(-width/2, 0, height/2)
    ];
    
    // Draw floor
    ctx.beginPath();
    ctx.moveTo(floorCorners[0].x, floorCorners[0].y);
    floorCorners.forEach(corner => ctx.lineTo(corner.x, corner.y));
    ctx.closePath();
    ctx.fillStyle = '#1F2937';
    ctx.fill();
    ctx.stroke();
    
    // Draw ceiling
    ctx.beginPath();
    ctx.moveTo(ceilingCorners[0].x, ceilingCorners[0].y);
    ceilingCorners.forEach(corner => ctx.lineTo(corner.x, corner.y));
    ctx.closePath();
    ctx.fillStyle = '#374151';
    ctx.fill();
    ctx.stroke();
    
    // Draw vertical edges
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(floorCorners[i].x, floorCorners[i].y);
      ctx.lineTo(ceilingCorners[i].x, ceilingCorners[i].y);
      ctx.stroke();
    }
    
    // Draw grid on floor if enabled
    if (viewSettings.showGrid) {
      ctx.strokeStyle = '#374151';
      ctx.lineWidth = 1;
      
      for (let x = -width/2; x <= width/2; x += 1) {
        const start = project3D(x, -depth, -height/2);
        const end = project3D(x, -depth, height/2);
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
      }
      
      for (let z = -height/2; z <= height/2; z += 1) {
        const start = project3D(-width/2, -depth, z);
        const end = project3D(width/2, -depth, z);
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
      }
    }
  };

  const drawTier = (ctx: CanvasRenderingContext2D, tier: Tier) => {
    if (!tier.visible || !viewSettings.showTiers) return;
    
    const { width } = roomDimensions;
    const tierHeightFeet = tier.height / 12; // Convert inches to feet
    const canopyHeightFeet = tier.canopyHeight / 12;
    
    // Bench surface
    const benchCorners = [
      project3D(-width/2, -tierHeightFeet, -tier.benchDepth/2),
      project3D(width/2, -tierHeightFeet, -tier.benchDepth/2),
      project3D(width/2, -tierHeightFeet, tier.benchDepth/2),
      project3D(-width/2, -tierHeightFeet, tier.benchDepth/2)
    ];
    
    // Draw bench surface
    ctx.beginPath();
    ctx.moveTo(benchCorners[0].x, benchCorners[0].y);
    benchCorners.forEach(corner => ctx.lineTo(corner.x, corner.y));
    ctx.closePath();
    
    if (viewSettings.wireframe) {
      ctx.strokeStyle = tier.color;
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.fillStyle = tier.color + '40'; // Semi-transparent
      ctx.fill();
      ctx.strokeStyle = tier.color;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    
    // Draw canopy area
    if (canopyHeightFeet > 0) {
      const canopyTopCorners = [
        project3D(-width/2, -(tierHeightFeet + canopyHeightFeet), -tier.benchDepth/2),
        project3D(width/2, -(tierHeightFeet + canopyHeightFeet), -tier.benchDepth/2),
        project3D(width/2, -(tierHeightFeet + canopyHeightFeet), tier.benchDepth/2),
        project3D(-width/2, -(tierHeightFeet + canopyHeightFeet), tier.benchDepth/2)
      ];
      
      // Draw canopy top
      ctx.beginPath();
      ctx.moveTo(canopyTopCorners[0].x, canopyTopCorners[0].y);
      canopyTopCorners.forEach(corner => ctx.lineTo(corner.x, corner.y));
      ctx.closePath();
      ctx.fillStyle = tier.color + '20';
      ctx.fill();
      ctx.strokeStyle = tier.color + '80';
      ctx.setLineDash([5, 5]);
      ctx.stroke();
      ctx.setLineDash([]);
      
      // Draw vertical canopy edges
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(benchCorners[i].x, benchCorners[i].y);
        ctx.lineTo(canopyTopCorners[i].x, canopyTopCorners[i].y);
        ctx.strokeStyle = tier.color + '60';
        ctx.setLineDash([3, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
    
    // Draw tier label
    const labelPos = project3D(width/2 + 0.5, -tierHeightFeet, 0);
    ctx.fillStyle = tier.color;
    ctx.font = '12px sans-serif';
    ctx.fillText(tier.name, labelPos.x, labelPos.y);
    
    // Draw tier details
    ctx.fillStyle = '#9CA3AF';
    ctx.font = '10px sans-serif';
    ctx.fillText(
      `${tier.cropType} • ${tier.targetPPFD} PPFD`,
      labelPos.x,
      labelPos.y + 15
    );
  };

  const drawFixture = (ctx: CanvasRenderingContext2D, fixture: Fixture) => {
    if (!fixture.enabled || !viewSettings.showFixtures) return;
    
    const { width, height } = roomDimensions;
    const x = (fixture.x / 100 - 0.5) * width;
    const z = (fixture.y / 100 - 0.5) * height;
    const y = -fixture.z;
    
    const pos = project3D(x, y, z);
    
    // Draw fixture housing
    const fixtureSize = 6;
    ctx.fillStyle = fixture.enabled ? '#FED570' : '#6B7280';
    ctx.fillRect(
      pos.x - fixtureSize/2,
      pos.y - fixtureSize/2,
      fixtureSize,
      fixtureSize
    );
    
    // Draw fixture outline
    ctx.strokeStyle = fixture.enabled ? '#F59E0B' : '#4B5563';
    ctx.lineWidth = 1;
    ctx.strokeRect(
      pos.x - fixtureSize/2,
      pos.y - fixtureSize/2,
      fixtureSize,
      fixtureSize
    );
    
    // Draw light beams
    if (viewSettings.showLightBeams && fixture.enabled) {
      const beamRadius = Math.tan((fixture.beamAngle * Math.PI / 180) / 2) * fixture.z;
      
      // Draw beam to each tier
      tiers.forEach(tier => {
        if (!tier.visible || !tier.enabled) return;
        
        const tierY = -(tier.height / 12);
        const beamRadiusAtTier = Math.tan((fixture.beamAngle * Math.PI / 180) / 2) * (fixture.z - tier.height / 12);
        
        if (beamRadiusAtTier > 0) {
          // Draw beam cone outline
          const numPoints = 8;
          ctx.strokeStyle = '#FED570' + '40';
          ctx.lineWidth = 1;
          
          for (let i = 0; i < numPoints; i++) {
            const angle = (i / numPoints) * 2 * Math.PI;
            const beamX = x + Math.cos(angle) * beamRadiusAtTier;
            const beamZ = z + Math.sin(angle) * beamRadiusAtTier;
            
            const beamStart = project3D(x, y, z);
            const beamEnd = project3D(beamX, tierY, beamZ);
            
            ctx.beginPath();
            ctx.moveTo(beamStart.x, beamStart.y);
            ctx.lineTo(beamEnd.x, beamEnd.y);
            ctx.stroke();
          }
          
          // Draw beam circle on tier
          ctx.strokeStyle = tier.color;
          ctx.lineWidth = 2;
          ctx.setLineDash([2, 2]);
          
          const centerAtTier = project3D(x, tierY, z);
          const radiusAtTier = beamRadiusAtTier * 20 * zoom; // Approximate screen radius
          
          ctx.beginPath();
          ctx.arc(centerAtTier.x, centerAtTier.y, radiusAtTier, 0, 2 * Math.PI);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      });
    }
    
    // Draw fixture info
    ctx.fillStyle = '#F3F4F6';
    ctx.font = '10px sans-serif';
    ctx.fillText(
      `${fixture.ppf} PPF`,
      pos.x + fixtureSize/2 + 5,
      pos.y + 3
    );
  };

  const drawShadows = (ctx: CanvasRenderingContext2D) => {
    if (!viewSettings.showShadows) return;
    
    // Draw simplified shadow projections
    const sortedTiers = [...tiers].sort((a, b) => b.height - a.height);
    
    for (let i = 0; i < sortedTiers.length - 1; i++) {
      const upperTier = sortedTiers[i];
      const lowerTier = sortedTiers[i + 1];
      
      if (!upperTier.visible || !lowerTier.visible) continue;
      
      // Project shadow from upper tier onto lower tier
      const shadowOffset = (upperTier.height - lowerTier.height) * 0.1; // Simplified shadow calculation
      
      const { width } = roomDimensions;
      const lowerTierY = -(lowerTier.height / 12);
      
      const shadowCorners = [
        project3D(-width/2 + shadowOffset, lowerTierY, -lowerTier.benchDepth/2 + shadowOffset),
        project3D(width/2 + shadowOffset, lowerTierY, -lowerTier.benchDepth/2 + shadowOffset),
        project3D(width/2 + shadowOffset, lowerTierY, lowerTier.benchDepth/2 + shadowOffset),
        project3D(-width/2 + shadowOffset, lowerTierY, lowerTier.benchDepth/2 + shadowOffset)
      ];
      
      ctx.beginPath();
      ctx.moveTo(shadowCorners[0].x, shadowCorners[0].y);
      shadowCorners.forEach(corner => ctx.lineTo(corner.x, corner.y));
      ctx.closePath();
      
      ctx.fillStyle = '#00000020';
      ctx.fill();
    }
  };

  const draw = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    // Draw room
    drawRoom(ctx);
    
    // Draw shadows first (behind everything)
    drawShadows(ctx);
    
    // Draw tiers (bottom to top for proper layering)
    const sortedTiers = [...tiers].sort((a, b) => a.height - b.height);
    sortedTiers.forEach(tier => drawTier(ctx, tier));
    
    // Draw fixtures last (on top)
    fixtures.forEach(fixture => drawFixture(ctx, fixture));
  };

  // Mouse event handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    
    const deltaX = e.clientX - lastMouse.x;
    const deltaY = e.clientY - lastMouse.y;
    
    if (e.shiftKey) {
      // Pan
      setPan(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
    } else {
      // Rotate
      setRotation(prev => ({
        x: Math.max(-90, Math.min(90, prev.x + deltaY * 0.5)),
        y: (prev.y + deltaX * 0.5) % 360
      }));
    }
    
    setLastMouse({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(prev => Math.max(0.1, Math.min(5, prev * zoomFactor)));
  };

  // Reset view
  const resetView = () => {
    setRotation({ x: -20, y: 45 });
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Redraw when state changes
  useEffect(() => {
    draw();
  }, [tiers, fixtures, rotation, zoom, pan, viewSettings]);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-gray-900 rounded-xl p-4 max-w-6xl w-full mx-4 h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Layers className="w-6 h-6 text-purple-400" />
            <div>
              <h2 className="text-xl font-semibold text-white">3D Multi-Tier Visualization</h2>
              <p className="text-sm text-gray-400">
                {tiers.length} tiers • {fixtures.length} fixtures
              </p>
            </div>
          </div>
          
          {/* View Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewSettings(prev => ({ ...prev, showTiers: !prev.showTiers }))}
              className={`p-2 rounded ${viewSettings.showTiers ? 'bg-purple-600' : 'bg-gray-700'} hover:bg-purple-700`}
              title="Toggle Tiers"
            >
              <Layers className="w-4 h-4 text-white" />
            </button>
            
            <button
              onClick={() => setViewSettings(prev => ({ ...prev, showFixtures: !prev.showFixtures }))}
              className={`p-2 rounded ${viewSettings.showFixtures ? 'bg-yellow-600' : 'bg-gray-700'} hover:bg-yellow-700`}
              title="Toggle Fixtures"
            >
              <Lightbulb className="w-4 h-4 text-white" />
            </button>
            
            <button
              onClick={() => setViewSettings(prev => ({ ...prev, showLightBeams: !prev.showLightBeams }))}
              className={`p-2 rounded ${viewSettings.showLightBeams ? 'bg-orange-600' : 'bg-gray-700'} hover:bg-orange-700`}
              title="Toggle Light Beams"
            >
              <Eye className="w-4 h-4 text-white" />
            </button>
            
            <button
              onClick={() => setViewSettings(prev => ({ ...prev, wireframe: !prev.wireframe }))}
              className={`p-2 rounded ${viewSettings.wireframe ? 'bg-blue-600' : 'bg-gray-700'} hover:bg-blue-700`}
              title="Toggle Wireframe"
            >
              <Settings className="w-4 h-4 text-white" />
            </button>
            
            <div className="w-px h-6 bg-gray-600" />
            
            <button
              onClick={() => setZoom(prev => prev * 1.2)}
              className="p-2 bg-gray-700 hover:bg-gray-600 rounded"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4 text-white" />
            </button>
            
            <button
              onClick={() => setZoom(prev => prev * 0.8)}
              className="p-2 bg-gray-700 hover:bg-gray-600 rounded"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4 text-white" />
            </button>
            
            <button
              onClick={resetView}
              className="p-2 bg-gray-700 hover:bg-gray-600 rounded"
              title="Reset View"
            >
              <RotateCcw className="w-4 h-4 text-white" />
            </button>
            
            {onClose && (
              <button
                onClick={onClose}
                className="p-2 bg-gray-700 hover:bg-gray-600 rounded"
                title="Close"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            )}
          </div>
        </div>
        
        {/* Canvas */}
        <div className="flex-1 relative">
          <canvas
            ref={canvasRef}
            className="w-full h-full bg-gray-950 rounded-lg cursor-grab active:cursor-grabbing"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onWheel={handleWheel}
          />
          
          {/* Instructions */}
          <div className="absolute bottom-4 left-4 bg-gray-800/90 backdrop-blur rounded-lg p-3">
            <p className="text-xs text-gray-300">Drag to rotate • Shift+drag to pan • Scroll to zoom</p>
            <p className="text-xs text-gray-400 mt-1">
              Zoom: {(zoom * 100).toFixed(0)}% • Rotation: {rotation.y.toFixed(0)}°
            </p>
          </div>
          
          {/* Legend */}
          <div className="absolute top-4 right-4 bg-gray-800/90 backdrop-blur rounded-lg p-3 space-y-2">
            <h4 className="text-sm font-medium text-white">Legend</h4>
            <div className="space-y-1 text-xs">
              {tiers.map(tier => (
                <div key={tier.id} className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded" 
                    style={{ backgroundColor: tier.color }}
                  />
                  <span className="text-gray-300">{tier.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MultiTier3DView;