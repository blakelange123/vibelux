"use client"

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  Home, 
  Lightbulb, 
  Calculator, 
  Maximize2,
  BarChart3,
  Activity,
  Calendar,
  Settings,
  FileText,
  Package,
  Languages,
  Accessibility,
  Link2,
  Code,
  Wrench,
  Cloud,
  WifiOff,
  Smartphone,
  ChevronDown,
  ChevronRight,
  Brain,
  PieChart,
  Camera,
  Leaf,
  Wifi,
  DollarSign,
  MessageSquare,
  Beaker,
  Sliders,
  Sun,
  Download,
  Building2,
  Shield,
  Wind,
  Grid3x3,
  TrendingUp,
  Thermometer,
  Layers,
  Droplets
} from 'lucide-react'
import { UserButton } from '@clerk/nextjs'
import { X } from 'lucide-react'

const navItems = [
  { href: '/', icon: Home, label: 'Home' },
  { href: '/dashboard', icon: BarChart3, label: 'Dashboard' },
  { href: '/fixtures', icon: Lightbulb, label: 'Fixtures' },
  { href: '/design', icon: Maximize2, label: 'Design Studio' },
  { href: '/design/advanced-v3', icon: Maximize2, label: 'Advanced Design' },
  { href: '/spectrum', icon: Activity, label: 'Spectrum' },
  { href: '/schedule', icon: Calendar, label: 'Schedule' },
  { href: '/analytics', icon: BarChart3, label: 'Analytics' },
  { href: '/predictions', icon: Brain, label: 'ML Predictions' },
  { href: '/reports', icon: PieChart, label: 'Report Builder' },
  { href: '/carbon-credits', icon: Leaf, label: 'Carbon Credits' },
  { href: '/iot-devices', icon: Wifi, label: 'IoT Devices' },
  { href: '/equipment-leasing', icon: DollarSign, label: 'Leasing Calculator' },
  { href: '/community-forum', icon: MessageSquare, label: 'Community Forum' },
  { href: '/light-recipes', icon: Sun, label: 'Light Recipes' },
  { href: '/photosynthetic-calculator', icon: Beaker, label: 'YPF Calculator' },
  { href: '/spectrum-builder', icon: Sliders, label: 'Spectrum Builder' },
  { href: '/maintenance-tracker', icon: Wrench, label: 'Maintenance' },
  { href: '/export-center', icon: Download, label: 'Export Center' },
  { href: '/greenhouse-integration', icon: Link2, label: 'Integrations' },
  { href: '/yield-prediction', icon: Brain, label: 'Yield ML' },
  { href: '/tco-calculator', icon: Calculator, label: 'TCO Analysis' },
  { href: '/rebate-calculator', icon: DollarSign, label: 'Rebates' },
  { href: '/multi-site', icon: Building2, label: 'Multi-Site' },
  { href: '/nutrient-dosing', icon: Beaker, label: 'Nutrient Dosing' },
  { href: '/dlc-compliance', icon: Shield, label: 'DLC Compliance' },
  { href: '/weather-adaptive', icon: Cloud, label: 'Weather Adaptive' },
]

const featureItems = [
  { href: '/features', icon: FileText, label: 'Feature Requests' },
  { href: '/templates', icon: Package, label: 'Templates' },
  { href: '/batch', icon: Package, label: 'Batch Operations' },
]

const settingsItems = [
  { href: '/settings', icon: Settings, label: 'Import/Export' },
  { href: '/language', icon: Languages, label: 'Language' },
  { href: '/accessibility', icon: Accessibility, label: 'Accessibility' },
  { href: '/integrations', icon: Link2, label: 'Integrations' },
  { href: '/sync', icon: Cloud, label: 'Mobile Sync' },
  { href: '/offline', icon: WifiOff, label: 'Offline Mode' },
  { href: '/pwa', icon: Smartphone, label: 'PWA Settings' },
]

const devItems = [
  { href: '/api-docs', icon: Code, label: 'API Docs' },
  { href: '/dev-tools', icon: Wrench, label: 'Dev Tools' },
]

const calculatorItems = [
  { href: '/calculators', icon: Calculator, label: 'All Calculators' },
  { href: '/calculators/co2-enrichment', icon: Wind, label: 'CO₂ Enrichment' },
  { href: '/calculators/coverage-area', icon: Grid3x3, label: 'Coverage Area' },
  { href: '/calculators/roi', icon: TrendingUp, label: 'ROI Calculator' },
  { href: '/tco-calculator', icon: BarChart3, label: 'TCO Analysis' },
  { href: '/calculators/heat-load', icon: Thermometer, label: 'Heat Load' },
  { href: '/photosynthetic-calculator', icon: Activity, label: 'YPF Calculator' },
  { href: '/nutrient-dosing', icon: Beaker, label: 'Nutrient Dosing' },
  { href: '/equipment-leasing', icon: DollarSign, label: 'Equipment Leasing' },
  { href: '/rebate-calculator', icon: Shield, label: 'Rebate Calculator' },
]

export default function Navigation({ onClose }: { onClose?: () => void }) {
  const pathname = usePathname()
  const [expandedSections, setExpandedSections] = useState({
    features: false,
    settings: false,
    dev: false,
    calculators: false
  })

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section as keyof typeof prev]
    }))
  }

  return (
    <nav className="h-full w-64 glass-dark border-r border-white/5">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-6 border-b border-white/5">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 btn-purple-gradient rounded-xl flex items-center justify-center shadow-purple-lg">
                <Lightbulb className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-purple-gradient">
                Vibelux
              </span>
            </Link>
            {onClose && (
              <button
                onClick={onClose}
                className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                aria-label="Close sidebar"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            )}
          </div>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 py-6 space-y-1 overflow-y-auto">
          {/* Main Navigation */}
          {navItems.map((item) => {
            const isActive = pathname === item.href || 
              (item.href !== '/' && pathname.startsWith(item.href))
            
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-6 py-3 transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600/20 to-purple-700/20 border-r-2 border-purple-500 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Link>
            )
          })}

          {/* Calculators Section */}
          <div className="mt-4">
            <button
              onClick={() => toggleSection('calculators')}
              className="w-full flex items-center justify-between px-6 py-3 text-gray-400 hover:text-white hover:bg-white/5"
            >
              <div className="flex items-center gap-3">
                <Calculator className="w-5 h-5" />
                <span>Calculators</span>
              </div>
              {expandedSections.calculators ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expandedSections.calculators && (
              <div className="space-y-1 mt-1">
                {calculatorItems.map((item) => {
                  const isActive = pathname === item.href || 
                    (item.href !== '/calculators' && pathname.startsWith(item.href))
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`flex items-center gap-3 pl-12 pr-6 py-2 transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-purple-600/20 to-purple-700/20 border-r-2 border-purple-500 text-white'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Features Section */}
          <div className="mt-4">
            <button
              onClick={() => toggleSection('features')}
              className="w-full flex items-center justify-between px-6 py-3 text-gray-400 hover:text-white hover:bg-white/5"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5" />
                <span>Features</span>
              </div>
              {expandedSections.features ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expandedSections.features && (
              <div className="space-y-1 mt-1">
                {featureItems.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`flex items-center gap-3 pl-12 pr-6 py-2 transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-purple-600/20 to-purple-700/20 border-r-2 border-purple-500 text-white'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Settings Section */}
          <div>
            <button
              onClick={() => toggleSection('settings')}
              className="w-full flex items-center justify-between px-6 py-3 text-gray-400 hover:text-white hover:bg-white/5"
            >
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </div>
              {expandedSections.settings ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expandedSections.settings && (
              <div className="space-y-1 mt-1">
                {settingsItems.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`flex items-center gap-3 pl-12 pr-6 py-2 transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-purple-600/20 to-purple-700/20 border-r-2 border-purple-500 text-white'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Developer Section */}
          <div>
            <button
              onClick={() => toggleSection('dev')}
              className="w-full flex items-center justify-between px-6 py-3 text-gray-400 hover:text-white hover:bg-white/5"
            >
              <div className="flex items-center gap-3">
                <Code className="w-5 h-5" />
                <span>Developer</span>
              </div>
              {expandedSections.dev ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expandedSections.dev && (
              <div className="space-y-1 mt-1">
                {devItems.map((item) => {
                  const isActive = pathname === item.href
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`flex items-center gap-3 pl-12 pr-6 py-2 transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-purple-600/20 to-purple-700/20 border-r-2 border-purple-500 text-white'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        </div>

        {/* User section */}
        <div className="p-6 border-t border-white/10">
          <div className="flex items-center gap-3">
            <UserButton afterSignOutUrl="/" />
            <div className="flex-1">
              <p className="text-sm text-white">Welcome back</p>
              <p className="text-xs text-gray-400">Free Plan</p>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}