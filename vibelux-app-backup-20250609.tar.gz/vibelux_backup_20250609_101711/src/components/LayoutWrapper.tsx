'use client';

import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Menu } from 'lucide-react';

export function LayoutWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Pages that should not show the sidebar
  const fullWidthPages = ['/sign-in', '/sign-up'];
  const isFullWidth = fullWidthPages.includes(pathname);

  const toggleSidebar = () => {
    console.log('Toggle sidebar function called!');
    setSidebarOpen(prev => {
      const newState = !prev;
      console.log('Sidebar state changing from', prev, 'to', newState);
      return newState;
    });
  };

  // Add keyboard shortcut - Try multiple keys
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Try Cmd/Ctrl + B (common for sidebar toggle)
      if ((e.metaKey || e.ctrlKey) && e.key === 'b') {
        e.preventDefault();
        console.log('Keyboard shortcut triggered!');
        toggleSidebar();
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  if (isFullWidth) {
    return <>{children}</>;
  }

  // Add visible toggle in top left that's always accessible
  return (
    <div className="relative min-h-screen">
      {/* Developer Sidebar */}
      <div className={`fixed left-0 top-0 h-full w-64 bg-gray-900 z-50 transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <Navigation onClose={toggleSidebar} />
      </div>
      
      {/* Main Content */}
      <div className={`min-h-screen transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
        {/* Show Menu Button when sidebar is closed */}
        {!sidebarOpen && (
          <button
            onClick={toggleSidebar}
            className="fixed top-4 left-4 p-2 bg-gray-800/80 backdrop-blur rounded-lg hover:bg-gray-700 transition-colors z-50"
            aria-label="Open sidebar"
          >
            <Menu className="w-5 h-5 text-white" />
          </button>
        )}
        
        <div className="px-6 pt-16">
          <Breadcrumbs />
        </div>
        {children}
      </div>
    </div>
  );
}