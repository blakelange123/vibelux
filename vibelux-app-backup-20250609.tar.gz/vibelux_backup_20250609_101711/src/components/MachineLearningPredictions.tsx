"use client"

import { useState, useEffect } from 'react'
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Calendar,
  Cpu,
  BarChart3,
  Activity,
  Target,
  Zap,
  Leaf,
  DollarSign,
  Clock,
  Info,
  CheckCircle,
  XCircle,
  RefreshCw,
  Download,
  Settings,
  Play,
  Pause
} from 'lucide-react'

interface Prediction {
  id: string
  type: 'yield' | 'energy' | 'maintenance' | 'disease' | 'optimization'
  title: string
  confidence: number
  timeframe: string
  value: string | number
  impact: 'high' | 'medium' | 'low'
  recommendations: string[]
  status: 'active' | 'pending' | 'completed'
}

interface Model {
  id: string
  name: string
  type: string
  accuracy: number
  lastTrained: Date
  dataPoints: number
  status: 'active' | 'training' | 'idle'
}

interface Anomaly {
  id: string
  type: string
  severity: 'critical' | 'warning' | 'info'
  detected: Date
  location: string
  description: string
  confidence: number
}

export function MachineLearningPredictions() {
  const [activeModel, setActiveModel] = useState<string>('yield-optimizer')
  const [isTraining, setIsTraining] = useState(false)
  const [selectedTimeframe, setSelectedTimeframe] = useState<'24h' | '7d' | '30d' | '90d'>('7d')
  const [autoPredict, setAutoPredict] = useState(true)
  const [trainingProgress, setTrainingProgress] = useState(0)

  const models: Model[] = [
    {
      id: 'yield-optimizer',
      name: 'Yield Optimization Model',
      type: 'Random Forest',
      accuracy: 94.7,
      lastTrained: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      dataPoints: 125430,
      status: 'active'
    },
    {
      id: 'energy-predictor',
      name: 'Energy Consumption Predictor',
      type: 'LSTM Neural Network',
      accuracy: 91.2,
      lastTrained: new Date(Date.now() - 1000 * 60 * 60 * 24),
      dataPoints: 89320,
      status: 'active'
    },
    {
      id: 'disease-detector',
      name: 'Disease Detection Model',
      type: 'CNN',
      accuracy: 96.8,
      lastTrained: new Date(Date.now() - 1000 * 60 * 60 * 12),
      dataPoints: 45670,
      status: 'training'
    },
    {
      id: 'maintenance-predictor',
      name: 'Predictive Maintenance',
      type: 'Gradient Boosting',
      accuracy: 89.5,
      lastTrained: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
      dataPoints: 67890,
      status: 'idle'
    }
  ]

  const predictions: Prediction[] = [
    {
      id: '1',
      type: 'yield',
      title: 'Yield Increase Opportunity',
      confidence: 92,
      timeframe: 'Next 14 days',
      value: '+12% yield',
      impact: 'high',
      recommendations: [
        'Increase PPFD to 450 µmol/m²/s in zones A3-A5',
        'Adjust photoperiod to 16/8 cycle',
        'Optimize spectrum with 15% more far-red'
      ],
      status: 'active'
    },
    {
      id: '2',
      type: 'energy',
      title: 'Energy Spike Predicted',
      confidence: 87,
      timeframe: 'Tomorrow 14:00-18:00',
      value: '+35% consumption',
      impact: 'medium',
      recommendations: [
        'Pre-cool facility before peak hours',
        'Reduce lighting intensity by 20% during peak',
        'Shift non-critical operations to off-peak'
      ],
      status: 'pending'
    },
    {
      id: '3',
      type: 'disease',
      title: 'Powdery Mildew Risk',
      confidence: 78,
      timeframe: 'Next 3-5 days',
      value: '32% probability',
      impact: 'high',
      recommendations: [
        'Reduce humidity to below 60%',
        'Increase air circulation in affected zones',
        'Prepare preventive treatment'
      ],
      status: 'active'
    },
    {
      id: '4',
      type: 'maintenance',
      title: 'LED Degradation Detected',
      confidence: 94,
      timeframe: 'Within 30 days',
      value: 'Fixture Group B-12',
      impact: 'medium',
      recommendations: [
        'Schedule replacement for fixtures B-12-01 to B-12-06',
        'Order replacement parts now to avoid downtime',
        'Consider upgrading to newer efficiency models'
      ],
      status: 'pending'
    }
  ]

  const anomalies: Anomaly[] = [
    {
      id: '1',
      type: 'Environmental',
      severity: 'warning',
      detected: new Date(Date.now() - 1000 * 60 * 30),
      location: 'Zone C3',
      description: 'Unusual temperature fluctuation pattern detected',
      confidence: 85
    },
    {
      id: '2',
      type: 'Growth Rate',
      severity: 'info',
      detected: new Date(Date.now() - 1000 * 60 * 60 * 2),
      location: 'Row 7-9',
      description: 'Growth rate 15% below model prediction',
      confidence: 72
    }
  ]

  // Simulate training progress
  useEffect(() => {
    if (isTraining) {
      const interval = setInterval(() => {
        setTrainingProgress(prev => {
          if (prev >= 100) {
            setIsTraining(false)
            return 0
          }
          return prev + 2
        })
      }, 100)
      return () => clearInterval(interval)
    }
  }, [isTraining])

  const startTraining = (modelId: string) => {
    setIsTraining(true)
    setTrainingProgress(0)
    console.log('Starting training for model:', modelId)
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-400 bg-red-500/20 border border-red-500/30'
      case 'medium': return 'text-yellow-400 bg-yellow-500/20 border border-yellow-500/30'
      case 'low': return 'text-green-400 bg-green-500/20 border border-green-500/30'
      default: return 'text-gray-400 bg-gray-700/50 border border-gray-700'
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return <XCircle className="w-5 h-5 text-red-400" />
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-400" />
      case 'info': return <Info className="w-5 h-5 text-blue-400" />
      default: return <Info className="w-5 h-5 text-gray-400" />
    }
  }

  const selectedModel = models.find(m => m.id === activeModel)

  return (
    <div className="space-y-4">

      {/* Main Container */}
      <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 shadow-xl p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold text-white">Machine Learning Control Center</h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-800/50 rounded-xl border border-gray-700">
              <label className="text-sm text-gray-400">Auto-predict</label>
              <input
                type="checkbox"
                checked={autoPredict}
                onChange={(e) => setAutoPredict(e.target.checked)}
                className="w-4 h-4 rounded bg-gray-700 border-gray-600 text-purple-600 focus:ring-purple-500"
              />
            </div>
            <button className="p-2 bg-gray-800/50 hover:bg-gray-800/70 rounded-xl border border-gray-700 transition-all">
              <Settings className="w-5 h-5 text-gray-400 hover:text-white" />
            </button>
          </div>
        </div>

        {/* Model Selector */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {models.map(model => (
            <div
              key={model.id}
              onClick={() => setActiveModel(model.id)}
              className={`relative group cursor-pointer transition-all duration-300 ${
                activeModel === model.id ? 'scale-[1.02]' : ''
              }`}
            >
              <div className={`absolute inset-0 rounded-2xl blur-xl transition-all duration-500 ${
                activeModel === model.id 
                  ? 'bg-gradient-to-br from-purple-600/30 to-pink-600/30 opacity-100' 
                  : 'bg-gradient-to-br from-purple-600/20 to-pink-600/20 opacity-0 group-hover:opacity-100'
              }`} />
              <div className={`relative bg-gray-900/60 backdrop-blur-xl rounded-2xl border p-6 transition-all duration-300 hover:translate-y-[-2px] hover:shadow-2xl ${
                activeModel === model.id
                  ? 'border-purple-500/50 shadow-purple-500/20'
                  : 'border-gray-800/50 hover:border-purple-700/50'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2 rounded-xl ${
                    activeModel === model.id ? 'bg-purple-500/20' : 'bg-gray-800/50'
                  }`}>
                    <Cpu className={`w-5 h-5 ${
                      activeModel === model.id ? 'text-purple-400' : 'text-gray-400'
                    }`} />
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    model.status === 'active' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                    model.status === 'training' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                    'bg-gray-700/50 text-gray-400 border border-gray-700'
                  }`}>
                    {model.status}
                  </span>
                </div>
                <h3 className="font-semibold text-white mb-1">{model.name}</h3>
                <p className="text-xs text-gray-400 mb-3">{model.type}</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">Accuracy</span>
                  <span className={`font-semibold ${
                    activeModel === model.id ? 'text-purple-400' : 'text-gray-300'
                  }`}>{model.accuracy}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Training Progress */}
        {isTraining && (
          <div className="mb-6 p-6 bg-purple-500/10 backdrop-blur-sm rounded-2xl border border-purple-500/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <RefreshCw className="w-5 h-5 text-purple-400 animate-spin" />
                <span className="font-semibold text-white">Training in Progress</span>
              </div>
              <span className="text-purple-300 font-medium">{trainingProgress}%</span>
            </div>
            <div className="w-full bg-gray-800/50 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                style={{ width: `${trainingProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Active Predictions */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-white">Active Predictions</h3>
            <div className="flex gap-2">
              {(['24h', '7d', '30d', '90d'] as const).map(timeframe => (
                <button
                  key={timeframe}
                  onClick={() => setSelectedTimeframe(timeframe)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                    selectedTimeframe === timeframe
                      ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25'
                      : 'bg-gray-800/50 text-gray-400 hover:bg-gray-800/70 hover:text-white border border-gray-700'
                  }`}
                >
                  {timeframe}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {predictions.map(prediction => (
              <div key={prediction.id} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-pink-600/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
                <div className="relative bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6 hover:border-purple-700/50 transition-all duration-300 hover:translate-y-[-2px] hover:shadow-2xl">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-white mb-1">{prediction.title}</h4>
                      <p className="text-sm text-gray-400">
                        {prediction.timeframe}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getImpactColor(prediction.impact)}`}>
                      {prediction.impact} impact
                    </span>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                        {prediction.value}
                      </span>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-gray-500">Confidence</span>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-gray-800/50 rounded-full h-2">
                            <div
                              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full shadow-[0_0_6px_rgba(168,85,247,0.5)]"
                              style={{ width: `${prediction.confidence}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold text-purple-400">{prediction.confidence}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <p className="text-sm font-medium text-gray-300">Recommendations:</p>
                    {prediction.recommendations.map((rec, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-sm text-gray-400">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span>{rec}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 flex gap-2">
                    <button className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-200 font-medium text-sm">
                      Apply Recommendations
                    </button>
                    <button className="px-4 py-2 bg-gray-800/50 text-gray-400 rounded-xl hover:bg-gray-800/70 hover:text-white border border-gray-700 transition-all duration-200 text-sm">
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
      </div>

        {/* Anomaly Detection */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-white mb-6">Anomaly Detection</h3>
          <div className="space-y-3">
            {anomalies.map(anomaly => (
              <div key={anomaly.id} className="relative group">
                <div className={`absolute inset-0 rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500 ${
                  anomaly.severity === 'critical' ? 'bg-red-600/20' :
                  anomaly.severity === 'warning' ? 'bg-yellow-600/20' :
                  'bg-blue-600/20'
                }`} />
                <div className="relative flex items-start gap-4 p-4 bg-gray-900/60 backdrop-blur-xl rounded-xl border border-gray-800/50 hover:border-gray-700/50 transition-all duration-300 hover:translate-y-[-1px] hover:shadow-xl">
                  {getSeverityIcon(anomaly.severity)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-white">{anomaly.type} Anomaly</h4>
                        <p className="text-sm text-gray-400 mt-1">
                          {anomaly.description}
                        </p>
                      </div>
                      <span className="text-sm text-gray-500">
                        {Math.floor((Date.now() - anomaly.detected.getTime()) / (1000 * 60))}m ago
                      </span>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-sm">
                      <span className="text-gray-500">Location: <span className="text-gray-300">{anomaly.location}</span></span>
                      <span className="text-gray-500">Confidence: <span className={`font-medium ${
                        anomaly.severity === 'critical' ? 'text-red-400' :
                        anomaly.severity === 'warning' ? 'text-yellow-400' :
                        'text-blue-400'
                      }`}>{anomaly.confidence}%</span></span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Model Performance */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-cyan-600/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
            <div className="relative bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6 hover:border-blue-700/50 transition-all duration-300 hover:translate-y-[-2px] hover:shadow-2xl">
              <h3 className="font-semibold text-white mb-4">Model Performance</h3>
              {selectedModel && (
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Accuracy</span>
                    <span className="font-semibold text-white">{selectedModel.accuracy}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Data Points</span>
                    <span className="font-semibold text-white">{selectedModel.dataPoints.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Last Trained</span>
                    <span className="font-semibold text-white">
                      {Math.floor((Date.now() - selectedModel.lastTrained.getTime()) / (1000 * 60 * 60))}h ago
                    </span>
                  </div>
                  <button
                    onClick={() => startTraining(selectedModel.id)}
                    disabled={isTraining}
                    className="w-full mt-4 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-200 disabled:opacity-50 font-medium"
                  >
                    {isTraining ? 'Training...' : 'Retrain Model'}
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-emerald-600/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
            <div className="relative bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6 hover:border-green-700/50 transition-all duration-300 hover:translate-y-[-2px] hover:shadow-2xl">
              <h3 className="font-semibold text-white mb-4">Prediction History</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Total Predictions</span>
                  <span className="font-semibold text-white">1,847</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Accuracy Rate</span>
                  <span className="font-semibold text-green-400">92.3%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Value Generated</span>
                  <span className="font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">$124,500</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Issues Prevented</span>
                  <span className="font-semibold text-white">47</span>
                </div>
              </div>
              <button className="w-full mt-4 px-4 py-2 bg-gray-800/50 text-gray-400 rounded-xl hover:bg-gray-800/70 hover:text-white border border-gray-700 transition-all duration-200">
                View Full History
              </button>
            </div>
          </div>
        </div>

        {/* Export Options */}
        <div className="mt-6 p-6 bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-white">Export Predictions</h4>
              <p className="text-sm text-gray-400 mt-1">
                Download predictions and model insights for further analysis
              </p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-200 font-medium">
              <Download className="w-4 h-4" />
              Export Data
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}