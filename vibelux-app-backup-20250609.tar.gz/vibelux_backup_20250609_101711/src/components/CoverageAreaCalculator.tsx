"use client"

import { useState } from 'react'
import { 
  Grid3x3, 
  Lightbulb, 
  Square, 
  Circle,
  Pentagon,
  Ruler,
  Target,
  AlertCircle,
  CheckCircle,
  Maximize
} from 'lucide-react'

interface FixtureOption {
  id: string
  name: string
  ppf: number
  beamAngle: number
  recommendedHeight: number
  price: number
}

export function CoverageAreaCalculator() {
  const [roomWidth, setRoomWidth] = useState(20) // feet
  const [roomLength, setRoomLength] = useState(20) // feet
  const [roomShape, setRoomShape] = useState<'rectangle' | 'square' | 'circle'>('rectangle')
  const [targetPPFD, setTargetPPFD] = useState(600) // μmol/m²/s
  const [mountingHeight, setMountingHeight] = useState(3) // feet
  const [selectedFixture, setSelectedFixture] = useState('gavita-1700e')
  const [overlapPercentage, setOverlapPercentage] = useState(20) // %
  const [aisleSpace, setAisleSpace] = useState(3) // feet
  const [uniformityTarget, setUniformityTarget] = useState(0.8) // 80%
  
  const fixtures: FixtureOption[] = [
    { id: 'gavita-1700e', name: 'Gavita Pro 1700e', ppf: 1700, beamAngle: 120, recommendedHeight: 3, price: 1299 },
    { id: 'fluence-spydr', name: 'Fluence SPYDR 2p', ppf: 1650, beamAngle: 130, recommendedHeight: 2.5, price: 1499 },
    { id: 'photontek-600w', name: 'PhotonTek 600W Pro', ppf: 1620, beamAngle: 120, recommendedHeight: 2.5, price: 899 },
    { id: 'mars-fc6500', name: 'Mars Hydro FC6500', ppf: 1711, beamAngle: 115, recommendedHeight: 3.5, price: 799 },
  ]
  
  const currentFixture = fixtures.find(f => f.id === selectedFixture) || fixtures[0]
  
  // Calculate coverage per fixture
  const coverageRadius = mountingHeight * Math.tan((currentFixture.beamAngle / 2) * Math.PI / 180) * 2
  const coverageArea = Math.PI * Math.pow(coverageRadius, 2)
  const effectiveCoverage = coverageArea * (1 - overlapPercentage / 100)
  
  // Calculate room area
  const roomArea = roomShape === 'circle' 
    ? Math.PI * Math.pow(roomWidth / 2, 2)
    : roomWidth * roomLength
  
  // Calculate usable area (minus aisles)
  const usableArea = roomArea - (aisleSpace * roomWidth + aisleSpace * roomLength - aisleSpace * aisleSpace)
  
  // Calculate fixtures needed
  const fixturesNeeded = Math.ceil(usableArea / effectiveCoverage)
  
  // Calculate PPFD
  const avgPPFD = (currentFixture.ppf * fixturesNeeded) / (usableArea * 10.764) // Convert to m²
  
  // Calculate power metrics
  const totalPower = fixturesNeeded * 600 // Assuming 600W average
  const powerDensity = totalPower / roomArea
  
  // Grid layout optimization
  const cols = Math.ceil(Math.sqrt(fixturesNeeded * (roomWidth / roomLength)))
  const rows = Math.ceil(fixturesNeeded / cols)
  const spacingX = roomWidth / (cols + 1)
  const spacingY = roomLength / (rows + 1)
  
  // Cost calculations
  const totalCost = fixturesNeeded * currentFixture.price
  const costPerSqFt = totalCost / roomArea

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-2">
          Coverage Area Calculator
        </h1>
        <p className="text-gray-400">
          Calculate optimal fixture layout and coverage for your grow space
        </p>
      </div>

      {/* Input Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Room Configuration */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Square className="w-5 h-5 text-purple-400" />
            Room Configuration
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Room Shape</label>
              <div className="grid grid-cols-3 gap-2">
                {(['rectangle', 'square', 'circle'] as const).map((shape) => (
                  <button
                    key={shape}
                    onClick={() => setRoomShape(shape)}
                    className={`p-3 rounded-lg transition-all flex flex-col items-center gap-2 ${
                      roomShape === shape
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/25'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {shape === 'rectangle' && <Square className="w-5 h-5" />}
                    {shape === 'square' && <Square className="w-5 h-5" />}
                    {shape === 'circle' && <Circle className="w-5 h-5" />}
                    <span className="text-xs capitalize">{shape}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {roomShape === 'circle' ? 'Diameter' : 'Width'} (ft)
                </label>
                <input
                  type="number"
                  value={roomWidth}
                  onChange={(e) => setRoomWidth(Number(e.target.value))}
                  className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
                />
              </div>
              {roomShape !== 'circle' && (
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Length (ft)
                  </label>
                  <input
                    type="number"
                    value={roomLength}
                    onChange={(e) => setRoomLength(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
                  />
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Aisle Space (ft)
              </label>
              <input
                type="number"
                value={aisleSpace}
                onChange={(e) => setAisleSpace(Number(e.target.value))}
                step="0.5"
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Mounting Height (ft)
              </label>
              <input
                type="number"
                value={mountingHeight}
                onChange={(e) => setMountingHeight(Number(e.target.value))}
                step="0.5"
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
              />
            </div>
          </div>
        </div>

        {/* Fixture Settings */}
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-400" />
            Fixture Selection
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Fixture Model
              </label>
              <select
                value={selectedFixture}
                onChange={(e) => setSelectedFixture(e.target.value)}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
              >
                {fixtures.map(fixture => (
                  <option key={fixture.id} value={fixture.id}>
                    {fixture.name} - {fixture.ppf} μmol/s - ${fixture.price}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Target PPFD (μmol/m²/s)
              </label>
              <input
                type="number"
                value={targetPPFD}
                onChange={(e) => setTargetPPFD(Number(e.target.value))}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white focus:border-purple-500 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Coverage Overlap: {overlapPercentage}%
              </label>
              <input
                type="range"
                min="0"
                max="50"
                value={overlapPercentage}
                onChange={(e) => setOverlapPercentage(Number(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span>25%</span>
                <span>50%</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Uniformity Target: {(uniformityTarget * 100).toFixed(0)}%
              </label>
              <input
                type="range"
                min="0.5"
                max="0.95"
                step="0.05"
                value={uniformityTarget}
                onChange={(e) => setUniformityTarget(Number(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>50%</span>
                <span>70%</span>
                <span>95%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-xl rounded-xl border border-purple-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Grid3x3 className="w-5 h-5 text-purple-400" />
            <p className="text-sm text-gray-400">Fixtures Needed</p>
          </div>
          <p className="text-3xl font-bold text-white">{fixturesNeeded}</p>
          <p className="text-xs text-gray-400 mt-1">{cols} × {rows} grid</p>
        </div>

        <div className="bg-gradient-to-br from-blue-900/50 to-cyan-900/50 backdrop-blur-xl rounded-xl border border-blue-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-5 h-5 text-blue-400" />
            <p className="text-sm text-gray-400">Average PPFD</p>
          </div>
          <p className="text-3xl font-bold text-white">{Math.round(avgPPFD)}</p>
          <p className="text-xs text-gray-400 mt-1">
            {avgPPFD >= targetPPFD ? (
              <span className="text-green-400">✓ Meets target</span>
            ) : (
              <span className="text-yellow-400">Below target</span>
            )}
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 backdrop-blur-xl rounded-xl border border-green-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Maximize className="w-5 h-5 text-green-400" />
            <p className="text-sm text-gray-400">Coverage/Fixture</p>
          </div>
          <p className="text-3xl font-bold text-white">{effectiveCoverage.toFixed(0)}</p>
          <p className="text-xs text-gray-400 mt-1">ft² per fixture</p>
        </div>

        <div className="bg-gradient-to-br from-yellow-900/50 to-orange-900/50 backdrop-blur-xl rounded-xl border border-yellow-500/30 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Ruler className="w-5 h-5 text-yellow-400" />
            <p className="text-sm text-gray-400">Fixture Spacing</p>
          </div>
          <p className="text-3xl font-bold text-white">{spacingX.toFixed(1)}'</p>
          <p className="text-xs text-gray-400 mt-1">× {spacingY.toFixed(1)}' centers</p>
        </div>
      </div>

      {/* Layout Visualization */}
      <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Optimal Layout Visualization</h3>
        
        <div className="relative bg-gray-800 rounded-xl p-8 overflow-hidden">
          <div 
            className="relative mx-auto border-2 border-gray-600"
            style={{
              width: '100%',
              maxWidth: '600px',
              aspectRatio: `${roomWidth} / ${roomLength}`,
              borderRadius: roomShape === 'circle' ? '50%' : '8px'
            }}
          >
            {/* Grid of fixtures */}
            {Array.from({ length: rows }, (_, rowIdx) => (
              Array.from({ length: cols }, (_, colIdx) => {
                const fixtureNum = rowIdx * cols + colIdx
                if (fixtureNum >= fixturesNeeded) return null
                
                const x = ((colIdx + 1) / (cols + 1)) * 100
                const y = ((rowIdx + 1) / (rows + 1)) * 100
                
                return (
                  <div
                    key={`${rowIdx}-${colIdx}`}
                    className="absolute w-8 h-8 -translate-x-1/2 -translate-y-1/2"
                    style={{
                      left: `${x}%`,
                      top: `${y}%`
                    }}
                  >
                    <div className="w-full h-full bg-yellow-500 rounded shadow-lg shadow-yellow-500/50" />
                    <div 
                      className="absolute inset-0 rounded-full opacity-20"
                      style={{
                        width: `${coverageRadius * 20}px`,
                        height: `${coverageRadius * 20}px`,
                        background: 'radial-gradient(circle, rgba(255,255,0,0.3) 0%, transparent 70%)',
                        transform: 'translate(-50%, -50%)',
                        left: '50%',
                        top: '50%'
                      }}
                    />
                  </div>
                )
              })
            ))}
            
            {/* Room dimensions label */}
            <div className="absolute bottom-2 left-2 bg-gray-900/80 px-2 py-1 rounded text-xs text-white">
              {roomWidth} × {roomLength} ft
            </div>
          </div>
        </div>
      </div>

      {/* Cost Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Area Breakdown</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Total Room Area</span>
              <span className="text-white font-medium">{roomArea.toFixed(0)} ft²</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Usable Grow Area</span>
              <span className="text-white font-medium">{usableArea.toFixed(0)} ft²</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Aisle/Access Area</span>
              <span className="text-white font-medium">{(roomArea - usableArea).toFixed(0)} ft²</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
              <span className="text-purple-400">Coverage Efficiency</span>
              <span className="text-white font-bold">{((usableArea / roomArea) * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-900/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Cost Breakdown</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Fixture Cost</span>
              <span className="text-white font-medium">${currentFixture.price}</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Total Equipment</span>
              <span className="text-white font-medium">${totalCost.toFixed(0)}</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
              <span className="text-gray-400">Cost per ft²</span>
              <span className="text-white font-medium">${costPerSqFt.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-green-500/10 rounded-lg border border-green-500/30">
              <span className="text-green-400">Power Density</span>
              <span className="text-white font-bold">{powerDensity.toFixed(1)} W/ft²</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 backdrop-blur-xl rounded-2xl border border-blue-500/30 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Layout Recommendations</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {avgPPFD >= targetPPFD ? (
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-green-400 font-medium">PPFD Target Met</p>
                <p className="text-sm text-gray-300 mt-1">
                  Your layout achieves {Math.round(avgPPFD)} μmol/m²/s, exceeding the target of {targetPPFD}.
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-yellow-400 font-medium">PPFD Below Target</p>
                <p className="text-sm text-gray-300 mt-1">
                  Consider adding {Math.ceil((targetPPFD - avgPPFD) * usableArea * 10.764 / currentFixture.ppf)} more fixtures.
                </p>
              </div>
            </div>
          )}
          
          {overlapPercentage < 15 && (
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-yellow-400 font-medium">Low Overlap</p>
                <p className="text-sm text-gray-300 mt-1">
                  Increase overlap to 15-25% for better uniformity.
                </p>
              </div>
            </div>
          )}
          
          {mountingHeight !== currentFixture.recommendedHeight && (
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-blue-400 font-medium">Height Adjustment</p>
                <p className="text-sm text-gray-300 mt-1">
                  Manufacturer recommends {currentFixture.recommendedHeight}ft mounting height.
                </p>
              </div>
            </div>
          )}
          
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-green-400 font-medium">Grid Layout</p>
              <p className="text-sm text-gray-300 mt-1">
                {cols} × {rows} grid with {spacingX.toFixed(1)}' × {spacingY.toFixed(1)}' spacing.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}