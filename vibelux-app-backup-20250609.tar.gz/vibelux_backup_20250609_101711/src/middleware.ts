import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

const isPublicRoute = createRouteMatcher([
  "/",
  "/api/webhooks(.*)",
  "/sign-in(.*)",
  "/sign-up(.*)",
  "/pricing",
  "/features",
  "/about",
  "/privacy",
  "/terms",
  "/support",
  "/fixtures(.*)",
  "/api/fixtures(.*)",
  "/calculators(.*)",
  "/design(.*)",
  "/spectrum(.*)",
  "/schedule(.*)",
  "/test-css",
  "/test(.*)",
  "/analytics(.*)",
  "/predictions(.*)",
  "/reports(.*)",
  "/templates(.*)",
  "/batch(.*)",
  "/settings(.*)",
  "/language(.*)",
  "/accessibility(.*)",
  "/integrations(.*)",
  "/sync(.*)",
  "/offline(.*)",
  "/pwa(.*)",
  "/api-docs(.*)",
  "/dev-tools(.*)",
  "/carbon-credits(.*)",
  "/iot-devices(.*)",
  "/equipment-leasing(.*)",
  "/community-forum(.*)",
  "/light-recipes(.*)",
  "/photosynthetic-calculator(.*)",
  "/spectrum-builder(.*)",
  "/maintenance-tracker(.*)",
  "/export-center(.*)",
  "/greenhouse-integration(.*)",
  "/yield-prediction(.*)",
  "/tco-calculator(.*)",
  "/rebate-calculator(.*)",
  "/multi-site(.*)",
  "/nutrient-dosing(.*)",
  "/dlc-compliance(.*)",
  "/weather-adaptive(.*)",
]);

export default clerkMiddleware(async (auth, req) => {
  if (!isPublicRoute(req)) {
    await auth.protect();
  }
});

export const config = {
  matcher: [
    // Skip Next.js internals and all static files, unless found in search params
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    // Always run for API routes
    '/(api|trpc)(.*)',
  ],
};