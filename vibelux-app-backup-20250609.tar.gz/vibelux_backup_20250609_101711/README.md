# Vibelux App Backup
Created: 20250609_101711

## Quick Restore Instructions

1. **Restore files:**
   ```bash
   chmod +x restore.sh
   ./restore.sh
   ```

2. **Setup environment:**
   - Copy `.env.local.template` to `.env.local`
   - Fill in your API keys and secrets

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Run the application:**
   ```bash
   npm run dev
   ```

## What's Included

- All source code from `/src`
- Configuration files (package.json, tsconfig.json, etc.)
- Public assets
- Backup manifest with full project documentation

## Important Notes

- Remember to set up your environment variables
- Check BACKUP_MANIFEST.md for detailed project information
- Ensure Node.js 18+ is installed
