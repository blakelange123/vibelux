#!/bin/bash
echo "🔄 Restoring Vibelux App from backup..."
echo "======================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found in backup directory"
    echo "Please run this script from within the backup directory"
    exit 1
fi

# Ask for target directory
read -p "Enter target directory path (or press Enter for current directory): " TARGET_DIR
TARGET_DIR=${TARGET_DIR:-.}

# Create target directory if it doesn't exist
mkdir -p "$TARGET_DIR"

# Copy all files
echo "📁 Copying files to $TARGET_DIR..."
cp -r ./* "$TARGET_DIR/"

echo "✅ Restore complete!"
echo ""
echo "Next steps:"
echo "1. cd $TARGET_DIR"
echo "2. Create .env.local with your environment variables"
echo "3. npm install"
echo "4. npm run dev"
