// Emergency sidebar toggle script
// This can be pasted into the browser console or included as a script

(function() {
  // Create toggle button
  const button = document.createElement('button');
  button.className = 'sidebar-emergency-toggle';
  button.textContent = 'Toggle Sidebar';
  
  // Toggle function
  function toggleSidebar() {
    document.body.classList.toggle('hide-sidebar');
    const isHidden = document.body.classList.contains('hide-sidebar');
    button.textContent = isHidden ? 'Show Sidebar' : 'Hide Sidebar';
    console.log('Sidebar toggled:', isHidden ? 'hidden' : 'visible');
  }
  
  // Add click handler
  button.onclick = toggleSidebar;
  
  // Add to page
  document.body.appendChild(button);
  
  // Also add keyboard shortcut (Alt+S)
  document.addEventListener('keydown', function(e) {
    if (e.altKey && e.key === 's') {
      e.preventDefault();
      toggleSidebar();
    }
  });
  
  console.log('Sidebar toggle installed. Click the red button or press Alt+S');
})();